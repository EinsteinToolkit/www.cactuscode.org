 /*@@
   @header    Template.h
   @date      Fri Oct  6 10:45:01 2000
   @author    Tom Goodale
   @desc 
   This is a template header function
   @enddesc
   @version $Header: /cactusdevcvs/Cactus/doc/MaintGuide/Template.h,v 1.3 2000/12/15 18:05:32 goodale Exp $
 @@*/

#ifndef _TEMPLATE_H_
#define _TEMPLATE_H_ 1

#ifdef __cplusplus
extern "C" 
{
#endif


#ifdef __cplusplus
}
#endif

#endif /* _TEMPLATE_H_ */
