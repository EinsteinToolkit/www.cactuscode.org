 /*@@
   @header    ParameterData.h
   @date      Fri Jan 15 14:06:43 1999
   @author    Tom Goodale
   @desc 
   
   @enddesc
   @version $Id: ParameterData.h,v 1.2 1999/07/24 22:57:04 allen Exp $
 @@*/

int ProcessParameterDatabase(tFleshConfig *ConfigData);

int CCTKi_InitialiseParameters(tFleshConfig *ConfigData);

