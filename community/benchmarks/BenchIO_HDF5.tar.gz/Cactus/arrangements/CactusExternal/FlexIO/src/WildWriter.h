#ifndef __WILDWRITER_H_
#define __WILDWRITER_H_

#include "declare_extern.h"
void WriteNodes(char *filename);

#endif
