#include "AMRreaderPlus.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <algorithm>


AMRreaderPlus::AMRreaderPlus(IObase &f) : AMRgridreaderPlus(f), grids(),  
    activeset(),  timemask(), levelmask(), realtimes()
{
    init();
    selectTimeStep(0);
    for (int ii=0;ii<=maxlevel;ii++) showLevel(ii);
    modflag=1;
}
    

  
AMRreaderPlus::~AMRreaderPlus(){
    
}



void AMRreaderPlus::init(){
    maxlevel=maxtimeres=maxtime=0;
    smin=smax=0.0;
    numgrids=0;
    
    build_info();
}
void AMRreaderPlus::build_info(){
    AMRgridPlus  *res, newg;
    res=getGridInfo(newg, 0);
    if (res==NULL) return;
    maxlevel=0;
    maxtime=0;
    numgrids=0;
    smin=newg.scalarmin;
    smax=newg.scalarmax;
    datatype=newg.datatype;
    while (res!=NULL){		    //Load all grid info
	grids.append(newg);
	realtimes.insert(newg.time);
	maxlevel=(maxlevel>newg.level)?maxlevel:newg.level;
	maxtime=(maxtime>newg.timestep)?maxtime:newg.timestep;
	smax=smax>newg.scalarmax?smax:newg.scalarmax;
	smin=smin<newg.scalarmin?smin:newg.scalarmin;
	numgrids++;
	res=getGridInfo(newg, numgrids);
    } 
    levelmask.fill(0, maxlevel+1);
    timemask.fill(0, maxtime+1);
   
   
    leveltimes= new flexmatrix<IdxArray> (maxlevel+1, maxtime+1);
    
    AMRgridPlus *g= grids.getData(0);
    for(int ii=0;ii<grids.getSize();ii++){//Extract basic info
	for (int jj=g->timestep;jj<g->timestep+g->persistence;jj++){
	    if (jj<=maxtime){
		idxrec trec(ii);
		(*leveltimes)(g->level, jj).append(trec.idx);
	    }
	}
	g++;
    }
    
    cout<<realtimes.getSize()<<" "<<numgrids<<endl<<endl;
    
}

void AMRreaderPlus::build_active(){
    IdxSet newset, delset;
    
    //Calculate what the set should be
	int ii;
    for (ii=0;ii<=maxtime;ii++)
	for (int jj=0;jj<=maxlevel;jj++)
	    if (timemask[ii]&&levelmask[jj]){
		for (int kk=0;kk<(*leveltimes)(jj, ii).getSize();kk++){
		    newset.insert((*leveltimes)(jj, ii)[kk]);
		}
	    }
    
    //remove all the unneeded grids
    setdifference(activeset, newset, delset); 
    for (ii=0;ii<delset.getSize();ii++)
	if (grids[delset[ii].idx].data!=NULL){
	    free(grids[delset[ii].idx].data);
	    grids[delset[ii].idx].data=NULL;
	}
    activeset=newset;
}


void AMRreaderPlus::modify(){modflag=1;}

void AMRreaderPlus::getActive(IdxSet &grids){
    if (modflag!=0){
	build_active();
	modflag=0;
    }
    grids=activeset;
}

void AMRreaderPlus::loadData(IdxSet &loadset){
    if (modflag!=0){
	build_active();
	modflag=0;
    }
    
    if (!activeset.contains(loadset)){
	cout<<"Trying to load non-active grids. Hmmmm."<<endl;
    }
    
    for (int ii=0;ii<loadset.getSize();ii++){
	if (grids[loadset[ii].idx].data==NULL){
	    cout<<"Loaded "<<loadset[ii].idx<<endl;
	    getGridData(grids[loadset[ii].idx], loadset[ii].idx);
	    }
    }
}
