#include <stdio.h>
#include <stdlib.h>
#include "AMRfilereaderPlus.h"
#include "FlexArrayTmpl.H"
void AMRfilereaderPlus::printGridInfo(AMRgridPlus &g){
	int i;
    printf("Grid level=%u step=%u maxtime=%u\n",g.level,g.timestep,g.maxtime);
    printf("\trank=%u dims[",g.rank);
    for(i=0;i<g.rank-1;i++) printf("%u,",g.dims[i]);
    printf("%u]\n",g.dims[g.rank-1]);
    printf("\tTimerefine=%u dx[0]=%lf origin[",g.timerefinement,g.delta[0]);
    for(i=0;i<g.rank-1;i++) printf("%lf,",g.origin[i]);
    printf("%lf]\n",g.origin[g.rank-1]);
    printf("\tData Pointer is %u\n",(unsigned long)(g.data));
    if(g.data){
      float *fdata = (float *)(g.data);
      for(int i=0;i<3;i++)
	printf("\t\tData[%u]=%f\n",i,fdata[i]);
    }
  }
 void AMRfilereaderPlus::printGridInfo(){
    // print it all out...
    printf("MaxLevel=%u\n",maxlevel);
    for(int i=0;i<grids.getSize();i++){
      printf("Grid[%u]--------------------\n",i);
      printGridInfo(grids[i]);
    }
  }
  void AMRfilereaderPlus::printActiveGrids(){
    // print it all out...
    printf("Num Active Grids=%u\n",activeGrids.getSize());
    for(int i = 0; i < activeGrids.getSize(); i++){
      printf("  Grid[%u] mapped from %u --------------------\n",
	     i,activeGrids[i]);
      printGridInfo(grids[activeGrids[i]]);
    }
  }
#define MAXIMIZE(u, v) {(u)=((u)>(v))?(u):(v);}
#define MINIMIZE(u, v) {(u)=((u)<(v))?(u):(v);}

void AMRfilereaderPlus::buildInfoTable(){
  // Load all grids Info
  int index=0;
  AMRgridPlus g;
  while(getGridInfo(g,index++)){
    if(this->debug) printf("buildInfoTable: getGrid index=%u\n",index);
    if(this->debug) printGridInfo(g);
    int i=grids.getSize();
    g.data=0; // zero out the data
    if(g.level>maxlevel)
      maxlevel=g.level;
    if(!i){
      smin=g.scalarmin;
      smax=g.scalarmax;
      //--Brad's additions
      //sminArray[i]=g.scalarmin;
      //smaxArray[i]=g.scalarmax;
      //--
      mintime = g.timestep;
      maxtime = g.timestep;
      maxtimeres = g.timerefinement;
      maxlevel= g.level;
      bounds[0]=g.origin[0];
      bounds[1]=g.origin[0]+g.delta[0]*g.dims[0];
      bounds[2]=g.origin[1];
      bounds[3]=g.origin[1]+g.delta[1]*g.dims[1];
      bounds[4]=g.origin[2];
      bounds[5]=g.origin[2]+g.delta[2]*g.dims[2];
    }
    else{
      //--Brad's additions
      //sminArray[i]=g.scalarmin;
      //smaxArray[i]=g.scalarmax;
      //--
	MINIMIZE(smin, g.scalarmin);
	MAXIMIZE(smax, g.scalarmax);
	if (g.level==0){
	    MINIMIZE(bounds[0], g.origin[0]);
	    MAXIMIZE(bounds[1], g.origin[0]+g.delta[0]*g.dims[0]);
	    MINIMIZE(bounds[2], g.origin[1]);
	    MAXIMIZE(bounds[3], g.origin[1]+g.delta[1]*g.dims[1]);
	    MINIMIZE(bounds[4], g.origin[2]);
	    MAXIMIZE(bounds[5], g.origin[2]+g.delta[2]*g.dims[2]);
	}
    }
    if(g.timestep<mintime) 
      mintime=g.timestep;
    if(g.timestep>maxtime) 
      maxtime=g.timestep;
    if(g.timerefinement>maxtimeres) 
      maxtimeres=g.timerefinement;
    grids.append(g); 
  }
}

void AMRfilereaderPlus::loadGrids(){
  if(!gridloading) return;
  for(int i=0;i<activeGrids.getSize();i++){
    if(this->debug) printf("buildInfoTable: getGrid index=%u activegridindex %u\n",i,activeGrids[i]);
    if(this->debug) printGridInfo(grids[activeGrids[i]]);
    getGridData(grids[activeGrids[i]],activeGrids[i]);
  }
}

void AMRfilereaderPlus::reclaimGrids(){
  if(!gridloading) return;
  for(int i=0;i<grids.getSize();i++){
    int f=0;
    for(int j=0;j<activeGrids.getSize();j++){
      if(activeGrids[j]==i){
	f=1;
	break;
      }
    }
    if(!f){
      free((grids[i]).data);
      (grids[i]).data=0;
    }
  }
}

void AMRfilereaderPlus::purgeGrids(){
  for(int i=0;i<grids.getSize();i++){
    if((grids[i]).data)
      free((grids[i]).data);
    (grids[i]).data=0;
  }
}

AMRfilereaderPlus::AMRfilereaderPlus(IObase &f):AMRgridreaderPlus(f),debug(0),gridloading(1){
  // we need to build a table from the file
  // then select grids based on the timestep
  buildInfoTable(); // initialize the convertor
  levelmask.setSize(maxlevel+1);
  for(int i=0;i<=maxlevel;i++)
    levelmask[i]=1; // all levels visible is default
  showAllLevels();
  setTime(mintime);
}

void AMRfilereaderPlus::setTime(int timestep){
  // Make Grid Selections
  if(timestep<mintime || timestep>maxtime){
    printf("timestep %u is out of range %u:%u\n",
	   timestep,mintime,maxtime);
    return;
  }
  activeGrids.purge();
  current_time=timestep;
  if(this->debug) printf("setTime(%u): mintime=%u maxtime=%u\n",current_time,mintime,maxtime);
  for(int i=0;i<grids.getSize();i++){
    if(this->debug) printf("\tgrids[%u].timestep=%u maxtime=%u\n",i,grids[i].timestep,
	   grids[i].maxtime);
    if(current_time>=grids[i].timestep && 
       current_time<grids[i].maxtime && levelmask[grids[i].level]){
      activeGrids.append(i);
      if(this->debug) printf("\t\tAppendGrid number %u\n",i);
    }
  }
  if(this->debug) puts("load grids");
  loadGrids();
  if(this->debug) puts("reclaim grids");
  reclaimGrids();
}
	
void AMRfilereaderPlus::showAllLevels(){
  for(int i=0;i<levelmask.getSize();i++) levelmask[i]=1;
}
	
// For C interface

int AMRfilereaderPlus::getGrids(AMRgridPlus *g){ // assumes number of 
  for(int i=0;i<grids.getSize();i++)
    g[i]=grids[activeGrids[i]];
  return activeGrids.getSize();
}

// For C++ interface
int AMRfilereaderPlus::getGrids(FlexArray<AMRgridPlus> &g){
  g.setSize(activeGrids.getSize());
  for(int i=0;i<g.getSize();i++)
    g[i]=grids[activeGrids[i]];
  return activeGrids.getSize();
}
