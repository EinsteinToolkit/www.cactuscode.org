#include "AMRwriterPlus.h"


AMRwriterPlus::AMRwriterPlus(IObase &descriptor) : AMRwriter(descriptor){
    scalarFlag=0;
    curscalarmin=curscalarmax=0;
}

void AMRwriterPlus::calcScalarRange(void *data){
    long numelts=1;
    for (int ii=0;ii<drank;ii++) numelts*=ddims[ii];
	        
    switch(this->dtypeID){
	case IObase::Byte:{
	    char *dptr=(char *)data;
	    curscalarmin=curscalarmax=*dptr;
	    for (long kk=0;kk<numelts;kk++){
		curscalarmin=(curscalarmin<dptr[kk])?curscalarmin:dptr[kk];
		curscalarmax=(curscalarmax>=dptr[kk])?curscalarmax:dptr[kk];
		}
	    } break;
	case IObase::Float32:{
	    float *fptr=(float *)data;
	    curscalarmin=curscalarmax=*fptr;
	    for (long jj=0;jj<numelts;jj++){
		curscalarmin=(curscalarmin<fptr[jj])?curscalarmin:fptr[jj];
		curscalarmax=(curscalarmax>=fptr[jj])?curscalarmax:fptr[jj];
		}
	    } break;
	case IObase::Float64:{
	    double *dptr=(double *)data;
	    curscalarmin=curscalarmax=*dptr;
	    for (long kk=0;kk<numelts;kk++){
		curscalarmin=(curscalarmin<dptr[kk])?curscalarmin:dptr[kk];
		curscalarmax=(curscalarmax>=dptr[kk])?curscalarmax:dptr[kk];
		}
	    } break;
    }
}


void AMRwriterPlus::writePlusattributes(){
    double range[2];
    range[0]=curscalarmin;
    range[1]=curscalarmax;
    file.writeAttribute("range", IObase::Float64, 2, range);
    scalarFlag=0;	//reset the flag
}
