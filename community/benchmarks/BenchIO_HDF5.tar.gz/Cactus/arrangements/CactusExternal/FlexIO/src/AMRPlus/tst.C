#include <iostream.h>
#include "flexset.h"

void main(){
    flexset<int> arr1, arr2;
    int tst;
    int ii;
  
    for (ii=0;ii<15;ii++){
	tst=rand() %10; 
	arr1.insert(tst);
    }
    for (ii=0;ii<15;ii++){
	tst=rand() %10; 
	arr2.insert(tst);
    }
    
    flexset<int> arr3;
    for (ii=0;ii<arr1.getSize();ii++){cout<<arr1[ii]<<endl;}
    cout<<endl;
    for (ii=0;ii<arr2.getSize();ii++){cout<<arr2[ii]<<endl;}
    cout<<endl;
    
    setunion(arr1, arr2, arr3);
    cout<<endl;<<"Union: "<<endl;
    for (ii=0;ii<arr3.getSize();ii++){cout<<arr3[ii]<<endl;}
    
    setintersection(arr1, arr2, arr3);
    cout<<endl;<<"Intersection: "<<endl;
    for (ii=0;ii<arr3.getSize();ii++){cout<<arr3[ii]<<endl;}
    
    setdifference(arr1, arr2, arr3);
    cout<<endl;<<"Difference: "<<endl;
    for (ii=0;ii<arr3.getSize();ii++){cout<<arr3[ii]<<endl;}
    
    setsymmetricdifference(arr1, arr2, arr3);
    cout<<endl;<<"Symmetric Difference: "<<endl;
    for (ii=0;ii<arr3.getSize();ii++){cout<<arr3[ii]<<endl;}
    
    
     
}
