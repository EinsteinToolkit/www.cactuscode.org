// inline-fn2.cc -- test non-class inline function in header file
// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/inline-fns/inline-fn2.cc,v 1.1 2003/03/25 17:18:42 jthorn Exp $
#include <stdio.h>
#include "mini-util.hh"

int main(void)
{
printf("jtutil::how_many_in_range(69,105) = %d\n",
       jtutil::how_many_in_range(69,105));
return 0;
}
