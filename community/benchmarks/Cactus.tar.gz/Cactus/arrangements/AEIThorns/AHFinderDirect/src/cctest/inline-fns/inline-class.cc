// inline-class.cc -- test simple class with inline function
// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/inline-fns/inline-class.cc,v 1.2 2003/03/25 17:13:25 jthorn Exp $
#include <stdio.h>

class	addx
	{
public:
	int operator()(int i) { return i+x_; }
	addx(int x);
private:
	int x_;
	};

addx::addx(int x)
	: x_(x)
{ }

int main(void)
{
addx add3(3);
printf("add3(42) = %d\n", add3(42));
return 0;
}
