// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/namespace/stdio_h-global.cc,v 1.1 2002/09/29 15:50:55 jthorn Exp $

#include <stdio.h>

int main()
{
printf("testing <stdio.h> functions in global namespace:\n");
printf("==> #include <stdio.h>; printf() is ok\n");
return 0;
}
