// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/namespace/stdio_h-std--using-namespace-std.cc,v 1.1 2002/10/09 18:32:18 jthorn Exp $

#include <stdio.h>
using namespace std;

int main()
{
printf("testing <stdio.h> functions in std:: namespace:\n");
printf("==> #include <stdio.h>; using namespace std; printf() is ok\n");
return 0;
}
