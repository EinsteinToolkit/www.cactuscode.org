/* fake_cctk.h -- fake "cctk.h" for non-Cactus standalone compilations */
/* $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/include/fake_cctk.h,v 1.4 2003/05/06 15:43:54 jthorn Exp $ */

#ifndef AHFINDERDIRECT__FAKE_CCTK_H
#define AHFINDERDIRECT__FAKE_CCTK_H

#define CCODE
typedef int    CCTK_INT;
typedef double CCTK_REAL;

#endif	/* AHFINDERDIRECT__FAKE_CCTK_H */
