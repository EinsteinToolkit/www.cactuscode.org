// mini-util.hh -- cut-down version of src/jtutil/util.hh for testing inline fns
// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/inline-fns/mini-util.hh,v 1.1 2003/03/25 17:18:42 jthorn Exp $

namespace jtutil
          {
// how many integers are in the closed interval [low,high]
inline int how_many_in_range(int low, int high) { return high - low + 1; }
          }
