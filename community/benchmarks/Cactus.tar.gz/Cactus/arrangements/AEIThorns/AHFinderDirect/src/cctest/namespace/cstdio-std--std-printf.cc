// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/namespace/cstdio-std--std-printf.cc,v 1.1 2002/10/09 18:32:18 jthorn Exp $

#include <cstdio>

int main()
{
std::printf("testing <cstdio> functions in std:: namespace:\n");
std::printf("==> #include <cstdio>; std::printf() is ok\n");
return 0;
}
