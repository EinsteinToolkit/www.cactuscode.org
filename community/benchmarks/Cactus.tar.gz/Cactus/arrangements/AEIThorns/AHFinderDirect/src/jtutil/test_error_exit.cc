// test_error_exit.cc -- test driver for  error_exit()  function
// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/jtutil/test_error_exit.cc,v 1.1 2002/09/29 23:05:18 jthorn Exp $

#include <stdio.h>

#include "stdc.h"
using jtutil::error_exit;

int main()
{
error_exit(ERROR_EXIT, "two+two=%.3f", 4.0);			/*NOTREACHED*/
return 0;
}
