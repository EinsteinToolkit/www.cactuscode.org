// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/namespace/stdio_h-std--using-std-printf.cc,v 1.1 2002/10/09 18:32:18 jthorn Exp $

#include <stdio.h>
using std::printf;

int main()
{
printf("testing <stdio.h> functions in std:: namespace:\n");
printf("==> #include <stdio.h>; using std::printf; printf() is ok\n");
return 0;
}
