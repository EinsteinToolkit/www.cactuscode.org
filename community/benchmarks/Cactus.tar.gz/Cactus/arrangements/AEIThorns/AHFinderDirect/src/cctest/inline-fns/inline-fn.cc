// inline-fn.cc -- test non-class inline function
// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/inline-fns/inline-fn.cc,v 1.2 2003/03/25 17:13:25 jthorn Exp $
#include <stdio.h>

inline int add3(int x) { return x+3; }

int main(void)
{
printf("add3(42) = %d\n", add3(42));
return 0;
}
