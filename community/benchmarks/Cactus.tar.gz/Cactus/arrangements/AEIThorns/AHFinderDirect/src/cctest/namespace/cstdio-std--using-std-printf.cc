// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/namespace/cstdio-std--using-std-printf.cc,v 1.1 2002/10/09 18:32:18 jthorn Exp $

#include <cstdio>
using std::printf;

int main()
{
printf("testing <cstdio> functions in std:: namespace:\n");
printf("==> #include <cstdio>; using std::printf; printf() is ok\n");
return 0;
}
