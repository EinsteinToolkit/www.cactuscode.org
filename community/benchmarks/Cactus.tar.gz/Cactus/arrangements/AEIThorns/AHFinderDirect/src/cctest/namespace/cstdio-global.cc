// $Header: /numrelcvs/AEIThorns/AHFinderDirect/src/cctest/namespace/cstdio-global.cc,v 1.1 2002/09/29 15:50:55 jthorn Exp $

#include <cstdio>

int main()
{
printf("testing <cstdio> functions in global namespace (THIS SHOULD FAIL):\n");
printf("==> #include <cstdio>; printf() is ok (THIS SHOULD FAIL)\n");
return 0;
}
