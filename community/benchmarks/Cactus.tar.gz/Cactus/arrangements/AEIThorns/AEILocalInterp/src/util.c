 /*@@
   @file      util.c
   @date      23 Oct 2001
   @author    Jonathan Thornburg <jthorn@aei.mpg.de>
   @desc
	Utility routines for generalized interpolation.

	This file contains various utility routines for the interpolator.
   @enddesc
   @version   $Id: util.c,v 1.1.1.1 2003/07/06 11:16:11 jthorn Exp $
 @@*/

#include <math.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifndef AEILOCALINTERP_STANDALONE_TEST
  #include "cctk.h"
#endif

#include "InterpLocalUniform.h"

/* the rcs ID and its dummy function to use it */
static const char *rcsid = "$Header: /numrelcvs/AEIThorns/AEILocalInterp/src/util.c,v 1.1.1.1 2003/07/06 11:16:11 jthorn Exp $";
#ifndef AEILOCALINTERP_STANDALONE_TEST
  CCTK_FILEVERSION(AEIThorns_AEILocalInterp_src_util_c)
#endif

/******************************************************************************/

/*@@
  @routine  AEILocalInterp_decode_N_parts
  @date     22 Jan 2002
  @author   Jonathan Thornburg <jthorn@aei.mpg.de>
  @desc     This function decodes a CCTK_VARIABLE_* variable type code
	    (cctk_Constants.h) to determine whether the type is real
	    or complex.
  @enddesc

  @var      type_code
  @vdesc    The type code to be decoded
  @vtype    int
  @endvar

  @returntype	int
  @returndesc	This function returns
		1	if the data type represents a real number of some sort
			(includes integers)
		2	if the data type represents a complex number
		0	if the data type doesn't represent a number,
			eg strings and pointers
		-1	if the data type is invalid
  @endreturndesc
  @@*/
int AEILocalInterp_decode_N_parts(int type_code)
{
switch	(type_code)
	{
case CCTK_VARIABLE_VOID:	return 0;
case CCTK_VARIABLE_BYTE:	return 1;
case CCTK_VARIABLE_INT:		return 1;
case CCTK_VARIABLE_INT2:	return 1;
case CCTK_VARIABLE_INT4:	return 1;
case CCTK_VARIABLE_INT8:	return 1;
case CCTK_VARIABLE_REAL:	return 1;
case CCTK_VARIABLE_REAL4:	return 1;
case CCTK_VARIABLE_REAL8:	return 1;
case CCTK_VARIABLE_REAL16:	return 1;
case CCTK_VARIABLE_COMPLEX:	return 2;
case CCTK_VARIABLE_COMPLEX8:	return 2;
case CCTK_VARIABLE_COMPLEX16:	return 2;
case CCTK_VARIABLE_COMPLEX32:	return 2;
case CCTK_VARIABLE_STRING:	return 0;
case CCTK_VARIABLE_POINTER:	return 0;
case CCTK_VARIABLE_FPOINTER:	return 0;
default:			return -1;
	}
}
