 /*@@
   @file      startup.c
   @date      Thu Feb 21 16:25:35 CET 2002
   @author    Jonathan Thornburg <jthorn@aei.mpg.de>
   @desc
              Startup routines for thorn AEILocalInterp
   @enddesc
   @version   $Id: startup.c,v 1.1.1.1 2003/07/06 11:16:11 jthorn Exp $
 @@*/

#include <stdlib.h>
#include <limits.h>

#include "cctk.h"
#include "cctk_Interp.h"
#include "InterpLocalUniform.h"

/* the rcs ID and its dummy function to use it */
static const char *rcsid = "$Header: /numrelcvs/AEIThorns/AEILocalInterp/src/startup.c,v 1.1.1.1 2003/07/06 11:16:11 jthorn Exp $";
CCTK_FILEVERSION(AEIThorns_AEILocalInterp_src_startup_c)


/*@@
  @routine   LocalInterp_GPU_Startup
  @date      Thu Feb 21 16:27:41 CET 2002
  @author    Jonathan Thornburg <jthorn@aei.mpg.de>
  @desc      This is the startup routine for thorn AEILocalInterp.
             It registers the interpolation operators.
  @enddesc
  @@*/
void AEILocalInterp_U_Startup(void)
{
CCTK_InterpRegisterOpLocalUniform(AEILocalInterp_U_Lagrange_TP,
			  "Lagrange polynomial interpolation (tensor product)",
				  CCTK_THORNSTRING);
CCTK_InterpRegisterOpLocalUniform(AEILocalInterp_U_Lagrange_MD,
			  "Lagrange polynomial interpolation (maximum degree)",
				  CCTK_THORNSTRING);

CCTK_InterpRegisterOpLocalUniform(AEILocalInterp_U_Hermite,
				  "Hermite polynomial interpolation",
				  CCTK_THORNSTRING);

/* synonym operator names for backwards compatability */
CCTK_InterpRegisterOpLocalUniform(AEILocalInterp_U_Lagrange_TP,
				  "Lagrange polynomial interpolation",
				  CCTK_THORNSTRING);
CCTK_InterpRegisterOpLocalUniform(AEILocalInterp_U_Lagrange_TP,
                                  "generalized polynomial interpolation",
				  CCTK_THORNSTRING);
}
