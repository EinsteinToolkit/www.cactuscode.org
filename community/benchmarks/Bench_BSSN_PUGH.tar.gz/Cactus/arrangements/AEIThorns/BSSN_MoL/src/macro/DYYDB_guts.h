/*@@
  @header   DYYDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DYYDB_GUTS
#define DYYDB_GUTS

#include "macro/BSSN_Derivative.h"

      if (local_spatial_order.eq.2) then
        DYYDB_DYYDBX = BSSN_DYY_2(betax,i,j,k)
        DYYDB_DYYDBY = BSSN_DYY_2(betay,i,j,k)
        DYYDB_DYYDBZ = BSSN_DYY_2(betaz,i,j,k)
      else
        DYYDB_DYYDBX = BSSN_DYY_4(betax,i,j,k)
        DYYDB_DYYDBY = BSSN_DYY_4(betay,i,j,k)
        DYYDB_DYYDBZ = BSSN_DYY_4(betaz,i,j,k)
      end if
#endif
