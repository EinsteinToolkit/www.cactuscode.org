/*@@
  @header   BSDZDA_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef BSDZDA_DECLARE
#define BSDZDA_DECLARE

/* Input variables */
#undef  BSDZDA_AXX_KP   
#define BSDZDA_AXX_KP   ADM_BS_Axx(i,j,k+1)
#undef  BSDZDA_AXY_KP   
#define BSDZDA_AXY_KP   ADM_BS_Axy(i,j,k+1)
#undef  BSDZDA_AXZ_KP  
#define BSDZDA_AXZ_KP   ADM_BS_Axz(i,j,k+1)
#undef  BSDZDA_AYY_KP    
#define BSDZDA_AYY_KP   ADM_BS_Ayy(i,j,k+1)
#undef  BSDZDA_AYZ_KP   
#define BSDZDA_AYZ_KP   ADM_BS_Ayz(i,j,k+1)
#undef  BSDZDA_AZZ_KP   
#define BSDZDA_AZZ_KP   ADM_BS_Azz(i,j,k+1)

#undef  BSDZDA_AXX_KM   
#define BSDZDA_AXX_KM   ADM_BS_Axx(i,j,k-1)
#undef  BSDZDA_AXY_KM   
#define BSDZDA_AXY_KM   ADM_BS_Axy(i,j,k-1)
#undef  BSDZDA_AXZ_KM  
#define BSDZDA_AXZ_KM   ADM_BS_Axz(i,j,k-1)
#undef  BSDZDA_AYY_KM    
#define BSDZDA_AYY_KM   ADM_BS_Ayy(i,j,k-1)
#undef  BSDZDA_AYZ_KM   
#define BSDZDA_AYZ_KM   ADM_BS_Ayz(i,j,k-1)
#undef  BSDZDA_AZZ_KM   
#define BSDZDA_AZZ_KM   ADM_BS_Azz(i,j,k-1)

/* Output variables */ 
#undef  BSDZDA_DZDAXX
#define BSDZDA_DZDAXX  bsdzda_dzdaxx
#undef  BSDZDA_DZDAXY
#define BSDZDA_DZDAXY  bsdzda_dzdaxy
#undef  BSDZDA_DZDAXZ
#define BSDZDA_DZDAXZ  bsdzda_dzdaxz
#undef  BSDZDA_DZDAYY
#define BSDZDA_DZDAYY  bsdzda_dzdayy
#undef  BSDZDA_DZDAYZ
#define BSDZDA_DZDAYZ  bsdzda_dzdayz
#undef  BSDZDA_DZDAZZ
#define BSDZDA_DZDAZZ  bsdzda_dzdazz

/* Internal variables */
#undef  BSDZDA_DZFAC
#define BSDZDA_DZFAC   bsdzda_dzfac

/* Declare internal variables */
      CCTK_REAL BSDZDA_DZFAC;

/* Declare output variables */
      CCTK_REAL BSDZDA_DZDAXX;
      CCTK_REAL BSDZDA_DZDAXY;
      CCTK_REAL BSDZDA_DZDAXZ;
      CCTK_REAL BSDZDA_DZDAYY;
      CCTK_REAL BSDZDA_DZDAYZ;
      CCTK_REAL BSDZDA_DZDAZZ;

#endif
