 /*@@
   @file      MoLRegister.c
   @date      Wed Jan  9 23:01:36 2002
   @author    
   @desc 
   Routine to register the variables with the MoL thorn.
   @enddesc 
 @@*/

#include "cctk.h"
#include "cctk_Arguments.h"
#include "cctk_Parameters.h"

#include "Slicing.h"

/* Prototypes */
void ADM_BSSN_MoLRegister(CCTK_ARGUMENTS);

 /*@@
   @routine    ADM_BSSN_MoLRegister
   @date       Wed Jan  9 23:15:19 2002
   @author     
   @desc 
   
   @enddesc 
   @calls     
   @calledby   
   @history 
 
   @endhistory 

@@*/

void ADM_BSSN_MoLRegister(CCTK_ARGUMENTS) 
{

  DECLARE_CCTK_ARGUMENTS
  DECLARE_CCTK_PARAMETERS

  int evolveK, evolveLapse, evolveShift, evolveGamma;

  int ierr = 0;

  if (forceKzero||freezeK) {
    evolveK = 0;
  }
  else {
    evolveK = 1;
  }

  if (freezeGamma) {
    evolveGamma = 0;
  }
  else {
    evolveGamma = 1;
  }
  
  if (CCTK_Equals(shift_evolution_method,"none")||CCTK_Equals(shift_evolution_method,"zero")||
      CCTK_Equals(shift_evolution_method,"static")||CCTK_Equals(shift_evolution_method,"locking")) {
    evolveShift = 0;
  }
  else if (CCTK_Equals(shift_evolution_method,"gamma0")||CCTK_Equals(shift_evolution_method,"gamma2")||
           CCTK_Equals(shift_evolution_method,"hyp_mindist")||
	   CCTK_Equals(shift_evolution_method,"dtlocking")||
	   CCTK_Equals(shift_evolution_method,"gammaS"))
  {
    evolveShift = 1;
  }
  else {
    evolveShift = 0;
  }
  
  if (*active_slicing_handle < 0)
  {
    CCTK_WARN (0, "No slicing is active");
  }
  if ((*active_slicing_handle==Einstein_GetSlicingHandle("1+log"))||
      (*active_slicing_handle==Einstein_GetSlicingHandle("harmonic"))) {
    evolveLapse = 1;
  }
  else {
    evolveLapse = 0;
  }
  
  /*
    The above variables are just a hack because they're all defined 
    in ADM_BSSN_Scalars which I can't use. Instead redefine here.
    Must fix this. 

    Especially note that the above forces the slicing to be unchanged
    over the evolution I think...
  */

  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_phi"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sphi"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_gxx"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sgxx"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_gxy"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sgxy"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_gxz"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sgxz"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_gyy"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sgyy"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_gyz"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sgyz"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_gzz"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sgzz"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Axx"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sAxx"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Axy"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sAxy"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Axz"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sAxz"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Ayy"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sAyy"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Ayz"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sAyz"));
  ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Azz"),
                          CCTK_VarIndex("adm_bssn::adm_bs_sAzz"));


  if (evolveK) {
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_K"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sK"));
  }
  
  if (evolveGamma) {
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Gx"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sGx"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Gy"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sGy"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Gz"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sGz"));
  }
  
  if (evolveLapse) {
    ierr += MoLRegisterEvolved(CCTK_VarIndex("admbase::alp"),
                            CCTK_VarIndex("adm_bssn::adm_bs_salp"));
    if ((evolveK)&&(CCTK_Equals(lapsesource,"modified")))
    {
      ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_dtalp"),
                              CCTK_VarIndex("adm_bssn::adm_bs_sdtalp"));
    }
  }
  else if ((*active_slicing_handle==Einstein_GetSlicingHandle("maximal"))
           ||(*active_slicing_handle==Einstein_GetSlicingHandle("static"))){
    /* This is a very nasty hack. Essentially the problem is that after 
       the first evolution step maximal will get the wrong lapse in the
       current timelevel every other step if registered as dependent.
       This kind of destroys the relevance of the dependent variables
       (but we'll keep them for the moment) and so we register the
       lapse as a primitive to ensure that maximal gets the same first
       guess that it always did. */
    ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::alp"));
  }
  else {
    ierr += MoLRegisterSaveAndRestore(CCTK_VarIndex("admbase::alp"));
  }  
    
  if (evolveShift)
  {
    ierr += MoLRegisterEvolved(CCTK_VarIndex("admbase::betax"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sbetax"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("admbase::betay"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sbetay"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("admbase::betaz"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sbetaz"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Bx"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sBx"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_By"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sBy"));
    ierr += MoLRegisterEvolved(CCTK_VarIndex("adm_bssn::ADM_BS_Bz"),
                            CCTK_VarIndex("adm_bssn::adm_bs_sBz"));

  }
  else if (CCTK_QueryGroupStorage(cctkGH,"admbase::shift")) {
    ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::betax"));
    ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::betay"));
    ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::betaz"));
  }
  
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::gxx"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::gxy"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::gxz"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::gyy"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::gyz"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::gzz"));

  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::kxx"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::kxy"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::kxz"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::kyy"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::kyz"));
  ierr += MoLRegisterConstrained(CCTK_VarIndex("admbase::kzz"));
  
  if (ierr) CCTK_WARN(0,"Problems registering variables with MoL");
}
