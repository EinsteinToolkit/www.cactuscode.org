/*@@
  @header   NABPHI_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef NABPHI_GUTS
#undef NABPHI_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/CDCDPHI_undefine.h"


