/*@@
  @header   LIEK_declare.h
  @date     August 2001
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef LIEK_DECLARE
#define LIEK_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_declare.h"

#undef  LIEK_LK
#define LIEK_LK liek_lk

      CCTK_REAL LIEK_LK

#endif
