/*@@
  @header   BSSTF_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the tracefree part of the BS matter
  variable S_ij using

    tracefree S_ij = S_ij - g_ij S / 3
 
  @enddesc
@@*/

#ifndef BSSTF_DECLARE
#define BSSTF_DECLARE

#include "macro/BSHYDRO_declare.h"
#include "macro/BSTRS_declare.h"

/* Internal variables */
#undef  BSSTF_PSIFAC
#define BSSTF_PSIFAC bsstf_psifac
#undef  BSSTF_PHIFAC
#define BSSTF_PHIFAC bsstf_phifac
#undef  BSSTF_TEMP
#define BSSTF_TEMP   bsstf_temp

/* Output variables */

#undef  BSSTF_SXX
#define BSSTF_SXX bsstf_sxx
#undef  BSSTF_SXY
#define BSSTF_SXY bsstf_sxy
#undef  BSSTF_SXZ
#define BSSTF_SXZ bsstf_sxz
#undef  BSSTF_SYY
#define BSSTF_SYY bsstf_syy
#undef  BSSTF_SYZ
#define BSSTF_SYZ bsstf_syz
#undef  BSSTF_SZZ
#define BSSTF_SZZ bsstf_szz

      CCTK_REAL BSSTF_PHIFAC
      CCTK_REAL BSSTF_PSIFAC
      CCTK_REAL BSSTF_TEMP

      CCTK_REAL BSSTF_SXX
      CCTK_REAL BSSTF_SXY
      CCTK_REAL BSSTF_SXZ
      CCTK_REAL BSSTF_SYY
      CCTK_REAL BSSTF_SYZ
      CCTK_REAL BSSTF_SZZ

#endif
