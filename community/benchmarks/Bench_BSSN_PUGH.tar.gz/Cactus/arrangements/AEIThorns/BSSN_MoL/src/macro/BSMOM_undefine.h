/*@@
  @header   BSMOM_undefine.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef BSMOM_GUTS
#undef BSMOM_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/DPHI_undefine.h"
#include "macro/DTRK_undefine.h"
#include "macro/DIVA_undefine.h"




  
