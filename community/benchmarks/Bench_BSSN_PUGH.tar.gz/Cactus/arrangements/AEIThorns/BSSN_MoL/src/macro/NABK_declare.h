/*@@
  @header   NABK_declare.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc

  @enddesc
@@*/

#ifndef NABK_DECLARE
#define NABK_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/CDCDK_declare.h"

/* Output variables */ 
#undef  NABK_NABK
#define NABK_NABK nabK_nabK

/* Declare output variables */
      CCTK_REAL NABK_NABK

#endif
