/*@@
  @header   DXYDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DXYDB_GUTS
#undef DXYDB_DECLARE


