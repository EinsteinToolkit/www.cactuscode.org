/*@@
  @header   RICCITF_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for the components of the tracefree Ricci tensor 
  Eq. 19 of the BS paper.
  @enddesc
@@*/

#ifndef RICCITF_DECLARE
#define RICCITF_DECLARE

#include "macro/BSRICCI_declare.h"
#include "macro/RICCIPHI_declare.h"
#include "macro/BSRICSCAL_declare.h"
#include "macro/TRAA_declare.h"
#include "macro/BSHYDRO_declare.h"

/* Internal variables */
#undef  RICCITF_PSIFAC
#define RICCITF_PSIFAC riccitf_psifac
#undef  RICCITF_PHIFAC
#define RICCITF_PHIFAC riccitf_phifac
#undef  RICCITF_TEMP 
#define RICCITF_TEMP riccitf_temp

      CCTK_REAL RICCITF_PSIFAC
      CCTK_REAL RICCITF_PHIFAC
      CCTK_REAL RICCITF_TEMP

/* Output variables */
#undef  RICCITF_RXX
#define RICCITF_RXX riccitf_Rxx
#undef  RICCITF_RXY
#define RICCITF_RXY riccitf_Rxy
#undef  RICCITF_RXZ
#define RICCITF_RXZ riccitf_Rxz
#undef  RICCITF_RYY
#define RICCITF_RYY riccitf_Ryy
#undef  RICCITF_RYZ
#define RICCITF_RYZ riccitf_Ryz
#undef  RICCITF_RZZ
#define RICCITF_RZZ riccitf_Rzz

      CCTK_REAL RICCITF_RXX
      CCTK_REAL RICCITF_RXY
      CCTK_REAL RICCITF_RXZ
      CCTK_REAL RICCITF_RYY
      CCTK_REAL RICCITF_RYZ
      CCTK_REAL RICCITF_RZZ

#endif
