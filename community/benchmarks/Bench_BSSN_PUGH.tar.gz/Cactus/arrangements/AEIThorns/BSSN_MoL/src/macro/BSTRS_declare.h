/*@@
  @header   BSTRS_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the trace of the BS matter variable
  Sij, note that it uses the definition of Sij in Eq 8
  to do this
  scheme
  @enddesc
@@*/

#ifndef BSTRS_DECLARE
#define BSTRS_DECLARE

/* This gives the Tmunus */

#include "macro/BSUPPERMET_declare.h"
#include "macro/BSHYDRO_declare.h"

#undef  BSTRS_TRS
#define BSTRS_TRS bstrs_trs

      CCTK_REAL BSTRS_TRS

#endif
