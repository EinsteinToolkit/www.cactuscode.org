/*@@
  @header   DYZDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DYZDB_GUTS
#define DYZDB_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        DYZDB_DYZDBX = BSSN_DYZ_2(betax,i,j,k)
        DYZDB_DYZDBY = BSSN_DYZ_2(betay,i,j,k)
        DYZDB_DYZDBZ = BSSN_DYZ_2(betaz,i,j,k)
      else
        DYZDB_DYZDBX = BSSN_DYZ_4(betax,i,j,k)
        DYZDB_DYZDBY = BSSN_DYZ_4(betay,i,j,k)
        DYZDB_DYZDBZ = BSSN_DYZ_4(betaz,i,j,k)
      end if

#endif
