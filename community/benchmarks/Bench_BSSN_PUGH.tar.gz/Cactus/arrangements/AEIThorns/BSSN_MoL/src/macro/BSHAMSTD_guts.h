/*@@
  @header   BSHAMSTD_guts.h
  @date     23 May 2002
  @author   Denis Pollney
  @desc
  Macro to calculate the Hamiltonian constraint via YS2.25

       R - ~A_{ij} ~A^{ij} + 2/3 (K^2 - tr~A K)

  Note that this formula explicitly includes the trA term, which
  is zero when the trace-free nature of A_{ij} is satisfied or
  enforced.

  @enddesc
@@*/

#ifndef BSHAMSTD_GUTS
#define BSHAMSTD_GUTS

#include "TRAA_guts.h"
#include "CactusEinstein/ADMMacros/src/macro/TRK_guts.h"
#include "BSRICSCAL_guts.h"

      BSHAMSTD_HAM = BSRICSCAL_R - TRAA_TRAA +
     +  (2.D0/3.D0) * (TRK_TRK*TRK_TRK - constraint_A(i,j,k) * TRK_TRK)
      BSHAMSTD_ABSHAM = abs(BSRICSCAL_R) - abs(TRAA_TRAA) +
     +  abs((2.D0/3.D0) * (TRK_TRK*TRK_TRK - constraint_A(i,j,k) * TRK_TRK))

#endif
