/*@@
  @header   BSDZDG_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the first derivatives of the 
  BS metric with respect to x
  @enddesc
@@*/

#include "macro/BSSN_Derivative.h"

#ifndef BSDZDG_GUTS
#define BSDZDG_GUTS
      if (local_spatial_order.eq.2) then
        BSDZDG_DZDGXX = BSSN_DZ_2(ADM_BS_gxx,i,j,k)
        BSDZDG_DZDGXY = BSSN_DZ_2(ADM_BS_gxy,i,j,k)
        BSDZDG_DZDGXZ = BSSN_DZ_2(ADM_BS_gxz,i,j,k)
        BSDZDG_DZDGYY = BSSN_DZ_2(ADM_BS_gyy,i,j,k)
        BSDZDG_DZDGYZ = BSSN_DZ_2(ADM_BS_gyz,i,j,k)
        BSDZDG_DZDGZZ = BSSN_DZ_2(ADM_BS_gzz,i,j,k)
      else
        BSDZDG_DZDGXX = BSSN_DZ_4(ADM_BS_gxx,i,j,k)
        BSDZDG_DZDGXY = BSSN_DZ_4(ADM_BS_gxy,i,j,k)
        BSDZDG_DZDGXZ = BSSN_DZ_4(ADM_BS_gxz,i,j,k)
        BSDZDG_DZDGYY = BSSN_DZ_4(ADM_BS_gyy,i,j,k)
        BSDZDG_DZDGYZ = BSSN_DZ_4(ADM_BS_gyz,i,j,k)
        BSDZDG_DZDGZZ = BSSN_DZ_4(ADM_BS_gzz,i,j,k)
      end if
#endif
