/*@@
  @header   BSDXDG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef BSDXDG_GUTS
#undef BSDXDG_DECLARE


