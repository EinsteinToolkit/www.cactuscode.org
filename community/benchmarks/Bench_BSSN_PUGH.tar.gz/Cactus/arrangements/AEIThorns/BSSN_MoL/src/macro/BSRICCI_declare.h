/*@@
  @header   BSRICCI_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for the components of the Ricci tensor using the BS 
  variables and Eq. 22 of the BS paper. 

  @enddesc
@@*/


#ifndef BSRICCI_DECLARE
#define BSRICCI_DECLARE

#include "macro/BSCHR1_declare.h"
#include "macro/BSCHR2_declare.h"
#include "macro/WAVEBSG_declare.h"
#include "macro/BSGAMMA_declare.h"

#undef  BSRICCI_DXGX
#define BSRICCI_DXGX bsricci_dxgx
#undef  BSRICCI_DXGY
#define BSRICCI_DXGY bsricci_dxgy
#undef  BSRICCI_DXGZ
#define BSRICCI_DXGZ bsricci_dxgz
#undef  BSRICCI_DYGX
#define BSRICCI_DYGX bsricci_dygx
#undef  BSRICCI_DYGY
#define BSRICCI_DYGY bsricci_dygy
#undef  BSRICCI_DYGZ
#define BSRICCI_DYGZ bsricci_dygz
#undef  BSRICCI_DZGX
#define BSRICCI_DZGX bsricci_dzgx
#undef  BSRICCI_DZGY
#define BSRICCI_DZGY bsricci_dzgy
#undef  BSRICCI_DZGZ
#define BSRICCI_DZGZ bsricci_dzgz

#undef  BSRICCI_TERM1
#define BSRICCI_TERM1 bsricci_term1
#undef  BSRICCI_TERM2
#define BSRICCI_TERM2 bsricci_term2
#undef  BSRICCI_TERM3
#define BSRICCI_TERM3 bsricci_term3
#undef  BSRICCI_TERM4A
#define BSRICCI_TERM4A bsricci_term4a
#undef  BSRICCI_TERM4B
#define BSRICCI_TERM4B bsricci_term4b
#undef  BSRICCI_TERM5
#define BSRICCI_TERM5 bsricci_term5

#undef  BSRICCI_RXX
#define BSRICCI_RXX bsricci_Rxx
#undef  BSRICCI_RXY
#define BSRICCI_RXY bsricci_Rxy
#undef  BSRICCI_RXZ
#define BSRICCI_RXZ bsricci_Rxz
#undef  BSRICCI_RYY
#define BSRICCI_RYY bsricci_Ryy
#undef  BSRICCI_RYZ
#define BSRICCI_RYZ bsricci_Ryz
#undef  BSRICCI_RZZ
#define BSRICCI_RZZ bsricci_Rzz

      CCTK_REAL BSRICCI_DXGX
      CCTK_REAL BSRICCI_DXGY
      CCTK_REAL BSRICCI_DXGZ
      CCTK_REAL BSRICCI_DYGX
      CCTK_REAL BSRICCI_DYGY
      CCTK_REAL BSRICCI_DYGZ
      CCTK_REAL BSRICCI_DZGX
      CCTK_REAL BSRICCI_DZGY
      CCTK_REAL BSRICCI_DZGZ

      CCTK_REAL BSRICCI_TERM1
      CCTK_REAL BSRICCI_TERM2
      CCTK_REAL BSRICCI_TERM3
      CCTK_REAL BSRICCI_TERM4A
      CCTK_REAL BSRICCI_TERM4B
      CCTK_REAL BSRICCI_TERM5

      CCTK_REAL BSRICCI_RXX
      CCTK_REAL BSRICCI_RXY
      CCTK_REAL BSRICCI_RXZ
      CCTK_REAL BSRICCI_RYY
      CCTK_REAL BSRICCI_RYZ
      CCTK_REAL BSRICCI_RZZ

      CCTK_REAL BSRICCI_GX
      CCTK_REAL BSRICCI_GY
      CCTK_REAL BSRICCI_GZ

#endif
