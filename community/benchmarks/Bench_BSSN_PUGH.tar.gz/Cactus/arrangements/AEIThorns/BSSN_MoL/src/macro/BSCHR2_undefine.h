/*@@
  @header   BSCHR2_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef BSCHR2_GUTS
#undef BSCHR2_DECLARE

#include "macro/BSCHR1_undefine.h"
#include "macro/BSUPPERMET_undefine.h"

