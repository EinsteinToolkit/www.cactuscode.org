/*@@
  @header   BSDYDG_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the first derivatives of the 
  BS metric with respect to x
  @enddesc
@@*/

#ifndef BSDYDG_GUTS
#define BSDYDG_GUTS

#include "macro/BSSN_Derivative.h"

      if (local_spatial_order.eq.2) then
        BSDYDG_DYDGXX = BSSN_DY_2(ADM_BS_gxx,i,j,k)
        BSDYDG_DYDGXY = BSSN_DY_2(ADM_BS_gxy,i,j,k)
        BSDYDG_DYDGXZ = BSSN_DY_2(ADM_BS_gxz,i,j,k)
        BSDYDG_DYDGYY = BSSN_DY_2(ADM_BS_gyy,i,j,k)
        BSDYDG_DYDGYZ = BSSN_DY_2(ADM_BS_gyz,i,j,k)
        BSDYDG_DYDGZZ = BSSN_DY_2(ADM_BS_gzz,i,j,k)
      else
        BSDYDG_DYDGXX = BSSN_DY_4(ADM_BS_gxx,i,j,k)
        BSDYDG_DYDGXY = BSSN_DY_4(ADM_BS_gxy,i,j,k)
        BSDYDG_DYDGXZ = BSSN_DY_4(ADM_BS_gxz,i,j,k)
        BSDYDG_DYDGYY = BSSN_DY_4(ADM_BS_gyy,i,j,k)
        BSDYDG_DYDGYZ = BSSN_DY_4(ADM_BS_gyz,i,j,k)
        BSDYDG_DYDGZZ = BSSN_DY_4(ADM_BS_gzz,i,j,k)
      end if   
#endif

