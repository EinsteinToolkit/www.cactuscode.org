/*@@
  @header   CDCDALPHA_declare.h
  @date     October 99
  @author   Miguel Alcubierre
  @desc

  @enddesc
@@*/

#ifndef CDCDALPHA_DECLARE
#define CDCDALPHA_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DA_declare.h"
#include "CactusEinstein/ADMMacros/src/macro/DDA_declare.h"
#include "DPHI_declare.h"
#include "BSUPPERMET_declare.h"
#include "BSCHR2_declare.h"

/* Input variables */
#ifdef OPT

#undef  CDCDALPHA_GXX
#define CDCDALPHA_GXX lg(XX,i,j,kc)
#undef  CDCDALPHA_GXY
#define CDCDALPHA_GXY lg(XY,i,j,kc)
#undef  CDCDALPHA_GXZ
#define CDCDALPHA_GXZ lg(XZ,i,j,kc)
#undef  CDCDALPHA_GYY
#define CDCDALPHA_GYY lg(YY,i,j,kc)
#undef  CDCDALPHA_GYZ
#define CDCDALPHA_GYZ lg(YZ,i,j,kc)
#undef  CDCDALPHA_GZZ
#define CDCDALPHA_GZZ lg(ZZ,i,j,kc)

#else

#undef  CDCDALPHA_GXX
#define CDCDALPHA_GXX ADM_BS_gxx(i,j,k)
#undef  CDCDALPHA_GXY
#define CDCDALPHA_GXY ADM_BS_gxy(i,j,k)
#undef  CDCDALPHA_GXZ
#define CDCDALPHA_GXZ ADM_BS_gxz(i,j,k)
#undef  CDCDALPHA_GYY
#define CDCDALPHA_GYY ADM_BS_gyy(i,j,k)
#undef  CDCDALPHA_GYZ
#define CDCDALPHA_GYZ ADM_BS_gyz(i,j,k)
#undef  CDCDALPHA_GZZ
#define CDCDALPHA_GZZ ADM_BS_gzz(i,j,k)

#endif

/* Internal variables */
#undef  CDCDALPHA_TEMP 
#define CDCDALPHA_TEMP cdcdalpha_temp

      CCTK_REAL CDCDALPHA_TEMP

/* Output variables */ 
#undef  CDCDALPHA_CDXXDALPHA
#define CDCDALPHA_CDXXDALPHA cdcdalpha_cdxxdalpha
#undef  CDCDALPHA_CDXYDALPHA
#define CDCDALPHA_CDXYDALPHA cdcdalpha_cdxydalpha
#undef  CDCDALPHA_CDXZDALPHA
#define CDCDALPHA_CDXZDALPHA cdcdalpha_cdxzdalpha
#undef  CDCDALPHA_CDYYDALPHA
#define CDCDALPHA_CDYYDALPHA cdcdalpha_cdyydalpha
#undef  CDCDALPHA_CDYZDALPHA
#define CDCDALPHA_CDYZDALPHA cdcdalpha_cdyzdalpha
#undef  CDCDALPHA_CDZZDALPHA
#define CDCDALPHA_CDZZDALPHA cdcdalpha_cdzzdalpha

#undef  CDCDALPHA_CDXXDALPHA_PHYS
#define CDCDALPHA_CDXXDALPHA_PHYS cdcdalpha_cdxxdalpha_phys
#undef  CDCDALPHA_CDXYDALPHA_PHYS
#define CDCDALPHA_CDXYDALPHA_PHYS cdcdalpha_cdxydalpha_phys
#undef  CDCDALPHA_CDXZDALPHA_PHYS
#define CDCDALPHA_CDXZDALPHA_PHYS cdcdalpha_cdxzdalpha_phys
#undef  CDCDALPHA_CDYYDALPHA_PHYS
#define CDCDALPHA_CDYYDALPHA_PHYS cdcdalpha_cdyydalpha_phys
#undef  CDCDALPHA_CDYZDALPHA_PHYS
#define CDCDALPHA_CDYZDALPHA_PHYS cdcdalpha_cdyzdalpha_phys
#undef  CDCDALPHA_CDZZDALPHA_PHYS
#define CDCDALPHA_CDZZDALPHA_PHYS cdcdalpha_cdzzdalpha_phys

      CCTK_REAL CDCDALPHA_CDXXDALPHA
      CCTK_REAL CDCDALPHA_CDXYDALPHA
      CCTK_REAL CDCDALPHA_CDXZDALPHA
      CCTK_REAL CDCDALPHA_CDYYDALPHA
      CCTK_REAL CDCDALPHA_CDYZDALPHA
      CCTK_REAL CDCDALPHA_CDZZDALPHA

      CCTK_REAL CDCDALPHA_CDXXDALPHA_PHYS
      CCTK_REAL CDCDALPHA_CDXYDALPHA_PHYS
      CCTK_REAL CDCDALPHA_CDXZDALPHA_PHYS
      CCTK_REAL CDCDALPHA_CDYYDALPHA_PHYS
      CCTK_REAL CDCDALPHA_CDYZDALPHA_PHYS
      CCTK_REAL CDCDALPHA_CDZZDALPHA_PHYS

#endif

