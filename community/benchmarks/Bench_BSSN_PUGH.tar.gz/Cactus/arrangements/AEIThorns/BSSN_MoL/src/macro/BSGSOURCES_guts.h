#ifndef BSGSOURCES_GUTS
#define BSGSOURCES_GUTS

      BSGSOURCES_TEMP = - 2.0d0*alp(i,j,k)
#ifdef OPT
      adm_bs_sgxx(i,j,k) = BSGSOURCES_TEMP*lA(XX,i,j,kc)
      adm_bs_sgxy(i,j,k) = BSGSOURCES_TEMP*lA(XY,i,j,kc)
      adm_bs_sgxz(i,j,k) = BSGSOURCES_TEMP*lA(XZ,i,j,kc)
      adm_bs_sgyy(i,j,k) = BSGSOURCES_TEMP*lA(YY,i,j,kc)
      adm_bs_sgyz(i,j,k) = BSGSOURCES_TEMP*lA(YZ,i,j,kc)
      adm_bs_sgzz(i,j,k) = BSGSOURCES_TEMP*lA(ZZ,i,j,kc)
#else
      adm_bs_sgxx(i,j,k) = BSGSOURCES_TEMP*ADM_BS_Axx(i,j,k)
      adm_bs_sgxy(i,j,k) = BSGSOURCES_TEMP*ADM_BS_Axy(i,j,k)
      adm_bs_sgxz(i,j,k) = BSGSOURCES_TEMP*ADM_BS_Axz(i,j,k)
      adm_bs_sgyy(i,j,k) = BSGSOURCES_TEMP*ADM_BS_Ayy(i,j,k)
      adm_bs_sgyz(i,j,k) = BSGSOURCES_TEMP*ADM_BS_Ayz(i,j,k)
      adm_bs_sgzz(i,j,k) = BSGSOURCES_TEMP*ADM_BS_Azz(i,j,k)
#endif

#endif
