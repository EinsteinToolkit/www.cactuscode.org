/*@@
  @header   GAMMAMINDIS_declare.h
  @date     February 2001
  @author   Miguel Alcubierre
  @desc
    Macro for source term of the BS Gamma evolution equation
    when using a minimal distortion shift vector.
  @enddesc
@@*/

#ifndef GAMMAMINDIS_DECLARE
#define GAMMAMINDIS_DECLARE

#include "macro/BSCHR2_declare.h"
#include "macro/DPHI_declare.h"
#include "macro/BSUPPERMET_declare.h"

#undef  GAMMAMINDIS_SOURCEX
#define GAMMAMINDIS_SOURCEX gammamindis_sourcex
#undef  GAMMAMINDIS_SOURCEY
#define GAMMAMINDIS_SOURCEY gammamindis_sourcey
#undef  GAMMAMINDIS_SOURCEZ
#define GAMMAMINDIS_SOURCEZ gammamindis_sourcez

#undef  GAMMAMINDIS_DTUPPERGXX
#define GAMMAMINDIS_DTUPPERGXX gammamindis_dtuppergxx
#undef  GAMMAMINDIS_DTUPPERGYY
#define GAMMAMINDIS_DTUPPERGYY gammamindis_dtuppergyy
#undef  GAMMAMINDIS_DTUPPERGZZ
#define GAMMAMINDIS_DTUPPERGZZ gammamindis_dtuppergzz
#undef  GAMMAMINDIS_DTUPPERGXY
#define GAMMAMINDIS_DTUPPERGXY gammamindis_dtuppergxy
#undef  GAMMAMINDIS_DTUPPERGXZ
#define GAMMAMINDIS_DTUPPERGXZ gammamindis_dtuppergxz
#undef  GAMMAMINDIS_DTUPPERGYZ
#define GAMMAMINDIS_DTUPPERGYz gammamindis_dtuppergyz

#undef  GAMMAMINDIS_TERM1
#define GAMMAMINDIS_TERM1 gammamindis_term1
#undef  GAMMAMINDIS_TERM2
#define GAMMAMINDIS_TERM2 gammamindis_term2

      CCTK_REAL GAMMAMINDIS_SOURCEX
      CCTK_REAL GAMMAMINDIS_SOURCEY
      CCTK_REAL GAMMAMINDIS_SOURCEZ

      CCTK_REAL GAMMAMINDIS_DTUPPERGXX
      CCTK_REAL GAMMAMINDIS_DTUPPERGYY
      CCTK_REAL GAMMAMINDIS_DTUPPERGZZ
      CCTK_REAL GAMMAMINDIS_DTUPPERGXY
      CCTK_REAL GAMMAMINDIS_DTUPPERGXZ
      CCTK_REAL GAMMAMINDIS_DTUPPERGYZ

      CCTK_REAL GAMMAMINDIS_TERM1
      CCTK_REAL GAMMAMINDIS_TERM2

#endif











