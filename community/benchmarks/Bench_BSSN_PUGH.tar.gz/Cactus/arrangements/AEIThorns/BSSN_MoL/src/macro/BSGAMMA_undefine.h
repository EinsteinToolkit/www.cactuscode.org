/*@@
  @header   BSGAMMA_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef BSGAMMA_GUTS
#undef BSGAMMA_DECLARE

#ifdef USE_INVERSE

#else

#include "macro/BSCHR2_undefine.h"
#include "macro/BSUPPERMET_undefine.h"

#endif
