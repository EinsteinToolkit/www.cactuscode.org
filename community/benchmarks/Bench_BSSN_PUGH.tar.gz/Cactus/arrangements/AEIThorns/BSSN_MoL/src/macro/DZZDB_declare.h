/*@@
  @header   DZZDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DZZDB_DECLARE
#define DZZDB_DECLARE

/* Input variables */

#undef  DZZDB_BX   
#define DZZDB_BX   betax(i,j,k)
#undef  DZZDB_BY   
#define DZZDB_BY   betay(i,j,k)
#undef  DZZDB_BZ  
#define DZZDB_BZ   betaz(i,j,k)

#undef  DZZDB_BX_KP   
#define DZZDB_BX_KP   betax(i,j,k+1)
#undef  DZZDB_BY_KP   
#define DZZDB_BY_KP   betay(i,j,k+1)
#undef  DZZDB_BZ_KP  
#define DZZDB_BZ_KP   betaz(i,j,k+1)

#undef  DZZDB_BX_KM   
#define DZZDB_BX_KM   betax(i,j,k-1)
#undef  DZZDB_BY_KM   
#define DZZDB_BY_KM   betay(i,j,k-1)
#undef  DZZDB_BZ_KM  
#define DZZDB_BZ_KM   betaz(i,j,k-1)

/* Internal variables */

#undef  DZZDB_TEMP
#define DZZDB_TEMP  dzzdb_temp

/* Output variables */ 

#undef  DZZDB_DZZDBX
#define DZZDB_DZZDBX  dzzdb_dzzdbx
#undef  DZZDB_DZZDBY
#define DZZDB_DZZDBY  dzzdb_dzzdby
#undef  DZZDB_DZZDBZ
#define DZZDB_DZZDBZ  dzzdb_dzzdbz

/* Declare variables */

      CCTK_REAL DZZDB_TEMP
      CCTK_REAL DZZDB_DZZDBX
      CCTK_REAL DZZDB_DZZDBY
      CCTK_REAL DZZDB_DZZDBZ

#endif
