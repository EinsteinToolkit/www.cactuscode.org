/*@@
  @header   NABALPHA_declare.h
  @date     October 99
  @author   Miguel Alcubierre
  @desc

  @enddesc
@@*/

#ifndef NABALPHA_DECLARE
#define NABALPHA_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/CDCDALPHA_declare.h"

/* Output variables */ 
#undef  NABALPHA_NABALPHA
#define NABALPHA_NABALPHA nabALPHA_nabALPHA

#undef  NABALPHA_NABALPHA_PHYS
#define NABALPHA_NABALPHA_PHYS nabALPHA_nabALPHA_PHYS

/* Declare output variables */
      CCTK_REAL NABALPHA_NABALPHA
      CCTK_REAL NABALPHA_NABALPHA_PHYS

#endif
