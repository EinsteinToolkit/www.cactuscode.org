/*@@
  @header   LIEBSG_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef LIEBSG_DECLARE
#define LIEBSG_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_declare.h"

#ifdef OPT

#undef  LIEBSG_GXX
#define LIEBSG_GXX lg(XX,i,j,kc)
#undef  LIEBSG_GXY
#define LIEBSG_GXY lg(XY,i,j,kc)
#undef  LIEBSG_GXZ
#define LIEBSG_GXZ lg(XZ,i,j,kc)
#undef  LIEBSG_GYY
#define LIEBSG_GYY lg(YY,i,j,kc)
#undef  LIEBSG_GYZ
#define LIEBSG_GYZ lg(YZ,i,j,kc)
#undef  LIEBSG_GZZ
#define LIEBSG_GZZ lg(ZZ,i,j,kc)

#else

#undef  LIEBSG_GXX
#define LIEBSG_GXX ADM_BS_gxx(i,j,k)
#undef  LIEBSG_GXY
#define LIEBSG_GXY ADM_BS_gxy(i,j,k)
#undef  LIEBSG_GXZ
#define LIEBSG_GXZ ADM_BS_gxz(i,j,k)
#undef  LIEBSG_GYY
#define LIEBSG_GYY ADM_BS_gyy(i,j,k)
#undef  LIEBSG_GYZ
#define LIEBSG_GYZ ADM_BS_gyz(i,j,k)
#undef  LIEBSG_GZZ
#define LIEBSG_GZZ ADM_BS_gzz(i,j,k)

#endif

#undef  LIEBSG_LGXX
#define LIEBSG_LGXX liebsg_lgxx
#undef  LIEBSG_LGXY
#define LIEBSG_LGXY liebsg_lgxy
#undef  LIEBSG_LGXZ
#define LIEBSG_LGXZ liebsg_lgxz
#undef  LIEBSG_LGYY
#define LIEBSG_LGYY liebsg_lgyy
#undef  LIEBSG_LGYZ
#define LIEBSG_LGYZ liebsg_lgyz
#undef  LIEBSG_LGZZ
#define LIEBSG_LGZZ liebsg_lgzz

#undef  LIEBSG_TEMP
#define LIEBSG_TEMP liebsg_temp

      CCTK_REAL LIEBSG_LGXX
      CCTK_REAL LIEBSG_LGXY
      CCTK_REAL LIEBSG_LGXZ
      CCTK_REAL LIEBSG_LGYY
      CCTK_REAL LIEBSG_LGYZ
      CCTK_REAL LIEBSG_LGZZ

      CCTK_REAL LIEBSG_TEMP

#endif
