/*@@
  @header   NABK_guts.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  Macro to calculate the nabla operator acting on K .
  @enddesc
@@*/

#ifndef NABK_GUTS
#define NABK_GUTS

#include "macro/BSUPPERMET_guts.h"
#include "macro/CDCDK_guts.h"

      NABK_NABK = BSUPPERMET_UXX*CDCDK_CDXXDK
     &          + BSUPPERMET_UYY*CDCDK_CDYYDK
     &          + BSUPPERMET_UZZ*CDCDK_CDZZDK
     &          +(BSUPPERMET_UXY*CDCDK_CDXYDK
     &          + BSUPPERMET_UXZ*CDCDK_CDXZDK
     &          + BSUPPERMET_UYZ*CDCDK_CDYZDK)*2.0d0

#endif

