/*@@
  @header   DPHI_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all first spatial derivative of BS conformal phi
  @enddesc
@@*/

#undef DPHI_GUTS
#undef DPHI_DECLARE



