/*@@
  @header   BSDG_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc

  Declarations for macro to calculate all the first derivatives of the 
  BS metric with respect to x, y, z.

  @enddesc
@@*/

#ifndef BSDG_DECLARE
#define BSDG_DECLARE

#include "macro/BSDXDG_declare.h"
#include "macro/BSDYDG_declare.h"
#include "macro/BSDZDG_declare.h"

#endif
