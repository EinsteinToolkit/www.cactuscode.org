/*@@
  @header   BSRICCI_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to the components of the Ricci tensor using the BS 
  variables and Eq. 22 of the BS paper. 

  @enddesc
@@*/

#undef BSRICCI_GUTS
#undef BSRICCI_DECLARE

#include "macro/BSCHR1_undefine.h"
#include "macro/BSCHR2_undefine.h"
#include "macro/WAVEBSG_undefine.h"
#include "macro/BSGAMMA_undefine.h"
