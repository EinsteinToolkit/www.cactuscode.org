
#ifndef ALPSOURCES_GUTS
#define ALPSOURCES_GUTS


c     All terms needed in the lapse source term have been
c     calculated before since the lapse source term is just
c     proportional to the source term of phi.  All that is
c     left to do here is add the dissipation terms.


/* Add dissipation terms */
/* --------------------- */

      if (flatNablaAlpCoeff.ne.0.0d0) then
#include "CactusEinstein/ADMMacros/src/macro/DDA_guts.h"
         adm_bs_salp(i,j,k) = adm_bs_salp(i,j,k)
     &      + flatNablaAlpCoeff*(DDA_DXXDA+DDA_DYYDA+DDA_DZZDA)
#include "CactusEinstein/ADMMacros/src/macro/DDA_undefine.h"
      end if

      if (nablaAlpCoeff.ne.0.0d0) then
#include "macro/NABALPHA_guts.h"
         adm_bs_salp(i,j,k) = adm_bs_salp(i,j,k)
     &      + nablaAlpCoeff*NABALPHA_NABALPHA_PHYS
#include "macro/NABALPHA_undefine.h"
      end if

#endif
