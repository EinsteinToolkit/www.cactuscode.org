/*@@
  @header   DTRK_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all first spatial derivative of BS variable trk
  @enddesc
@@*/

#ifndef DTRK_GUTS
#define DTRK_GUTS

#ifdef FCODE 

#include "macro/BSSN_Derivative.h"

      if (local_spatial_order.eq.2) then
        DTRK_DXDTRK = BSSN_DX_2(ADM_BS_K,i,j,k)
        DTRK_DYDTRK = BSSN_DY_2(ADM_BS_K,i,j,k)
        DTRK_DZDTRK = BSSN_DZ_2(ADM_BS_K,i,j,k)
      else
        DTRK_DXDTRK = BSSN_DX_4(ADM_BS_K,i,j,k)
        DTRK_DYDTRK = BSSN_DY_4(ADM_BS_K,i,j,k)
        DTRK_DZDTRK = BSSN_DZ_4(ADM_BS_K,i,j,k)
      end if

#endif

#ifdef CCODE

      DTRK_OO2DX = 1/(2D0*DTRK_DX);
      DTRK_OO2DY = 1/(2D0*DTRK_DY);
      DTRK_OO2DZ = 1/(2D0*DTRK_DZ);

      DTRK_DXDTRK = DTRK_OO2DX*(DTRK_TRK_IP - DTRK_TRK_IM);
      DTRK_DYDTRK = DTRK_OO2DY*(DTRK_TRK_JP - DTRK_TRK_JM);
      DTRK_DZDTRK = DTRK_OO2DZ*(DTRK_TRK_KP - DTRK_TRK_KM);

#endif

#endif
