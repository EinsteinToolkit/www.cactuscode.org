/*@@
  @header   BSHAMSTD_undefine.h
  @date     23 May 2002
  @author   Denis Pollney
  @desc
  Macro to calculate the spacetime part of the 
  Hamiltonian Constraint. That is:

       R - K^i_j K^j_i + trK^2 

  @enddesc
@@*/

#undef BSHAMSTD_GUTS
#undef BSHAMSTD_DECLARE

#include "TRAA_undefine.h"
#include "CactusEinstein/ADMMacros/src/macro/TRK_undefine.h"
#include "BSRICSCAL_undefine.h"
