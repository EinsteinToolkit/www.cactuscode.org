/*@@
  @header   UPPERA_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to the upper components of the BS conformal TF variable A
  (using the conformal metric)

  @enddesc
@@*/

#ifndef UPPERA_GUTS
#define UPPERA_GUTS

#include "BSUPPERMET_guts.h"

#ifdef OPT
      UPPERA_AXX = BSUPPERMET_UXX**2*lA(XX,i,j,kc)
     &           + BSUPPERMET_UXY**2*lA(YY,i,j,kc)
     &           + BSUPPERMET_UXZ**2*lA(ZZ,i,j,kc)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UXY*lA(XY,i,j,kc)
     &           + BSUPPERMET_UXX*BSUPPERMET_UXZ*lA(XZ,i,j,kc)
     &           + BSUPPERMET_UXY*BSUPPERMET_UXZ*lA(YZ,i,j,kc))*2.0d0

      UPPERA_AYY = BSUPPERMET_UXY**2*lA(XX,i,j,kc)
     &           + BSUPPERMET_UYY**2*lA(YY,i,j,kc)
     &           + BSUPPERMET_UYZ**2*lA(ZZ,i,j,kc)
     &           +(BSUPPERMET_UXY*BSUPPERMET_UYY*lA(XY,i,j,kc)
     &           + BSUPPERMET_UYZ*BSUPPERMET_UXY*lA(XZ,i,j,kc)
     &           + BSUPPERMET_UYZ*BSUPPERMET_UYY*lA(YZ,i,j,kc))*2.0d0

      UPPERA_AZZ = BSUPPERMET_UXZ**2*lA(XX,i,j,kc)
     &           + BSUPPERMET_UYZ**2*lA(YY,i,j,kc)
     &           + BSUPPERMET_UZZ**2*lA(ZZ,i,j,kc)
     &           +(BSUPPERMET_UZX*BSUPPERMET_UZY*lA(XY,i,j,kc)
     &           + BSUPPERMET_UZX*BSUPPERMET_UZZ*lA(XZ,i,j,kc)
     &           + BSUPPERMET_UZY*BSUPPERMET_UZZ*lA(YZ,i,j,kc))*2.0d0

      UPPERA_AXY = BSUPPERMET_UXX*BSUPPERMET_UYX*lA(XX,i,j,kc)
     &           + BSUPPERMET_UXY*BSUPPERMET_UYY*lA(YY,i,j,kc)
     &           + BSUPPERMET_UXZ*BSUPPERMET_UYZ*lA(ZZ,i,j,kc)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UYY
     &           + BSUPPERMET_UXY*BSUPPERMET_UYX)*lA(XY,i,j,kc)
     &           +(BSUPPERMET_UXZ*BSUPPERMET_UYX
     &           + BSUPPERMET_UXX*BSUPPERMET_UYZ)*lA(XZ,i,j,kc)
     &           +(BSUPPERMET_UXZ*BSUPPERMET_UYY
     &            +BSUPPERMET_UXY*BSUPPERMET_UYZ)*lA(YZ,i,j,kc)

      UPPERA_AXZ = BSUPPERMET_UXX*BSUPPERMET_UZX*lA(XX,i,j,kc)
     &           + BSUPPERMET_UXY*BSUPPERMET_UZY*lA(YY,i,j,kc)
     &           + BSUPPERMET_UXZ*BSUPPERMET_UZZ*lA(ZZ,i,j,kc)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UZY
     &           + BSUPPERMET_UXY*BSUPPERMET_UZX)*lA(XY,i,j,kc)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UZZ
     &           + BSUPPERMET_UXZ*BSUPPERMET_UZX)*lA(XZ,i,j,kc)
     &           +(BSUPPERMET_UXY*BSUPPERMET_UZZ
     &           + BSUPPERMET_UXZ*BSUPPERMET_UZY)*lA(YZ,i,j,kc)

      UPPERA_AYZ = BSUPPERMET_UYX*BSUPPERMET_UZX*lA(XX,i,j,kc)
     &           + BSUPPERMET_UYY*BSUPPERMET_UZY*lA(YY,i,j,kc)
     &           + BSUPPERMET_UYZ*BSUPPERMET_UZZ*lA(ZZ,i,j,kc)
     &           +(BSUPPERMET_UYX*BSUPPERMET_UZY
     &           + BSUPPERMET_UYY*BSUPPERMET_UZX)*lA(XY,i,j,kc)
     &           +(BSUPPERMET_UYX*BSUPPERMET_UZZ
     &           + BSUPPERMET_UYZ*BSUPPERMET_UZX)*lA(XZ,i,j,kc)
     &           +(BSUPPERMET_UYY*BSUPPERMET_UZZ
     &           + BSUPPERMET_UYZ*BSUPPERMET_UZY)*lA(YZ,i,j,kc)

#else

      UPPERA_AXX = BSUPPERMET_UXX**2*ADM_BS_Axx(i,j,k)
     &           + BSUPPERMET_UXY**2*ADM_BS_Ayy(i,j,k)
     &           + BSUPPERMET_UXZ**2*ADM_BS_Azz(i,j,k)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UXY*ADM_BS_Axy(i,j,k)
     &           + BSUPPERMET_UXX*BSUPPERMET_UXZ*ADM_BS_Axz(i,j,k)
     &           + BSUPPERMET_UXY*BSUPPERMET_UXZ*ADM_BS_Ayz(i,j,k))*2.0d0

      UPPERA_AYY = BSUPPERMET_UXY**2*ADM_BS_Axx(i,j,k)
     &           + BSUPPERMET_UYY**2*ADM_BS_Ayy(i,j,k)
     &           + BSUPPERMET_UYZ**2*ADM_BS_Azz(i,j,k)
     &           +(BSUPPERMET_UXY*BSUPPERMET_UYY*ADM_BS_Axy(i,j,k)
     &           + BSUPPERMET_UYZ*BSUPPERMET_UXY*ADM_BS_Axz(i,j,k)
     &           + BSUPPERMET_UYZ*BSUPPERMET_UYY*ADM_BS_Ayz(i,j,k))*2.0d0

      UPPERA_AZZ = BSUPPERMET_UXZ**2*ADM_BS_Axx(i,j,k)
     &           + BSUPPERMET_UYZ**2*ADM_BS_Ayy(i,j,k)
     &           + BSUPPERMET_UZZ**2*ADM_BS_Azz(i,j,k)
     &           +(BSUPPERMET_UZX*BSUPPERMET_UZY*ADM_BS_Axy(i,j,k)
     &           + BSUPPERMET_UZX*BSUPPERMET_UZZ*ADM_BS_Axz(i,j,k)
     &           + BSUPPERMET_UZY*BSUPPERMET_UZZ*ADM_BS_Ayz(i,j,k))*2.0d0

      UPPERA_AXY = BSUPPERMET_UXX*BSUPPERMET_UYX*ADM_BS_Axx(i,j,k)
     &           + BSUPPERMET_UXY*BSUPPERMET_UYY*ADM_BS_Ayy(i,j,k)
     &           + BSUPPERMET_UXZ*BSUPPERMET_UYZ*ADM_BS_Azz(i,j,k)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UYY
     &           + BSUPPERMET_UXY*BSUPPERMET_UYX)*ADM_BS_Axy(i,j,k)
     &           +(BSUPPERMET_UXZ*BSUPPERMET_UYX
     &           + BSUPPERMET_UXX*BSUPPERMET_UYZ)*ADM_BS_Axz(i,j,k)
     &           +(BSUPPERMET_UXZ*BSUPPERMET_UYY
     &            +BSUPPERMET_UXY*BSUPPERMET_UYZ)*ADM_BS_Ayz(i,j,k)

      UPPERA_AXZ = BSUPPERMET_UXX*BSUPPERMET_UZX*ADM_BS_Axx(i,j,k)
     &           + BSUPPERMET_UXY*BSUPPERMET_UZY*ADM_BS_Ayy(i,j,k)
     &           + BSUPPERMET_UXZ*BSUPPERMET_UZZ*ADM_BS_Azz(i,j,k)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UZY
     &           + BSUPPERMET_UXY*BSUPPERMET_UZX)*ADM_BS_Axy(i,j,k)
     &           +(BSUPPERMET_UXX*BSUPPERMET_UZZ
     &           + BSUPPERMET_UXZ*BSUPPERMET_UZX)*ADM_BS_Axz(i,j,k)
     &           +(BSUPPERMET_UXY*BSUPPERMET_UZZ
     &           + BSUPPERMET_UXZ*BSUPPERMET_UZY)*ADM_BS_Ayz(i,j,k)

      UPPERA_AYZ = BSUPPERMET_UYX*BSUPPERMET_UZX*ADM_BS_Axx(i,j,k)
     &           + BSUPPERMET_UYY*BSUPPERMET_UZY*ADM_BS_Ayy(i,j,k)
     &           + BSUPPERMET_UYZ*BSUPPERMET_UZZ*ADM_BS_Azz(i,j,k)
     &           +(BSUPPERMET_UYX*BSUPPERMET_UZY
     &           + BSUPPERMET_UYY*BSUPPERMET_UZX)*ADM_BS_Axy(i,j,k)
     &           +(BSUPPERMET_UYX*BSUPPERMET_UZZ
     &           + BSUPPERMET_UYZ*BSUPPERMET_UZX)*ADM_BS_Axz(i,j,k)
     &           +(BSUPPERMET_UYY*BSUPPERMET_UZZ
     &           + BSUPPERMET_UYZ*BSUPPERMET_UZY)*ADM_BS_Ayz(i,j,k)

#endif

#endif
