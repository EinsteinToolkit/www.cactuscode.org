/*@@
  @header   BSRICSCAL_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for Ricci scalar where the Ricci tensor is given
  by Eq ?? of BS
  @enddesc
@@*/

#undef BSRICSCAL_GUTS
#undef BSRICSCAL_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/BSRICCI_undefine.h"
#include "macro/RICCIPHI_undefine.h"
