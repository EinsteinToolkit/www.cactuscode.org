/*@@
  @header   BSDYDA_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef BSDYDA_GUTS
#undef BSDYDA_DECLARE


