/*@@
  @header   UPPERA_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to the upper components of the BS conformal TF variable A
  (using the conformal metric)

  @enddesc
@@*/

#ifndef UPPERA_DECLARE
#define UPPERA_DECLARE

#include "macro/BSUPPERMET_declare.h"

#undef  UPPERA_AXX
#define UPPERA_AXX uppera_axx
#undef  UPPERA_AXY
#define UPPERA_AXY uppera_axy
#undef  UPPERA_AXZ
#define UPPERA_AXZ uppera_axz
#undef  UPPERA_AYY
#define UPPERA_AYY uppera_ayy
#undef  UPPERA_AYZ
#define UPPERA_AYZ uppera_ayz
#undef  UPPERA_AZZ
#define UPPERA_AZZ uppera_azz

      CCTK_REAL UPPERA_AXX
      CCTK_REAL UPPERA_AXY
      CCTK_REAL UPPERA_AXZ
      CCTK_REAL UPPERA_AYY
      CCTK_REAL UPPERA_AYZ
      CCTK_REAL UPPERA_AZZ

/* Symmetries */
#undef  UPPERA_AYX
#define UPPERA_AYX UPPERA_AXY
#undef  UPPERA_AZX
#define UPPERA_AZX UPPERA_AXZ
#undef  UPPERA_AZY
#define UPPERA_AZY UPPERA_AYZ

#endif
