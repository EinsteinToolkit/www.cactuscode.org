/*@@
  @header   BSGAMMA_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate BS Gauge Source Functions (Gammas)

  That is BSGAMMA_Ga = BSg^bc BSCHR2_abc

  @enddesc
@@*/

#ifndef BSGAMMA_GUTS
#define BSGAMMA_GUTS

#include "BSCHR2_guts.h"
#include "BSUPPERMET_guts.h"

      BSGAMMA_GAMMAX = BSUPPERMET_UXX*BSCHR2_XXX
     &               + BSUPPERMET_UYY*BSCHR2_XYY
     &               + BSUPPERMET_UZZ*BSCHR2_XZZ
     &               +(BSUPPERMET_UXY*BSCHR2_XXY
     &               + BSUPPERMET_UXZ*BSCHR2_XXZ
     &               + BSUPPERMET_UYZ*BSCHR2_XYZ)*2.0D0

      BSGAMMA_GAMMAY = BSUPPERMET_UXX*BSCHR2_YXX
     &               + BSUPPERMET_UYY*BSCHR2_YYY
     &               + BSUPPERMET_UZZ*BSCHR2_YZZ
     &               +(BSUPPERMET_UXY*BSCHR2_YXY
     &               + BSUPPERMET_UXZ*BSCHR2_YXZ
     &               + BSUPPERMET_UYZ*BSCHR2_YYZ)*2.0D0

      BSGAMMA_GAMMAZ = BSUPPERMET_UXX*BSCHR2_ZXX
     &               + BSUPPERMET_UYY*BSCHR2_ZYY
     &               + BSUPPERMET_UZZ*BSCHR2_ZZZ
     &               +(BSUPPERMET_UXY*BSCHR2_ZXY
     &               + BSUPPERMET_UXZ*BSCHR2_ZXZ
     &               + BSUPPERMET_UYZ*BSCHR2_ZYZ)*2.0D0

#endif
