c $Header: /numrelcvs/AEIThorns/BSSN_MoL/StandAloneBenchmark/Defines.h,v 1.1 2003/10/15 17:47:52 tradke Exp $

c     ==================================================================
c     PARAMETERS YOU MAY WANT TO CHANGE

c grid size
#define DIMX 40
#define DIMY 40
#define DIMZ 40

c the number of iterations to take
#define NITERATIONS 100

c how often to output "iteration #"
#define OUTEVERY 100
