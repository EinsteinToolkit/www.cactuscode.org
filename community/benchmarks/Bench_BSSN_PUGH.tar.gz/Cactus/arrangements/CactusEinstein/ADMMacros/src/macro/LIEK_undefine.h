/*@@
  @header   LIEK_undefine.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef LIEK_GUTS

#include "DB_undefine.h"
#include "DK_undefine.h"


