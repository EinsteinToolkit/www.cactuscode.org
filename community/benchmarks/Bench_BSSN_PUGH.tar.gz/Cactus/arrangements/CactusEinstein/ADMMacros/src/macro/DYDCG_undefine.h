/*@@
  @header   DYDCG_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DYDCG_GUTS

