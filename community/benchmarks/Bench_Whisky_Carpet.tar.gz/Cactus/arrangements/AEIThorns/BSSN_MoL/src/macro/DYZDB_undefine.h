/*@@
  @header   DYZDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DYZDB_GUTS
#undef DYZDB_DECLARE


