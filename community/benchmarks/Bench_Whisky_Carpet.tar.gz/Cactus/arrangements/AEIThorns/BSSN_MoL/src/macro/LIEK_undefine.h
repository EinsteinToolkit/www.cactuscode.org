/*@@
  @header   LIEK_undefine.h
  @date     August 2001
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef LIEK_GUTS
#undef LIEK_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_undefine.h"

