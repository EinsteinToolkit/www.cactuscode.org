/*@@
  @header   PHISOURCES_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
     Macro to calculate the source terms for the evolution of PHI.
  @enddesc
@@*/

#ifndef PHISOURCES_GUTS
#define PHISOURCES_GUTS


/* Extrinsic curvature term */
/* -------------------------*/

      adm_bs_sphi(i,j,k) = - sixth*alp(i,j,k)*ADM_BS_K(i,j,k)

#endif
