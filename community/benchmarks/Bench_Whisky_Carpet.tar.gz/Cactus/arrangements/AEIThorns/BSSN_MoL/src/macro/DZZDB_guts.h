/*@@
  @header   DZZDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DZZDB_GUTS
#define DZZDB_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        DZZDB_DZZDBX = BSSN_DZZ_2(betax,i,j,k)
        DZZDB_DZZDBY = BSSN_DZZ_2(betay,i,j,k)
        DZZDB_DZZDBZ = BSSN_DZZ_2(betaz,i,j,k)
      else
        DZZDB_DZZDBX = BSSN_DZZ_4(betax,i,j,k)
        DZZDB_DZZDBY = BSSN_DZZ_4(betay,i,j,k)
        DZZDB_DZZDBZ = BSSN_DZZ_4(betaz,i,j,k)
      end if

#endif
