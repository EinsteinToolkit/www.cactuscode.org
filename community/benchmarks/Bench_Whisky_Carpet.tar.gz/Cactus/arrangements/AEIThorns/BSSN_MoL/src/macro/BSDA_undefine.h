/*@@
  @header   BSDA_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef BSDG_GUTS
#undef BSDG_DECLARE

#include "macro/BSDXDA_undefine.h"
#include "macro/BSDYDA_undefine.h"
#include "macro/BSDZDA_undefine.h"

