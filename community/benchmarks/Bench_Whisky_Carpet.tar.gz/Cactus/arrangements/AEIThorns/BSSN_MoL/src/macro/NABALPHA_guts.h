/*@@
  @header   NABALPHA_guts.h
  @date     October 99
  @author   Miguel Alcubierre
  @desc
  Macro to calculate the nabla operator acting on alpha 
  @enddesc
@@*/

#ifndef NABALPHA_GUTS
#define NABALPHA_GUTS

#include "macro/BSUPPERMET_guts.h"
#include "macro/CDCDALPHA_guts.h"

      NABALPHA_NABALPHA =
     &     BSUPPERMET_UXX*CDCDALPHA_CDXXDALPHA
     &   + BSUPPERMET_UYY*CDCDALPHA_CDYYDALPHA
     &   + BSUPPERMET_UZZ*CDCDALPHA_CDZZDALPHA
     &   +(BSUPPERMET_UXY*CDCDALPHA_CDXYDALPHA
     &   + BSUPPERMET_UXZ*CDCDALPHA_CDXZDALPHA
     &   + BSUPPERMET_UYZ*CDCDALPHA_CDYZDALPHA)*2.0d0

      NABALPHA_NABALPHA_PHYS =
     &     BSUPPERMET_UXX*CDCDALPHA_CDXXDALPHA_PHYS
     &   + BSUPPERMET_UYY*CDCDALPHA_CDYYDALPHA_PHYS
     &   + BSUPPERMET_UZZ*CDCDALPHA_CDZZDALPHA_PHYS
     &   +(BSUPPERMET_UXY*CDCDALPHA_CDXYDALPHA_PHYS
     &   + BSUPPERMET_UXZ*CDCDALPHA_CDXZDALPHA_PHYS
     &   + BSUPPERMET_UYZ*CDCDALPHA_CDYZDALPHA_PHYS)*2.0d0

      NABALPHA_NABALPHA_PHYS = NABALPHA_NABALPHA_PHYS
     &   *exp(-4.0d0*ADM_BS_PHI(i,j,k))

      IF (conformal_state .ne. 0) THEN
         NABALPHA_NABALPHA_PHYS = NABALPHA_NABALPHA_PHYS/psi(i,j,k)**4
      ENDIF

#ifdef INSOURCES
c      iusdiusdh
c      print *, "Code is giving error at i=",i,"j=",j,"kc=",kc,6
#endif

#endif
