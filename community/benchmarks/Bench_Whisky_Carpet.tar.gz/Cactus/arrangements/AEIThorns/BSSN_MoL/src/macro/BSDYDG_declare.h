/*@@
  @header   BSDYDG_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#ifndef BSDYDG_DECLARE
#define BSDYDG_DECLARE

/* Input variables */
#ifdef OPT

#undef  BSDYDG_GXX_JP   
#define BSDYDG_GXX_JP   lg(XX,i,j+1,kc)
#undef  BSDYDG_GXY_JP   
#define BSDYDG_GXY_JP   lg(XY,i,j+1,kc)
#undef  BSDYDG_GXZ_JP  
#define BSDYDG_GXZ_JP   lg(XZ,i,j+1,kc)
#undef  BSDYDG_GYY_JP    
#define BSDYDG_GYY_JP   lg(YY,i,j+1,kc)
#undef  BSDYDG_GYZ_JP   
#define BSDYDG_GYZ_JP   lg(YZ,i,j+1,kc)
#undef  BSDYDG_GZZ_JP   
#define BSDYDG_GZZ_JP   lg(ZZ,i,j+1,kc)

#undef  BSDYDG_GXX_JM   
#define BSDYDG_GXX_JM   lg(XX,i,j-1,kc)
#undef  BSDYDG_GXY_JM   
#define BSDYDG_GXY_JM   lg(XY,i,j-1,kc)
#undef  BSDYDG_GXZ_JM  
#define BSDYDG_GXZ_JM   lg(XZ,i,j-1,kc)
#undef  BSDYDG_GYY_JM    
#define BSDYDG_GYY_JM   lg(YY,i,j-1,kc)
#undef  BSDYDG_GYZ_JM   
#define BSDYDG_GYZ_JM   lg(YZ,i,j-1,kc)
#undef  BSDYDG_GZZ_JM   
#define BSDYDG_GZZ_JM   lg(ZZ,i,j-1,kc)

#else

#undef  BSDYDG_GXX_JP   
#define BSDYDG_GXX_JP   ADM_BS_gxx(i,j+1,k)
#undef  BSDYDG_GXY_JP   
#define BSDYDG_GXY_JP   ADM_BS_gxy(i,j+1,k)
#undef  BSDYDG_GXZ_JP  
#define BSDYDG_GXZ_JP   ADM_BS_gxz(i,j+1,k)
#undef  BSDYDG_GYY_JP    
#define BSDYDG_GYY_JP   ADM_BS_gyy(i,j+1,k)
#undef  BSDYDG_GYZ_JP   
#define BSDYDG_GYZ_JP   ADM_BS_gyz(i,j+1,k)
#undef  BSDYDG_GZZ_JP   
#define BSDYDG_GZZ_JP   ADM_BS_gzz(i,j+1,k)

#undef  BSDYDG_GXX_JM   
#define BSDYDG_GXX_JM   ADM_BS_gxx(i,j-1,k)
#undef  BSDYDG_GXY_JM   
#define BSDYDG_GXY_JM   ADM_BS_gxy(i,j-1,k)
#undef  BSDYDG_GXZ_JM  
#define BSDYDG_GXZ_JM   ADM_BS_gxz(i,j-1,k)
#undef  BSDYDG_GYY_JM    
#define BSDYDG_GYY_JM   ADM_BS_gyy(i,j-1,k)
#undef  BSDYDG_GYZ_JM   
#define BSDYDG_GYZ_JM   ADM_BS_gyz(i,j-1,k)
#undef  BSDYDG_GZZ_JM   
#define BSDYDG_GZZ_JM   ADM_BS_gzz(i,j-1,k)

#endif

/* Output variables */ 
#undef  BSDYDG_DYDGXX
#define BSDYDG_DYDGXX  bsdydg_dydgxx
#undef  BSDYDG_DYDGXY
#define BSDYDG_DYDGXY  bsdydg_dydgxy
#undef  BSDYDG_DYDGXZ
#define BSDYDG_DYDGXZ  bsdydg_dydgxz
#undef  BSDYDG_DYDGYY
#define BSDYDG_DYDGYY  bsdydg_dydgyy
#undef  BSDYDG_DYDGYZ
#define BSDYDG_DYDGYZ  bsdydg_dydgyz
#undef  BSDYDG_DYDGZZ
#define BSDYDG_DYDGZZ  bsdydg_dydgzz

/* Internal variables */
#undef  BSDYDG_DYFAC
#define BSDYDG_DYFAC   bsdydg_dyfac

/* Declare internal variables */
      CCTK_REAL BSDYDG_DYFAC;

/* Declare output variables */
      CCTK_REAL BSDYDG_DYDGXX;
      CCTK_REAL BSDYDG_DYDGXY;
      CCTK_REAL BSDYDG_DYDGXZ;
      CCTK_REAL BSDYDG_DYDGYY;
      CCTK_REAL BSDYDG_DYDGYZ;
      CCTK_REAL BSDYDG_DYDGZZ;

#endif
