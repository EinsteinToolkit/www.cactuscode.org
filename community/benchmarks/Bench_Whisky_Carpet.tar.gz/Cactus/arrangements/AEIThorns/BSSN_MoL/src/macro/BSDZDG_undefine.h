/*@@
  @header   BSDZDG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef BSDZDG_GUTS
#undef BSDZDG_DECLARE


