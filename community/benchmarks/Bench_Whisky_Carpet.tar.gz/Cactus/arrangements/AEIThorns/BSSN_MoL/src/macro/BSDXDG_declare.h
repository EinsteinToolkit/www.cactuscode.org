/*@@
  @header   BSDXDG_declare.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#ifndef BSDXDG_DECLARE
#define BSDXDG_DECLARE

/* Input variables */
#ifdef OPT

#undef  BSDXDG_GXX_IP
#define BSDXDG_GXX_IP   lg(XX,i+1,j,kc)
#undef  BSDXDG_GXY_IP
#define BSDXDG_GXY_IP   lg(XY,i+1,j,kc)
#undef  BSDXDG_GXZ_IP
#define BSDXDG_GXZ_IP   lg(XZ,i+1,j,kc)
#undef  BSDXDG_GYY_IP
#define BSDXDG_GYY_IP   lg(YY,i+1,j,kc)
#undef  BSDXDG_GYZ_IP
#define BSDXDG_GYZ_IP   lg(YZ,i+1,j,kc)
#undef  BSDXDG_GZZ_IP
#define BSDXDG_GZZ_IP   lg(ZZ,i+1,j,kc)
#undef  BSDXDG_GXX_IM
#define BSDXDG_GXX_IM   lg(XX,i-1,j,kc)
#undef  BSDXDG_GXY_IM
#define BSDXDG_GXY_IM   lg(XY,i-1,j,kc)
#undef  BSDXDG_GXZ_IM
#define BSDXDG_GXZ_IM   lg(XZ,i-1,j,kc)
#undef  BSDXDG_GYY_IM
#define BSDXDG_GYY_IM   lg(YY,i-1,j,kc)
#undef  BSDXDG_GYZ_IM
#define BSDXDG_GYZ_IM   lg(YZ,i-1,j,kc)
#undef  BSDXDG_GZZ_IM
#define BSDXDG_GZZ_IM   lg(ZZ,i-1,j,kc)

#else

#undef  BSDXDG_GXX_IP
#define BSDXDG_GXX_IP   ADM_BS_gxx(i+1,j,k)
#undef  BSDXDG_GXY_IP
#define BSDXDG_GXY_IP   ADM_BS_gxy(i+1,j,k)
#undef  BSDXDG_GXZ_IP
#define BSDXDG_GXZ_IP   ADM_BS_gxz(i+1,j,k)
#undef  BSDXDG_GYY_IP
#define BSDXDG_GYY_IP   ADM_BS_gyy(i+1,j,k)
#undef  BSDXDG_GYZ_IP
#define BSDXDG_GYZ_IP   ADM_BS_gyz(i+1,j,k)
#undef  BSDXDG_GZZ_IP
#define BSDXDG_GZZ_IP   ADM_BS_gzz(i+1,j,k)
#undef  BSDXDG_GXX_IM
#define BSDXDG_GXX_IM   ADM_BS_gxx(i-1,j,k)
#undef  BSDXDG_GXY_IM
#define BSDXDG_GXY_IM   ADM_BS_gxy(i-1,j,k)
#undef  BSDXDG_GXZ_IM
#define BSDXDG_GXZ_IM   ADM_BS_gxz(i-1,j,k)
#undef  BSDXDG_GYY_IM
#define BSDXDG_GYY_IM   ADM_BS_gyy(i-1,j,k)
#undef  BSDXDG_GYZ_IM
#define BSDXDG_GYZ_IM   ADM_BS_gyz(i-1,j,k)
#undef  BSDXDG_GZZ_IM
#define BSDXDG_GZZ_IM   ADM_BS_gzz(i-1,j,k)

#endif

/* Output variables */ 
#undef  BSDXDG_DXDGXX
#define BSDXDG_DXDGXX  bsdxdg_dxdgxx
#undef  BSDXDG_DXDGXY
#define BSDXDG_DXDGXY  bsdxdg_dxdgxy
#undef  BSDXDG_DXDGXZ
#define BSDXDG_DXDGXZ  bsdxdg_dxdgxz
#undef  BSDXDG_DXDGYY
#define BSDXDG_DXDGYY  bsdxdg_dxdgyy
#undef  BSDXDG_DXDGYZ
#define BSDXDG_DXDGYZ  bsdxdg_dxdgyz
#undef  BSDXDG_DXDGZZ
#define BSDXDG_DXDGZZ  bsdxdg_dxdgzz

/* Internal variables */
#undef  BSDXDG_DXFAC
#define BSDXDG_DXFAC   bsdxdg_dxfac

/* Declare internal variables */
      CCTK_REAL BSDXDG_DXFAC;

/* Declare output variables */
      CCTK_REAL BSDXDG_DXDGXX;
      CCTK_REAL BSDXDG_DXDGXY;
      CCTK_REAL BSDXDG_DXDGXZ;
      CCTK_REAL BSDXDG_DXDGYY;
      CCTK_REAL BSDXDG_DXDGYZ;
      CCTK_REAL BSDXDG_DXDGZZ;

#endif
