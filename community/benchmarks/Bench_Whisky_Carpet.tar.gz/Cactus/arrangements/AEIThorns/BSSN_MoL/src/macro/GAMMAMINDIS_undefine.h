/*@@
  @header   GAMMAMINDIS_undefine.h
  @date     February 2001
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef GAMMAMINDIS_GUTS
#undef GAMMAMINDIS_DECLARE

#include "macro/BSCHR2_undefine.h"
#include "macro/DPHI_undefine.h"
#include "macro/BSUPPERMET_undefine.h"
