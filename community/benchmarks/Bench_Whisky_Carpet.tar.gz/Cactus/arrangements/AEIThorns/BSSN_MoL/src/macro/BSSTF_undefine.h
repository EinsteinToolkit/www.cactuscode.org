/*@@
  @header   BSSTF_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the tracefree part of the BS matter
  variable S_ij using

    tracefree S_ij = S_ij - g_ij S / 3
 
  @enddesc
@@*/

#undef BSSTF_GUTS
#undef BSSTF_DECLARE

#include "macro/BSHYDRO_undefine.h"
#include "macro/BSTRS_undefine.h"

