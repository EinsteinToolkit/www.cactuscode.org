/*@@
  @header   ASOURCES_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for source term of the BS A evolution equation 
  Eq. 17 of the BS paper.
  @enddesc
@@*/

#undef ASOURCES_GUTS
#undef ASOURCES_DECLARE

#include "macro/BSSTF_undefine.h"
#include "macro/CDCDALPHA_undefine.h"
#include "macro/NABALPHA_undefine.h"
#include "macro/RICCITF_undefine.h"
#include "macro/AA_undefine.h"
#include "macro/BSUPPERMET_undefine.h"
