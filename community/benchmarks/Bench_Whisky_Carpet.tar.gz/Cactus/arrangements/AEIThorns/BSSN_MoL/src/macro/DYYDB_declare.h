/*@@
  @header   DYYDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DYYDB_DECLARE
#define DYYDB_DECLARE

/* Input variables */

#undef  DYYDB_BX   
#define DYYDB_BX   betax(i,j,k)
#undef  DYYDB_BY   
#define DYYDB_BY   betay(i,j,k)
#undef  DYYDB_BZ  
#define DYYDB_BZ   betaz(i,j,k)

#undef  DYYDB_BX_JP   
#define DYYDB_BX_JP   betax(i,j+1,k)
#undef  DYYDB_BY_JP   
#define DYYDB_BY_JP   betay(i,j+1,k)
#undef  DYYDB_BZ_JP  
#define DYYDB_BZ_JP   betaz(i,j+1,k)

#undef  DYYDB_BX_JM   
#define DYYDB_BX_JM   betax(i,j-1,k)
#undef  DYYDB_BY_JM   
#define DYYDB_BY_JM   betay(i,j-1,k)
#undef  DYYDB_BZ_JM  
#define DYYDB_BZ_JM   betaz(i,j-1,k)


/* Internal variables */

#undef  DYYDB_TEMP
#define DYYDB_TEMP  dyydb_temp

/* Output variables */ 

#undef  DYYDB_DYYDBX
#define DYYDB_DYYDBX  dyydb_dyydbx
#undef  DYYDB_DYYDBY
#define DYYDB_DYYDBY  dyydb_dyydby
#undef  DYYDB_DYYDBZ
#define DYYDB_DYYDBZ  dyydb_dyydbz

/* Declare variables */

      CCTK_REAL DYYDB_TEMP
      CCTK_REAL DYYDB_DYYDBX
      CCTK_REAL DYYDB_DYYDBY
      CCTK_REAL DYYDB_DYYDBZ

#endif
