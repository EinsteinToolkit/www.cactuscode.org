/*@@
  @header   TRAA_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc

  Declarations for macro to calculate the trace of 
  ~A_lj ~A^j_i

  @enddesc
@@*/

#ifndef TRAA_DECLARE
#define TRAA_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/AA_declare.h"

/* Output variables */
#undef  TRAA_TRAA
#define TRAA_TRAA traa_traa

/* Declare output variables */
       CCTK_REAL TRAA_TRAA

#endif
