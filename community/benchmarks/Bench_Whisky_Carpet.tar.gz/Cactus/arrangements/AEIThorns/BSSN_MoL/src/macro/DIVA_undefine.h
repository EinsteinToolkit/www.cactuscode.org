/*@@
  @header   DIVA_undefine.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DIVA_GUTS
#undef DIVA_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/BSCHR2_undefine.h"
#include "macro/BSGAMMA_undefine.h"
