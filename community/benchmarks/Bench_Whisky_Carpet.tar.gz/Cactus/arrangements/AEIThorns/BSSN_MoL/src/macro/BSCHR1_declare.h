/*@@
  @header   BSCHR1_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Declarations for macro to calculate the Christoffel symbols of the
  first kind for the BS variables
  @enddesc
@@*/

#ifndef BSCHR1_DECLARE
#define BSCHR1_DECLARE

#include "macro/BSDG_declare.h"

#ifdef FCODE

/* Output variables */
#undef  BSCHR1_XXX 
#define BSCHR1_XXX bschr1_111
#undef  BSCHR1_XXY 
#define BSCHR1_XXY bschr1_112 
#undef  BSCHR1_XXZ 
#define BSCHR1_XXZ bschr1_113 
#undef  BSCHR1_XYY 
#define BSCHR1_XYY bschr1_122
#undef  BSCHR1_XYZ 
#define BSCHR1_XYZ bschr1_123
#undef  BSCHR1_XZZ
#define BSCHR1_XZZ bschr1_133
#undef  BSCHR1_YXX
#define BSCHR1_YXX bschr1_211
#undef  BSCHR1_YXY
#define BSCHR1_YXY bschr1_212
#undef  BSCHR1_YXZ
#define BSCHR1_YXZ bschr1_213
#undef  BSCHR1_YYY
#define BSCHR1_YYY bschr1_222
#undef  BSCHR1_YYZ
#define BSCHR1_YYZ bschr1_223
#undef  BSCHR1_YZZ
#define BSCHR1_YZZ bschr1_233
#undef  BSCHR1_ZXX
#define BSCHR1_ZXX bschr1_311
#undef  BSCHR1_ZXY
#define BSCHR1_ZXY bschr1_312
#undef  BSCHR1_ZXZ
#define BSCHR1_ZXZ bschr1_313
#undef  BSCHR1_ZYY
#define BSCHR1_ZYY bschr1_322
#undef  BSCHR1_ZYZ
#define BSCHR1_ZYZ bschr1_323
#undef  BSCHR1_ZZZ
#define BSCHR1_ZZZ bschr1_333

/* Declare output variables */
      CCTK_REAL BSCHR1_XXX
      CCTK_REAL BSCHR1_XXY
      CCTK_REAL BSCHR1_XXZ
      CCTK_REAL BSCHR1_XYY
      CCTK_REAL BSCHR1_XYZ
      CCTK_REAL BSCHR1_XZZ
      CCTK_REAL BSCHR1_YXX
      CCTK_REAL BSCHR1_YXY
      CCTK_REAL BSCHR1_YXZ
      CCTK_REAL BSCHR1_YYY
      CCTK_REAL BSCHR1_YYZ
      CCTK_REAL BSCHR1_YZZ
      CCTK_REAL BSCHR1_ZXX
      CCTK_REAL BSCHR1_ZXY
      CCTK_REAL BSCHR1_ZXZ
      CCTK_REAL BSCHR1_ZYY
      CCTK_REAL BSCHR1_ZYZ
      CCTK_REAL BSCHR1_ZZZ

#endif


#ifdef CCODE

/* Output variables */
#undef  BSCHR1_XX1 
#define BSCHR1_XXX bschr1_111
#undef  BSCHR1_XXY 
#define BSCHR1_XXY bschr1_112 
#undef  BSCHR1_XXZ 
#define BSCHR1_XXZ bschr1_113 
#undef  BSCHR1_XYY 
#define BSCHR1_XYY bschr1_122
#undef  BSCHR1_XYZ 
#define BSCHR1_XYZ bschr1_123
#undef  BSCHR1_XZZ
#define BSCHR1_XZZ bschr1_133
#undef  BSCHR1_YXX
#define BSCHR1_YXX bschr1_211
#undef  BSCHR1_YXY
#define BSCHR1_YXY bschr1_212
#undef  BSCHR1_YXZ
#define BSCHR1_Y1Z bschr1_213
#undef  BSCHR1_YYY
#define BSCHR1_YYY bschr1_222
#undef  BSCHR1_YYZ
#define BSCHR1_YYZ bschr1_223
#undef  BSCHR1_2ZZ
#define BSCHR1_YZZ bschr1_233
#undef  BSCHR1_ZXX
#define BSCHR1_ZXX bschr1_311
#undef  BSCHR1_ZXY
#define BSCHR1_ZXY bschr1_312
#undef  BSCHR1_ZXZ
#define BSCHR1_ZXZ bschr1_313
#undef  BSCHR1_ZYY
#define BSCHR1_ZYY bschr1_322
#undef  BSCHR1_ZYZ
#define BSCHR1_ZYZ bschr1_323
#undef  BSCHR1_ZZZ
#define BSCHR1_ZZZ bschr1_333

/* Declare output variables */
CCTK_REAL BSCHR1_XXX;
CCTK_REAL BSCHR1_XXY;
CCTK_REAL BSCHR1_XXZ;
CCTK_REAL BSCHR1_XYY;
CCTK_REAL BSCHR1_XYZ;
CCTK_REAL BSCHR1_XZZ;
CCTK_REAL BSCHR1_YXX;
CCTK_REAL BSCHR1_YXY;
CCTK_REAL BSCHR1_YXZ;
CCTK_REAL BSCHR1_YYY;
CCTK_REAL BSCHR1_YYZ;
CCTK_REAL BSCHR1_YZZ;
CCTK_REAL BSCHR1_ZXX;
CCTK_REAL BSCHR1_ZXY;
CCTK_REAL BSCHR1_ZXZ;
CCTK_REAL BSCHR1_ZYY;
CCTK_REAL BSCHR1_ZYZ;
CCTK_REAL BSCHR1_ZZZ;

#endif

/* Symmetries */
#undef  BSCHR1_XYX 
#define BSCHR1_XYX BSCHR1_XXY
#undef  BSCHR1_XZX 
#define BSCHR1_XZX BSCHR1_XXZ
#undef  BSCHR1_XZY 
#define BSCHR1_XZY BSCHR1_XYZ
#undef  BSCHR1_YYX
#define BSCHR1_YYX BSCHR1_YXY
#undef  BSCHR1_YZX
#define BSCHR1_YZX BSCHR1_YXZ
#undef  BSCHR1_YZY
#define BSCHR1_YZY BSCHR1_YYZ
#undef  BSCHR1_ZYX
#define BSCHR1_ZYX BSCHR1_ZXY
#undef  BSCHR1_ZZX
#define BSCHR1_ZZX BSCHR1_ZXZ
#undef  BSCHR1_ZZY
#define BSCHR1_ZZY BSCHR1_ZYZ

#endif



