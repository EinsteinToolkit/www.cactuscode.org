/*@@
  @header   DZZDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DZZDB_GUTS
#undef DZZDB_DECLARE


