/*@@
  @header   LIEBSG_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the Lie derivative of the BS metric.
  @enddesc
@@*/

#ifndef LIEBSG_GUTS
#define LIEBSG_GUTS

#include "macro/BSSN_Derivative.h"

#include "CactusEinstein/ADMMacros/src/macro/DB_guts.h"
c Computes derivatives of shift only.

c     Advection.

#ifdef OPT
c         print *, "location:"
c         print *, "i=",i,"j=",j,"stencily=",stencily
c         print *, "km=",km,"kc=",kc,"kp=",kp,"kpp=",kpp
c         print *, "upwinding:"
c         print *, "ks=",ks,"kss=",kss,"kss=",kss
c         print *, "sx=",sx,"sy=",sy,"ssy=",ssy
c         print *

      LIEBSG_LGXX =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lg(1,i,j,kc) - 3.0D0*lg(1,i+sx,j,kc)
     &   - lg(1,i+ssx,j,kc) + lg(1,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lg(1,i,j,kc) - 3.0D0*lg(1,i,j+sy,kc)
     &   - lg(1,i,j+ssy,kc) + lg(1,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lg(1,i,j,kc) - 3.0D0*lg(1,i,j,ks)
     &   - lg(1,i,j,kss) + lg(1,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lg(1,i+1,j,kc) - lg(1,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lg(1,i,j+1,kc) - lg(1,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lg(1,i,j,kp) - lg(1,i,j,km))
c      LIEBSG_LGXX =
c     &   -(dble(wx*sx)*BETAX_TEMP
c     &   *(3.0D0*ADM_BS_gxx(i,j,k) - 3.0D0*ADM_BS_gxx(i+sx,j,k)
c     &   - ADM_BS_gxx(i+ssx,j,k) + ADM_BS_gxx(i+sx+ssx,j,k))
c     &   + dble(wy*sy)*BETAY_TEMP
c     &   *(3.0D0*ADM_BS_gxx(i,j,k) - 3.0D0*ADM_BS_gxx(i,j+sy,k)
c     &   - ADM_BS_gxx(i,j+ssy,k) + ADM_BS_gxx(i,j+sy+ssy,k))
c     &   + dble(wz*sz)*BETAZ_TEMP
c     &   *(3.0D0*ADM_BS_gxx(i,j,k) - 3.0D0*ADM_BS_gxx(i,j,k+sz)
c     &   - ADM_BS_gxx(i,j,k+ssz) + ADM_BS_gxx(i,j,k+sz+ssz))) 
c     &   + dble(1-wx)*BETAX_TEMP*(ADM_BS_gxx(i+1,j,k) - ADM_BS_gxx(i-1,j,k))
c     &   + dble(1-wy)*BETAY_TEMP*(ADM_BS_gxx(i,j+1,k) - ADM_BS_gxx(i,j-1,k))
c     &   + dble(1-wz)*BETAZ_TEMP*(ADM_BS_gxx(i,j,k+1) - ADM_BS_gxx(i,j,k-1))
c      LIEBSG_LGXX =
c     &   -(dble(wx*sx)*BETAX_TEMP
c     &   *(3.0D0*ADM_BS_gxx(i,j,k) - 3.0D0*ADM_BS_gxx(i+sx,j,k)
c     &   - ADM_BS_gxx(i+ssx,j,k) + ADM_BS_gxx(i+sx+ssx,j,k))
c     &   + dble(wy*sy)*BETAY_TEMP
c     &   *(3.0D0*ADM_BS_gxx(i,j,k) - 3.0D0*ADM_BS_gxx(i,j+sy,k)
c     &   - ADM_BS_gxx(i,j+ssy,k) + ADM_BS_gxx(i,j+sy+ssy,k))
c     &   + dble(wz*sz)*BETAZ_TEMP
c     &   *(3.0D0*ADM_BS_gxx(i,j,k) - 3.0D0*ADM_BS_gxx(i,j,k+sz)
c     &   - ADM_BS_gxx(i,j,k+ssz) + ADM_BS_gxx(i,j,k+sz+ssz))) 
c     &   + dble(1-wx)*BETAX_TEMP*(ADM_BS_gxx(i+1,j,k) - ADM_BS_gxx(i-1,j,k))
c     &   + dble(1-wy)*BETAY_TEMP*(ADM_BS_gxx(i,j+1,k) - ADM_BS_gxx(i,j-1,k))
c     &   + dble(1-wz)*BETAZ_TEMP*(lg(1,i,j,kp) - lg(1,i,j,km))
c        if (lg(1,i,j,kp).ne.ADM_BS_gxx(i,j,k+1)) print *, "error in kp"
c        if (lg(1,i,j,km).ne.ADM_BS_gxx(i,j,k-1)) print *, "error in km"
c       print *, "kp:",lg(1,i,j,kp), ADM_BS_gxx(i,j,k+1)
c       print *, "km:",lg(1,i,j,km), ADM_BS_gxx(i,j,k-1)


      LIEBSG_LGYY =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lg(YY,i,j,kc) - 3.0D0*lg(YY,i+sx,j,kc)
     &   - lg(YY,i+ssx,j,kc) + lg(YY,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lg(YY,i,j,kc) - 3.0D0*lg(YY,i,j+sy,kc)
     &   - lg(YY,i,j+ssy,kc) + lg(YY,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lg(YY,i,j,kc) - 3.0D0*lg(YY,i,j,ks)
     &   - lg(YY,i,j,kss) + lg(YY,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lg(YY,i+1,j,kc) - lg(YY,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lg(YY,i,j+1,kc) - lg(YY,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lg(YY,i,j,kp) - lg(YY,i,j,km))
      LIEBSG_LGZZ =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lg(ZZ,i,j,kc) - 3.0D0*lg(ZZ,i+sx,j,kc)
     &   - lg(ZZ,i+ssx,j,kc) + lg(ZZ,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lg(ZZ,i,j,kc) - 3.0D0*lg(ZZ,i,j+sy,kc)
     &   - lg(ZZ,i,j+ssy,kc) + lg(ZZ,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lg(ZZ,i,j,kc) - 3.0D0*lg(ZZ,i,j,ks)
     &   - lg(ZZ,i,j,kss) + lg(ZZ,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lg(ZZ,i+1,j,kc) - lg(ZZ,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lg(ZZ,i,j+1,kc) - lg(ZZ,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lg(ZZ,i,j,kp) - lg(ZZ,i,j,km))
      LIEBSG_LGXY =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lg(XY,i,j,kc) - 3.0D0*lg(XY,i+sx,j,kc)
     &   - lg(XY,i+ssx,j,kc) + lg(XY,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lg(XY,i,j,kc) - 3.0D0*lg(XY,i,j+sy,kc)
     &   - lg(XY,i,j+ssy,kc) + lg(XY,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lg(XY,i,j,kc) - 3.0D0*lg(XY,i,j,ks)
     &   - lg(XY,i,j,kss) + lg(XY,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lg(XY,i+1,j,kc) - lg(XY,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lg(XY,i,j+1,kc) - lg(XY,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lg(XY,i,j,kp) - lg(XY,i,j,km))
      LIEBSG_LGXZ =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lg(XZ,i,j,kc) - 3.0D0*lg(XZ,i+sx,j,kc)
     &   - lg(XZ,i+ssx,j,kc) + lg(XZ,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lg(XZ,i,j,kc) - 3.0D0*lg(XZ,i,j+sy,kc)
     &   - lg(XZ,i,j+ssy,kc) + lg(XZ,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lg(XZ,i,j,kc) - 3.0D0*lg(XZ,i,j,ks)
     &   - lg(XZ,i,j,kss) + lg(XZ,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lg(XZ,i+1,j,kc) - lg(XZ,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lg(XZ,i,j+1,kc) - lg(XZ,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lg(XZ,i,j,kp) - lg(XZ,i,j,km))
      LIEBSG_LGYZ =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lg(YZ,i,j,kc) - 3.0D0*lg(YZ,i+sx,j,kc)
     &   - lg(YZ,i+ssx,j,kc) + lg(YZ,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lg(YZ,i,j,kc) - 3.0D0*lg(YZ,i,j+sy,kc)
     &   - lg(YZ,i,j+ssy,kc) + lg(YZ,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lg(YZ,i,j,kc) - 3.0D0*lg(YZ,i,j,ks)
     &   - lg(YZ,i,j,kss) + lg(YZ,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lg(YZ,i+1,j,kc) - lg(YZ,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lg(YZ,i,j+1,kc) - lg(YZ,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lg(YZ,i,j,kp) - lg(YZ,i,j,km))
#else

      LIEBSG_LGXX = BSSN_ADV_DX_2(ADM_BS_gxx,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_gxx,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_gxx,i,j,k,wz,sz,ssz)
      LIEBSG_LGYY = BSSN_ADV_DX_2(ADM_BS_gyy,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_gyy,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_gyy,i,j,k,wz,sz,ssz)
      LIEBSG_LGZZ = BSSN_ADV_DX_2(ADM_BS_gzz,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_gzz,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_gzz,i,j,k,wz,sz,ssz)
      LIEBSG_LGXY = BSSN_ADV_DX_2(ADM_BS_gxy,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_gxy,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_gxy,i,j,k,wz,sz,ssz)
      LIEBSG_LGXZ = BSSN_ADV_DX_2(ADM_BS_gxz,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_gxz,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_gxz,i,j,k,wz,sz,ssz)
      LIEBSG_LGYZ = BSSN_ADV_DX_2(ADM_BS_gyz,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_gyz,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_gyz,i,j,k,wz,sz,ssz)

#endif

c     Extra terms in the Lie derivative.

      LIEBSG_TEMP = twothird*(DXDB_DXDBX + DYDB_DYDBY + DZDB_DZDBZ)

      LIEBSG_LGXX = LIEBSG_LGXX + 2.0D0*(DXDB_DXDBX*LIEBSG_GXX
     &     + DXDB_DXDBY*LIEBSG_GXY + DXDB_DXDBZ*LIEBSG_GXZ)
     &     - LIEBSG_GXX*LIEBSG_TEMP

      LIEBSG_LGYY = LIEBSG_LGYY + 2.0D0*(DYDB_DYDBX*LIEBSG_GXY
     &     + DYDB_DYDBY*LIEBSG_GYY + DYDB_DYDBZ*LIEBSG_GYZ)
     &     - LIEBSG_GYY*LIEBSG_TEMP

      LIEBSG_LGZZ = LIEBSG_LGZZ + 2.0D0*(DZDB_DZDBX*LIEBSG_GXZ
     &     + DZDB_DZDBY*LIEBSG_GYZ + DZDB_DZDBZ*LIEBSG_GZZ)
     &     - LIEBSG_GZZ*LIEBSG_TEMP

      LIEBSG_LGXY = LIEBSG_LGXY + DYDB_DYDBX*LIEBSG_GXX
     &     + (DXDB_DXDBX + DYDB_DYDBY)*LIEBSG_GXY
     &     + DYDB_DYDBZ*LIEBSG_GXZ + DXDB_DXDBY*LIEBSG_GYY
     &     + DXDB_DXDBZ*LIEBSG_GYZ - LIEBSG_GXY*LIEBSG_TEMP

      LIEBSG_LGXZ = LIEBSG_LGXZ + DZDB_DZDBX*LIEBSG_GXX
     &     + (DXDB_DXDBX + DZDB_DZDBZ)*LIEBSG_GXZ
     &     + DZDB_DZDBY*LIEBSG_GXY + DXDB_DXDBY*LIEBSG_GYZ
     &     + DXDB_DXDBZ*LIEBSG_GZZ - LIEBSG_GXZ*LIEBSG_TEMP

      LIEBSG_LGYZ = LIEBSG_LGYZ + DZDB_DZDBX*LIEBSG_GXY
     &     + (DYDB_DYDBY + DZDB_DZDBZ)*LIEBSG_GYZ
     &     + DYDB_DYDBX*LIEBSG_GXZ + DZDB_DZDBY*LIEBSG_GYY
     &     + DYDB_DYDBZ*LIEBSG_GZZ - LIEBSG_GYZ*LIEBSG_TEMP

#endif
