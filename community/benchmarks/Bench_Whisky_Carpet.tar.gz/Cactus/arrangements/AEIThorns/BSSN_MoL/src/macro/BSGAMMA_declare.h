/*@@
  @header   BSGAMMA_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc

  Macro to calculate BS Gauge Source Functions (Gammas)

  That is BSGAMMA_a = BSg^bc BSCHR2_abc
  @enddesc
@@*/

/* #define USE_INVERSE */

#ifndef BSGAMMA_DECLARE
#define BSGAMMA_DECLARE

#ifdef USE_INVERSE

#undef  BSGAMMA_DXUGXX
#define BSGAMMA_DXUGXX bsgamma_dxugxx
#undef  BSGAMMA_DXUGXY
#define BSGAMMA_DXUGXY bsgamma_dxugxy
#undef  BSGAMMA_DXUGXZ
#define BSGAMMA_DXUGXZ bsgamma_dxugxz
#undef  BSGAMMA_DYUGXY
#define BSGAMMA_DYUGXY bsgamma_dyugxy
#undef  BSGAMMA_DYUGYY
#define BSGAMMA_DYUGYY bsgamma_dyugyy
#undef  BSGAMMA_DYUGYZ
#define BSGAMMA_DYUGYZ bsgamma_dyugyz
#undef  BSGAMMA_DZUGXZ
#define BSGAMMA_DZUGXZ bsgamma_dzugxz
#undef  BSGAMMA_DZUGYZ
#define BSGAMMA_DZUGYZ bsgamma_dzugyz
#undef  BSGAMMA_DZUGZZ
#define BSGAMMA_DZUGZZ bsgamma_dzugzz

#undef  BSGAMMA_TEMPXX_IP
#define BSGAMMA_TEMPXX_IP bsgamma_tempxx_ip
#undef  BSGAMMA_TEMPXX_IM
#define BSGAMMA_TEMPXX_IM bsgamma_tempxx_im
#undef  BSGAMMA_TEMPXX_JP
#define BSGAMMA_TEMPXX_JP bsgamma_tempxx_jp
#undef  BSGAMMA_TEMPXX_JM
#define BSGAMMA_TEMPXX_JM bsgamma_tempxx_jm
#undef  BSGAMMA_TEMPXX_KP
#define BSGAMMA_TEMPXX_KP bsgamma_tempxx_kp
#undef  BSGAMMA_TEMPXX_KM
#define BSGAMMA_TEMPXX_KM bsgamma_tempxx_km

#undef  BSGAMMA_TEMPXY_IP
#define BSGAMMA_TEMPXY_IP bsgamma_tempxy_ip
#undef  BSGAMMA_TEMPXY_IM
#define BSGAMMA_TEMPXY_IM bsgamma_tempxy_im
#undef  BSGAMMA_TEMPXY_JP
#define BSGAMMA_TEMPXY_JP bsgamma_tempxy_jp
#undef  BSGAMMA_TEMPXY_JM
#define BSGAMMA_TEMPXY_JM bsgamma_tempxy_jm
#undef  BSGAMMA_TEMPXY_KP
#define BSGAMMA_TEMPXY_KP bsgamma_tempxy_kp
#undef  BSGAMMA_TEMPXY_KM
#define BSGAMMA_TEMPXY_KM bsgamma_tempxy_km

#undef  BSGAMMA_TEMPXZ_IP
#define BSGAMMA_TEMPXZ_IP bsgamma_tempxz_ip
#undef  BSGAMMA_TEMPXZ_IM
#define BSGAMMA_TEMPXZ_IM bsgamma_tempxz_im
#undef  BSGAMMA_TEMPXZ_JP
#define BSGAMMA_TEMPXZ_JP bsgamma_tempxz_jp
#undef  BSGAMMA_TEMPXZ_JM
#define BSGAMMA_TEMPXZ_JM bsgamma_tempxz_jm
#undef  BSGAMMA_TEMPXZ_KP
#define BSGAMMA_TEMPXZ_KP bsgamma_tempxz_kp
#undef  BSGAMMA_TEMPXZ_KM
#define BSGAMMA_TEMPXZ_KM bsgamma_tempxz_km

#undef  BSGAMMA_TEMPYY_IP
#define BSGAMMA_TEMPYY_IP bsgamma_tempyy_ip
#undef  BSGAMMA_TEMPYY_IM
#define BSGAMMA_TEMPYY_IM bsgamma_tempyy_im
#undef  BSGAMMA_TEMPYY_JP
#define BSGAMMA_TEMPYY_JP bsgamma_tempyy_jp
#undef  BSGAMMA_TEMPYY_JM
#define BSGAMMA_TEMPYY_JM bsgamma_tempyy_jm
#undef  BSGAMMA_TEMPYY_KP
#define BSGAMMA_TEMPYY_KP bsgamma_tempyy_kp
#undef  BSGAMMA_TEMPYY_KM
#define BSGAMMA_TEMPYY_KM bsgamma_tempyy_km

#undef  BSGAMMA_TEMPYZ_IP
#define BSGAMMA_TEMPYZ_IP bsgamma_tempyz_ip
#undef  BSGAMMA_TEMPYZ_IM
#define BSGAMMA_TEMPYZ_IM bsgamma_tempyz_im
#undef  BSGAMMA_TEMPYZ_JP
#define BSGAMMA_TEMPYZ_JP bsgamma_tempyz_jp
#undef  BSGAMMA_TEMPYZ_JM
#define BSGAMMA_TEMPYZ_JM bsgamma_tempyz_jm
#undef  BSGAMMA_TEMPYZ_KP
#define BSGAMMA_TEMPYZ_KP bsgamma_tempyz_kp
#undef  BSGAMMA_TEMPYZ_KM
#define BSGAMMA_TEMPYZ_KM bsgamma_tempyz_km

#undef  BSGAMMA_TEMPZZ_IP
#define BSGAMMA_TEMPZZ_IP bsgamma_tempzz_ip
#undef  BSGAMMA_TEMPZZ_IM
#define BSGAMMA_TEMPZZ_IM bsgamma_tempzz_im
#undef  BSGAMMA_TEMPZZ_JP
#define BSGAMMA_TEMPZZ_JP bsgamma_tempzz_jp
#undef  BSGAMMA_TEMPZZ_JM
#define BSGAMMA_TEMPZZ_JM bsgamma_tempzz_jm
#undef  BSGAMMA_TEMPZZ_KP
#define BSGAMMA_TEMPZZ_KP bsgamma_tempzz_kp
#undef  BSGAMMA_TEMPZZ_KM
#define BSGAMMA_TEMPZZ_KM bsgamma_tempzz_km

#undef  BSGAMMA_DETG_IP
#define BSGAMMA_DETG_IP bsgamma_detg_ip
#undef  BSGAMMA_DETG_IM
#define BSGAMMA_DETG_IM bsgamma_detg_im
#undef  BSGAMMA_DETG_JP
#define BSGAMMA_DETG_JP bsgamma_detg_jp
#undef  BSGAMMA_DETG_JM
#define BSGAMMA_DETG_JM bsgamma_detg_jm
#undef  BSGAMMA_DETG_KP
#define BSGAMMA_DETG_KP bsgamma_detg_kp
#undef  BSGAMMA_DETG_KM
#define BSGAMMA_DETG_KM bsgamma_detg_km

#undef  BSGAMMA_UGXX_IP
#define BSGAMMA_UGXX_IP bsgamma_ugxx_ip
#undef  BSGAMMA_UGXY_IP
#define BSGAMMA_UGXY_IP bsgamma_ugxy_ip
#undef  BSGAMMA_UGXZ_IP
#define BSGAMMA_UGXZ_IP bsgamma_ugxz_ip
#undef  BSGAMMA_UGXX_IM
#define BSGAMMA_UGXX_IM bsgamma_ugxx_im
#undef  BSGAMMA_UGXY_IM
#define BSGAMMA_UGXY_IM bsgamma_ugxy_im
#undef  BSGAMMA_UGXZ_IM
#define BSGAMMA_UGXZ_IM bsgamma_ugxz_im

#undef  BSGAMMA_UGXY_JP
#define BSGAMMA_UGXY_JP bsgamma_ugxy_jp
#undef  BSGAMMA_UGYY_JP
#define BSGAMMA_UGYY_JP bsgamma_ugyy_jp
#undef  BSGAMMA_UGYZ_JP
#define BSGAMMA_UGYZ_JP bsgamma_ugyz_jp
#undef  BSGAMMA_UGXY_JM
#define BSGAMMA_UGXY_JM bsgamma_ugxy_jm
#undef  BSGAMMA_UGYY_JM
#define BSGAMMA_UGYY_JM bsgamma_ugyy_jm
#undef  BSGAMMA_UGYZ_JM
#define BSGAMMA_UGYZ_JM bsgamma_ugyz_jm

#undef  BSGAMMA_UGXZ_KP
#define BSGAMMA_UGXZ_KP bsgamma_ugxz_kp
#undef  BSGAMMA_UGYZ_KP
#define BSGAMMA_UGYZ_KP bsgamma_ugyz_kp
#undef  BSGAMMA_UGZZ_KP
#define BSGAMMA_UGZZ_KP bsgamma_ugzz_kp
#undef  BSGAMMA_UGXZ_KM
#define BSGAMMA_UGXZ_KM bsgamma_ugxz_km
#undef  BSGAMMA_UGYZ_KM
#define BSGAMMA_UGYZ_KM bsgamma_ugyz_km
#undef  BSGAMMA_UGZZ_KM
#define BSGAMMA_UGZZ_KM bsgamma_ugzz_km

      CCTK_REAL BSGAMMA_DXUGXX
      CCTK_REAL BSGAMMA_DXUGXY
      CCTK_REAL BSGAMMA_DXUGXZ
      CCTK_REAL BSGAMMA_DYUGXY
      CCTK_REAL BSGAMMA_DYUGYY
      CCTK_REAL BSGAMMA_DYUGYZ
      CCTK_REAL BSGAMMA_DZUGXZ
      CCTK_REAL BSGAMMA_DZUGYZ
      CCTK_REAL BSGAMMA_DZUGZZ


      CCTK_REAL BSGAMMA_TEMPXX_IP
      CCTK_REAL BSGAMMA_TEMPXX_IM
      CCTK_REAL BSGAMMA_TEMPXX_JP
      CCTK_REAL BSGAMMA_TEMPXX_JM
      CCTK_REAL BSGAMMA_TEMPXX_KP
      CCTK_REAL BSGAMMA_TEMPXX_KM

      CCTK_REAL BSGAMMA_TEMPXY_IP
      CCTK_REAL BSGAMMA_TEMPXY_IM
      CCTK_REAL BSGAMMA_TEMPXY_JP
      CCTK_REAL BSGAMMA_TEMPXY_JM
      CCTK_REAL BSGAMMA_TEMPXY_KP
      CCTK_REAL BSGAMMA_TEMPXY_KM

      CCTK_REAL BSGAMMA_TEMPXZ_IP
      CCTK_REAL BSGAMMA_TEMPXZ_IM
      CCTK_REAL BSGAMMA_TEMPXZ_JP
      CCTK_REAL BSGAMMA_TEMPXZ_JM
      CCTK_REAL BSGAMMA_TEMPXZ_KP
      CCTK_REAL BSGAMMA_TEMPXZ_KM

      CCTK_REAL BSGAMMA_TEMPYY_IP
      CCTK_REAL BSGAMMA_TEMPYY_IM
      CCTK_REAL BSGAMMA_TEMPYY_JP
      CCTK_REAL BSGAMMA_TEMPYY_JM
      CCTK_REAL BSGAMMA_TEMPYY_KP
      CCTK_REAL BSGAMMA_TEMPYY_KM

      CCTK_REAL BSGAMMA_TEMPYZ_IP
      CCTK_REAL BSGAMMA_TEMPYZ_IM
      CCTK_REAL BSGAMMA_TEMPYZ_JP
      CCTK_REAL BSGAMMA_TEMPYZ_JM
      CCTK_REAL BSGAMMA_TEMPYZ_KP
      CCTK_REAL BSGAMMA_TEMPYZ_KM

      CCTK_REAL BSGAMMA_TEMPZZ_IP
      CCTK_REAL BSGAMMA_TEMPZZ_IM
      CCTK_REAL BSGAMMA_TEMPZZ_JP
      CCTK_REAL BSGAMMA_TEMPZZ_JM
      CCTK_REAL BSGAMMA_TEMPZZ_KP
      CCTK_REAL BSGAMMA_TEMPZZ_KM

      CCTK_REAL BSGAMMA_DETG_IP
      CCTK_REAL BSGAMMA_DETG_IM
      CCTK_REAL BSGAMMA_DETG_JP
      CCTK_REAL BSGAMMA_DETG_JM
      CCTK_REAL BSGAMMA_DETG_KP
      CCTK_REAL BSGAMMA_DETG_KM

      CCTK_REAL BSGAMMA_UGXX_IP
      CCTK_REAL BSGAMMA_UGXX_IM
      CCTK_REAL BSGAMMA_UGXY_IP
      CCTK_REAL BSGAMMA_UGXY_IM
      CCTK_REAL BSGAMMA_UGXZ_IP
      CCTK_REAL BSGAMMA_UGXZ_IM

      CCTK_REAL BSGAMMA_UGXY_JP
      CCTK_REAL BSGAMMA_UGXY_JM
      CCTK_REAL BSGAMMA_UGYY_JP
      CCTK_REAL BSGAMMA_UGYY_JM
      CCTK_REAL BSGAMMA_UGYZ_JP
      CCTK_REAL BSGAMMA_UGYZ_JM

      CCTK_REAL BSGAMMA_UGXZ_KP
      CCTK_REAL BSGAMMA_UGXZ_KM
      CCTK_REAL BSGAMMA_UGYZ_KP
      CCTK_REAL BSGAMMA_UGYZ_KM
      CCTK_REAL BSGAMMA_UGZZ_KP
      CCTK_REAL BSGAMMA_UGZZ_KM


#undef  BSGAMMA_TWODX
#define BSGAMMA_TWODX  bsgamma_twodx
#undef  BSGAMMA_TWODY
#define BSGAMMA_TWODY  bsgamma_twody
#undef  BSGAMMA_TWODZ
#define BSGAMMA_TWODZ  bsgamma_twodz

      CCTK_REAL BSGAMMA_TWODX
      CCTK_REAL BSGAMMA_TWODY
      CCTK_REAL BSGAMMA_TWODZ


#else

#include "macro/BSCHR2_declare.h"
#include "macro/BSUPPERMET_declare.h"

#endif

/* Output variables */
#undef  BSGAMMA_GAMMAX 
#define BSGAMMA_GAMMAX bsgamma_gammax
#undef  BSGAMMA_GAMMAY
#define BSGAMMA_GAMMAY bsgamma_gammay
#undef  BSGAMMA_GAMMAZ
#define BSGAMMA_GAMMAZ bsgamma_gammaz

/* Declare output variables */
      CCTK_REAL BSGAMMA_GAMMAX
      CCTK_REAL BSGAMMA_GAMMAY
      CCTK_REAL BSGAMMA_GAMMAZ

#endif


