/*@@
  @header   TRKSOURCES_declare.h
  @date 
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef TRKSOURCES_DECLARE
#define TRKSOURCES_DECLARE

#include "macro/BSHYDRO_declare.h"
#include "macro/BSTRS_declare.h"
#include "macro/TRAA_declare.h"
#include "macro/NABALPHA_declare.h"
#include "macro/BSRICSCAL_declare.h"

#undef  TRKSOURCES_MATTER
#define TRKSOURCES_MATTER trksources_matter

#undef  TRKSOURCES_METRIC
#define TRKSOURCES_METRIC trksources_metric

      CCTK_REAL TRKSOURCES_MATTER
      CCTK_REAL TRKSOURCES_METRIC

#endif
