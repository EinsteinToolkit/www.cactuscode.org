/*@@
  @header   TRAA_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc

  Macro to calculate the trace of ~A_lj ~A^j_i

  @enddesc
@@*/

#ifndef TRAA_GUTS
#define TRAA_GUTS

#include "macro/BSUPPERMET_guts.h"
#include "macro/AA_guts.h"

      TRAA_TRAA = BSUPPERMET_UXX*AA_AAXX + BSUPPERMET_UYY*AA_AAYY
     &      + BSUPPERMET_UZZ*AA_AAZZ + 2.0d0*(BSUPPERMET_UXY*AA_AAXY
     &      + BSUPPERMET_UXZ*AA_AAXZ + BSUPPERMET_UYZ*AA_AAYZ)
 
#endif
  
