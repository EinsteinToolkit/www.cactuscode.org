/*@@
  @header   LIEA_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef LIEA_DECLARE
#define LIEA_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_declare.h"

#ifdef OPT

#undef  LIEA_AXX
#define LIEA_AXX lA(XX,i,j,kc)
#undef  LIEA_AXY
#define LIEA_AXY lA(XY,i,j,kc)
#undef  LIEA_AXZ
#define LIEA_AXZ lA(XZ,i,j,kc)
#undef  LIEA_AYY
#define LIEA_AYY lA(YY,i,j,kc)
#undef  LIEA_AYZ
#define LIEA_AYZ lA(YZ,i,j,kc)
#undef  LIEA_AZZ
#define LIEA_AZZ lA(ZZ,i,j,kc)

#else

#undef  LIEA_AXX
#define LIEA_AXX ADM_BS_Axx(i,j,k)
#undef  LIEA_AXY
#define LIEA_AXY ADM_BS_Axy(i,j,k)
#undef  LIEA_AXZ
#define LIEA_AXZ ADM_BS_Axz(i,j,k)
#undef  LIEA_AYY
#define LIEA_AYY ADM_BS_Ayy(i,j,k)
#undef  LIEA_AYZ
#define LIEA_AYZ ADM_BS_Ayz(i,j,k)
#undef  LIEA_AZZ
#define LIEA_AZZ ADM_BS_Azz(i,j,k)

#endif

#undef  LIEA_LAXX
#define LIEA_LAXX liea_laxx
#undef  LIEA_LAXY
#define LIEA_LAXY liea_laxy
#undef  LIEA_LAXZ
#define LIEA_LAXZ liea_laxz
#undef  LIEA_LAYY
#define LIEA_LAYY liea_layy
#undef  LIEA_LAYZ
#define LIEA_LAYZ liea_layz
#undef  LIEA_LAZZ
#define LIEA_LAZZ liea_lazz

#undef  LIEA_TEMP
#define LIEA_TEMP liea_temp

      CCTK_REAL LIEA_LAXX
      CCTK_REAL LIEA_LAXY
      CCTK_REAL LIEA_LAXZ
      CCTK_REAL LIEA_LAYY
      CCTK_REAL LIEA_LAYZ
      CCTK_REAL LIEA_LAZZ

      CCTK_REAL LIEA_TEMP

#endif
