/*@@
  @header   BSDA_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Declarations for macro to calculate all the first derivatives of the 
     BS Aij with respect to x, y, z.
  @enddesc
@@*/

#ifndef BSDA_DECLARE
#define BSDA_DECLARE

#include "macro/BSDXDA_declare.h"
#include "macro/BSDYDA_declare.h"
#include "macro/BSDZDA_declare.h"

#endif
