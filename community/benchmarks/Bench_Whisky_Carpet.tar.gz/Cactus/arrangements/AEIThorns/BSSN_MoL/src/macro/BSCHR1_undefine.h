/*@@
  @header   BSCHR1_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef BSCHR1_GUTS
#undef BSCHR1_DECLARE

#include "macro/BSDG_undefine.h"


