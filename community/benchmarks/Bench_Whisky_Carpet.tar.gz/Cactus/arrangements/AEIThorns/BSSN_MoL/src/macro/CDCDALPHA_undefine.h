/*@@
  @header   CDCDALPHA_undefine.h
  @date     October 99
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef CDCDALPHA_GUTS
#undef CDCDALPHA_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DA_undefine.h"
#include "CactusEinstein/ADMMacros/src/macro/DDA_undefine.h"
#include "macro/DPHI_undefine.h"
#include "macro/BSCHR2_undefine.h"
#include "macro/BSUPPERMET_undefine.h"

