/*@@
  @header   DIVA_guts.h
  @date     March 2000
  @author   Miguel Alcubierre
  @desc

  Macro to calculate the divergence of \tilde{A}_ij:

           ~ab ~  ~
  DIVA  =  g   D  A
      i         a  bi

           ~ab /    ~      ~k  ~      ~k  ~   \
        =  g   | d  A   -  G   A   -  G   A   |
               \  a  bi     ai  bk     ab  ki /


           ~ab /    ~      ~k  ~   \     ~k ~
        =  g   | d  A   -  G   A   |  -  G  A
               \  a  bi     ai  bk /         ki


  with \tilde{G}^k_ij the Christoffel symbols of the
  covariat metric, and \tilde{G}^k the BS Gammas.

  Notice that this is the covariant (lower index) divergence!

  @enddesc
@@*/

#ifndef DIV_GUTS
#define DIV_GUTS

#include "macro/BSSN_Derivative.h"

c     Derivative terms.

#include "BSUPPERMET_guts.h"
#include "BSCHR2_guts.h"
#include "BSGAMMA_guts.h"

c     Derivative terms.

      if (local_spatial_order.eq.2) then
        DIVA_DIVAX = 0.5d0*(BSUPPERMET_UXX*BSSN_DX_2(ADM_BS_Axx,i,j,k)
     .           + BSUPPERMET_UYY*BSSN_DY_2(ADM_BS_Axy,i,j,k)
     .           + BSUPPERMET_UZZ*BSSN_DZ_2(ADM_BS_Axz,i,j,k)
     .           + BSUPPERMET_UXY*(BSSN_DX_2(ADM_BS_Axy,i,j,k) 
     .                           + BSSN_DY_2(ADM_BS_Axx,i,j,k))
     .           + BSUPPERMET_UXZ*(BSSN_DX_2(ADM_BS_Axz,i,j,k) 
     .                           + BSSN_DZ_2(ADM_BS_Axx,i,j,k))
     .           + BSUPPERMET_UYZ*(BSSN_DY_2(ADM_BS_Axz,i,j,k) 
     .                           + BSSN_DZ_2(ADM_BS_Axy,i,j,k)))

        DIVA_DIVAY = 0.5d0*(BSUPPERMET_UXX*BSSN_DX_2(ADM_BS_Axy,i,j,k)
     .           + BSUPPERMET_UYY*BSSN_DY_2(ADM_BS_Ayy,i,j,k)
     .           + BSUPPERMET_UZZ*BSSN_DZ_2(ADM_BS_Ayz,i,j,k)
     .           + BSUPPERMET_UXY*(BSSN_DX_2(ADM_BS_Ayy,i,j,k)
     .                           + BSSN_DY_2(ADM_BS_Axy,i,j,k))
     .           + BSUPPERMET_UXZ*(BSSN_DX_2(ADM_BS_Ayz,i,j,k)
     .                           + BSSN_DZ_2(ADM_BS_Axy,i,j,k))
     .           + BSUPPERMET_UYZ*(BSSN_DY_2(ADM_BS_Ayz,i,j,k)
     .                           + BSSN_DZ_2(ADM_BS_Ayy,i,j,k)))

        DIVA_DIVAZ = 0.5d0*(BSUPPERMET_UXX*BSSN_DX_2(ADM_BS_Axz,i,j,k)
     .           + BSUPPERMET_UYY*BSSN_DY_2(ADM_BS_Ayz,i,j,k)
     .           + BSUPPERMET_UZZ*BSSN_DZ_2(ADM_BS_Azz,i,j,k)
     .           + BSUPPERMET_UXY*(BSSN_DX_2(ADM_BS_Ayz,i,j,k)
     .                           + BSSN_DY_2(ADM_BS_Axz,i,j,k))
     .           + BSUPPERMET_UXZ*(BSSN_DX_2(ADM_BS_Azz,i,j,k)
     .                           + BSSN_DZ_2(ADM_BS_Axz,i,j,k))
     .           + BSUPPERMET_UYZ*(BSSN_DY_2(ADM_BS_Azz,i,j,k)
     .                           + BSSN_DZ_2(ADM_BS_Ayz,i,j,k)))
      else
        DIVA_DIVAX = 0.5d0*(BSUPPERMET_UXX*BSSN_DX_4(ADM_BS_Axx,i,j,k)
     .           + BSUPPERMET_UYY*BSSN_DY_4(ADM_BS_Axy,i,j,k)
     .           + BSUPPERMET_UZZ*BSSN_DZ_4(ADM_BS_Axz,i,j,k)
     .           + BSUPPERMET_UXY*(BSSN_DX_4(ADM_BS_Axy,i,j,k) 
     .                           + BSSN_DY_4(ADM_BS_Axx,i,j,k))
     .           + BSUPPERMET_UXZ*(BSSN_DX_4(ADM_BS_Axz,i,j,k) 
     .                           + BSSN_DZ_4(ADM_BS_Axx,i,j,k))
     .           + BSUPPERMET_UYZ*(BSSN_DY_4(ADM_BS_Axz,i,j,k) 
     .                           + BSSN_DZ_4(ADM_BS_Axy,i,j,k)))

        DIVA_DIVAY = 0.5d0*(BSUPPERMET_UXX*BSSN_DX_4(ADM_BS_Axy,i,j,k)
     .           + BSUPPERMET_UYY*BSSN_DY_4(ADM_BS_Ayy,i,j,k)
     .           + BSUPPERMET_UZZ*BSSN_DZ_4(ADM_BS_Ayz,i,j,k)
     .           + BSUPPERMET_UXY*(BSSN_DX_4(ADM_BS_Ayy,i,j,k)
     .                           + BSSN_DY_4(ADM_BS_Axy,i,j,k))
     .           + BSUPPERMET_UXZ*(BSSN_DX_4(ADM_BS_Ayz,i,j,k)
     .                           + BSSN_DZ_4(ADM_BS_Axy,i,j,k))
     .           + BSUPPERMET_UYZ*(BSSN_DY_4(ADM_BS_Ayz,i,j,k)
     .                           + BSSN_DZ_4(ADM_BS_Ayy,i,j,k)))

        DIVA_DIVAZ = 0.5d0*(BSUPPERMET_UXX*BSSN_DX_4(ADM_BS_Axz,i,j,k)
     .           + BSUPPERMET_UYY*BSSN_DY_4(ADM_BS_Ayz,i,j,k)
     .           + BSUPPERMET_UZZ*BSSN_DZ_4(ADM_BS_Azz,i,j,k)
     .           + BSUPPERMET_UXY*(BSSN_DX_4(ADM_BS_Ayz,i,j,k)
     .                           + BSSN_DY_4(ADM_BS_Axz,i,j,k))
     .           + BSUPPERMET_UXZ*(BSSN_DX_4(ADM_BS_Azz,i,j,k)
     .                           + BSSN_DZ_4(ADM_BS_Axz,i,j,k))
     .           + BSUPPERMET_UYZ*(BSSN_DY_4(ADM_BS_Azz,i,j,k)
     .                           + BSSN_DZ_4(ADM_BS_Ayz,i,j,k)))
      end if

c     Christoffel symbol terms.

      DIVA_DIVAX = DIVA_DIVAX
     .           - BSUPPERMET_UXX*(BSCHR2_XXX*ADM_BS_Axx(i,j,k)
     .           + BSCHR2_YXX*ADM_BS_Axy(i,j,k) + BSCHR2_ZXX*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UYY*(BSCHR2_XXY*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_YXY*ADM_BS_Ayy(i,j,k) + BSCHR2_ZXY*ADM_BS_Ayz(i,j,k))
     .           - BSUPPERMET_UZZ*(BSCHR2_XXZ*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YXZ*ADM_BS_Ayz(i,j,k) + BSCHR2_ZXZ*ADM_BS_Azz(i,j,k))
     .           - BSUPPERMET_UXY*(BSCHR2_XXX*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_YXX*ADM_BS_Ayy(i,j,k) + BSCHR2_ZXX*ADM_BS_Ayz(i,j,k)
     .           + BSCHR2_XXY*ADM_BS_Axx(i,j,k) + BSCHR2_YXY*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_ZXY*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UXZ*(BSCHR2_XXX*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YXX*ADM_BS_Ayz(i,j,k) + BSCHR2_ZXX*ADM_BS_Azz(i,j,k)
     .           + BSCHR2_XXZ*ADM_BS_Axx(i,j,k) + BSCHR2_YXZ*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_ZXZ*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UYZ*(BSCHR2_XXY*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YXY*ADM_BS_Ayz(i,j,k) + BSCHR2_ZXY*ADM_BS_Azz(i,j,k)
     .           + BSCHR2_XXZ*ADM_BS_Axy(i,j,k) + BSCHR2_YXZ*ADM_BS_Ayy(i,j,k)
     .           + BSCHR2_ZXZ*ADM_BS_Ayz(i,j,k))

      DIVA_DIVAY = DIVA_DIVAY
     .           - BSUPPERMET_UXX*(BSCHR2_XXY*ADM_BS_Axx(i,j,k)
     .           + BSCHR2_YXY*ADM_BS_Axy(i,j,k) + BSCHR2_ZXY*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UYY*(BSCHR2_XYY*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_YYY*ADM_BS_Ayy(i,j,k) + BSCHR2_ZYY*ADM_BS_Ayz(i,j,k))
     .           - BSUPPERMET_UZZ*(BSCHR2_XYZ*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YYZ*ADM_BS_Ayz(i,j,k) + BSCHR2_ZYZ*ADM_BS_Azz(i,j,k))
     .           - BSUPPERMET_UXY*(BSCHR2_XXY*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_YXY*ADM_BS_Ayy(i,j,k) + BSCHR2_ZXY*ADM_BS_Ayz(i,j,k)
     .           + BSCHR2_XYY*ADM_BS_Axx(i,j,k) + BSCHR2_YYY*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_ZYY*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UXZ*(BSCHR2_XXY*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YXY*ADM_BS_Ayz(i,j,k) + BSCHR2_ZXY*ADM_BS_Azz(i,j,k)
     .           + BSCHR2_XYZ*ADM_BS_Axx(i,j,k) + BSCHR2_YYZ*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_ZYZ*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UYZ*(BSCHR2_XYY*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YYY*ADM_BS_Ayz(i,j,k) + BSCHR2_ZYY*ADM_BS_Azz(i,j,k)
     .           + BSCHR2_XYZ*ADM_BS_Axy(i,j,k) + BSCHR2_YYZ*ADM_BS_Ayy(i,j,k)
     .           + BSCHR2_ZYZ*ADM_BS_Ayz(i,j,k))

      DIVA_DIVAZ = DIVA_DIVAZ
     .           - BSUPPERMET_UXX*(BSCHR2_XXZ*ADM_BS_Axx(i,j,k)
     .           + BSCHR2_YXZ*ADM_BS_Axy(i,j,k) + BSCHR2_ZXZ*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UYY*(BSCHR2_XYZ*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_YYZ*ADM_BS_Ayy(i,j,k) + BSCHR2_ZYZ*ADM_BS_Ayz(i,j,k))
     .           - BSUPPERMET_UZZ*(BSCHR2_XZZ*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YZZ*ADM_BS_Ayz(i,j,k) + BSCHR2_ZZZ*ADM_BS_Azz(i,j,k))
     .           - BSUPPERMET_UXY*(BSCHR2_XXZ*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_YXZ*ADM_BS_Ayy(i,j,k) + BSCHR2_ZXZ*ADM_BS_Ayz(i,j,k)
     .           + BSCHR2_XYZ*ADM_BS_Axx(i,j,k) + BSCHR2_YYZ*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_ZYZ*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UXZ*(BSCHR2_XXZ*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YXZ*ADM_BS_Ayz(i,j,k) + BSCHR2_ZXZ*ADM_BS_Azz(i,j,k)
     .           + BSCHR2_XZZ*ADM_BS_Axx(i,j,k) + BSCHR2_YZZ*ADM_BS_Axy(i,j,k)
     .           + BSCHR2_ZZZ*ADM_BS_Axz(i,j,k))
     .           - BSUPPERMET_UYZ*(BSCHR2_XYZ*ADM_BS_Axz(i,j,k)
     .           + BSCHR2_YYZ*ADM_BS_Ayz(i,j,k) + BSCHR2_ZYZ*ADM_BS_Azz(i,j,k)
     .           + BSCHR2_XZZ*ADM_BS_Axy(i,j,k) + BSCHR2_YZZ*ADM_BS_Ayy(i,j,k)
     .           + BSCHR2_ZZZ*ADM_BS_Ayz(i,j,k))

c     Gamma terms.

      DIVA_DIVAX = DIVA_DIVAX
     .           - BSGAMMA_GAMMAX*ADM_BS_Axx(i,j,k)
     .           - BSGAMMA_GAMMAY*ADM_BS_Axy(i,j,k)
     .           - BSGAMMA_GAMMAZ*ADM_BS_Axz(i,j,k)

      DIVA_DIVAY = DIVA_DIVAY
     .           - BSGAMMA_GAMMAX*ADM_BS_Axy(i,j,k)
     .           - BSGAMMA_GAMMAY*ADM_BS_Ayy(i,j,k)
     .           - BSGAMMA_GAMMAZ*ADM_BS_Ayz(i,j,k)

      DIVA_DIVAZ = DIVA_DIVAZ
     .           - BSGAMMA_GAMMAX*ADM_BS_Axz(i,j,k)
     .           - BSGAMMA_GAMMAY*ADM_BS_Ayz(i,j,k)
     .           - BSGAMMA_GAMMAZ*ADM_BS_Azz(i,j,k)

#endif


