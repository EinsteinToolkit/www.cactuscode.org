/*@@
  @header   NABPHI_declare.h
  @date     Jul 98
  @author   Gabrielle Allen
  @desc

  @enddesc
@@*/

#ifndef NABPHI_DECLARE
#define NABPHI_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/CDCDPHI_declare.h"

/* Output variables */ 
#undef  NABPHI_NABPHI
#define NABPHI_NABPHI nabphi_nabphi

/* Declare output variables */
      CCTK_REAL NABPHI_NABPHI

#endif
