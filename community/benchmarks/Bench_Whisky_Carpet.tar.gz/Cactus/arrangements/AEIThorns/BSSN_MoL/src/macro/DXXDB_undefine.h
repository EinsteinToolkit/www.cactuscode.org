/*@@
  @header   DXXDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DXXDB_GUTS
#undef DXXDB_DECLARE


