/*@@
  @header   BSDXDA_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the first derivatives of the 
     BS Aij with respect to x
  @enddesc
@@*/

#include "macro/BSSN_Derivative.h"

#ifndef BSDXDA_GUTS
#define BSDXDA_GUTS
      if (local_spatial_order.eq.2) then
        BSDXDA_DXDAXX = BSSN_DX_2(ADM_BS_Axx,i,j,k)
        BSDXDA_DXDAXY = BSSN_DX_2(ADM_BS_Axy,i,j,k)
        BSDXDA_DXDAXZ = BSSN_DX_2(ADM_BS_Axz,i,j,k)
        BSDXDA_DXDAYY = BSSN_DX_2(ADM_BS_Ayy,i,j,k)
        BSDXDA_DXDAYZ = BSSN_DX_2(ADM_BS_Ayz,i,j,k)
        BSDXDA_DXDAZZ = BSSN_DX_2(ADM_BS_Azz,i,j,k)
      else
        BSDXDA_DXDAXX = BSSN_DX_4(ADM_BS_Axx,i,j,k)
        BSDXDA_DXDAXY = BSSN_DX_4(ADM_BS_Axy,i,j,k)
        BSDXDA_DXDAXZ = BSSN_DX_4(ADM_BS_Axz,i,j,k)
        BSDXDA_DXDAYY = BSSN_DX_4(ADM_BS_Ayy,i,j,k)
        BSDXDA_DXDAYZ = BSSN_DX_4(ADM_BS_Ayz,i,j,k)
        BSDXDA_DXDAZZ = BSSN_DX_4(ADM_BS_Azz,i,j,k)
      end if
#endif
