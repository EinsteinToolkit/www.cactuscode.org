
#undef ALPSOURCES_GUTS
#undef ALPSOURCES_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DA_undefine.h"
#include "CactusEinstein/ADMMacros/src/macro/DDA_undefine.h"
#include "macro/NABALPHA_undefine.h"
