/*@@
  @header   DTRK_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all first spatial derivative of BS trk
  @enddesc
@@*/

#ifndef DTRK_DECLARE
#define DTRK_DECLARE

#ifdef FCODE

/* Input variables */
#undef  DTRK_TRK_IP 
#define DTRK_TRK_IP ADM_BS_K(i+1,j,k)
#undef  DTRK_TRK_IM
#define DTRK_TRK_IM ADM_BS_K(i-1,j,k)
#undef  DTRK_TRK_JP 
#define DTRK_TRK_JP ADM_BS_K(i,j+1,k)
#undef  DTRK_TRK_JM 
#define DTRK_TRK_JM ADM_BS_K(i,j-1,k)
#undef  DTRK_TRK_KP 
#define DTRK_TRK_KP ADM_BS_K(i,j,k+1)
#undef  DTRK_TRK_KM
#define DTRK_TRK_KM ADM_BS_K(i,j,k-1)

/* Output variables */ 
#undef  DTRK_DXDTRK
#define DTRK_DXDTRK  dtrk_dxdtrk
#undef  DTRK_DYDTRK
#define DTRK_DYDTRK  dtrk_dydtrk
#undef  DTRK_DZDTRK
#define DTRK_DZDTRK  dtrk_dzdtrk

/* Internal variables */
#undef  DTRK_OO2DX   
#define DTRK_OO2DX dtrk_oo2dx
#undef  DTRK_OO2DY   
#define DTRK_OO2DY dtrk_oo2dy
#undef  DTRK_OO2DZ   
#define DTRK_OO2DZ dtrk_oo2dz
#undef  DTRK_DX   
#define DTRK_DX dx
#undef  DTRK_DY   
#define DTRK_DY dy
#undef  DTRK_DZ   
#define DTRK_DZ dz

/* Declare internal variables */
      CCTK_REAL DTRK_OO2DX
      CCTK_REAL DTRK_OO2DY
      CCTK_REAL DTRK_OO2DZ

/* Declare output variables */
      CCTK_REAL DTRK_DXDTRK
      CCTK_REAL DTRK_DYDTRK
      CCTK_REAL DTRK_DZDTRK

#endif


#ifdef CCODE

/* Input variables */
#undef  DTRK_TRK_IP 
#define DTRK_TRK_IP ADM_BS_trk[ di + ijk]
#undef  DTRK_TRK_IM
#define DTRK_TRK_IM ADM_BS_trk[-di + ijk]
#undef  DTRK_TRK_JP 
#define DTRK_TRK_JP ADM_BS_trk[ dj + ijk]
#undef  DTRK_TRK_JM 
#define DTRK_TRK_JM ADM_BS_trk[-dj + ijk]
#undef  DTRK_TRK_KP 
#define DTRK_TRK_KP ADM_BS_trk[ dk + ijk]
#undef  DTRK_TRK_KM
#define DTRK_TRK_KM ADM_BS_trk[-dk + ijk]

/* Output variables */ 
#undef  DTRK_DXDTRK
#define DTRK_DXDTRK dtrk_dxdtrk
#undef  DTRK_DYDTRK
#define DTRK_DYDTRK dtrk_dydtrk
#undef  DTRK_DZDTRK
#define DTRK_DZDTRK dtrk_dzdtrk

/* Internal variables */
#undef  DTRK_OO2DX   
#define DTRK_OO2DX dtrk_oo2dx
#undef  DTRK_OO2DY   
#define DTRK_OO2DY dtrk_oo2dy
#undef  DTRK_OO2DZ   
#define DTRK_OO2DZ dtrk_oo2dz

/* Declare internal variables */
      CCTK_REAL DTRK_OO2DX;
      CCTK_REAL DTRK_OO2DY;
      CCTK_REAL DTRK_OO2DZ;

/* Declare output variables */
      CCTK_REAL DTRK_DXDTRK;
      CCTK_REAL DTRK_DYDTRK;
      CCTK_REAL DTRK_DZDTRK;

#endif

#endif


