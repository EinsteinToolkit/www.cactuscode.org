/*@@
  @header   LIEK_guts.h
  @date     August 2001
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the Lie derivative of the
     trace of the extrinsic curvature K.
  @enddesc
@@*/

#ifndef LIEK_GUTS
#define LIEK_GUTS

#include "macro/BSSN_Derivative.h"

c     Advection.

      LIEK_LK = BSSN_ADV_DX_2(ADM_BS_K,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_K,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_K,i,j,k,wz,sz,ssz)

#endif
