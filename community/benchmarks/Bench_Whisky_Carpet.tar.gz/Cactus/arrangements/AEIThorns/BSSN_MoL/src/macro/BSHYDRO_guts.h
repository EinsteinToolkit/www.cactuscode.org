/*@@
  @header   BSHYDRO_guts.h
  @date     Nov 98
  @author   Gabrielle Allen + Miguel Alcubierre
  @desc
  Macro to calculate the hydro quantities in the BS evolution scheme.

  n_a = (-alpha,0, 0, 0)
  n^a = (1/alpha,-betaz/alpha,-betay/alpha,-betaz/alpha)

  Energy density:

  rho = n_a n_b T^{ab} = n^a n^b T_{ab}
      = (T_00 - 2 beta^i T_{i0} + beta^i beta^j T_{ij})/alpha^2

  Momentum density:

  S_i = - g_{ia} n_b T^{ab} = - g_i^a n^b T_{ab} 
      = - (T_{i0} - beta^j T_{ij})/alpha

  Stress tensor:

  S_{ij} = g_{ia} g_{jb} T^{ab} = T_{ij}

  @enddesc
@@*/

#ifndef BSHYDRO_GUTS
#define BSHYDRO_GUTS

#include "CactusEinstein/ADMMacros/src/macro/STRESSENERGY_guts.h"

      BSHYDRO_IALP = 1.0d0/alp(i,j,k)

c     Energy density.

      BSHYDRO_RHO = BSHYDRO_IALP**2*STRESSENERGY_TTT

c     Momentum density.

      BSHYDRO_SX = - BSHYDRO_IALP*STRESSENERGY_TTX
      BSHYDRO_SY = - BSHYDRO_IALP*STRESSENERGY_TTY
      BSHYDRO_SZ = - BSHYDRO_IALP*STRESSENERGY_TTZ

c     Stress tensor.

      BSHYDRO_SXX = STRESSENERGY_TXX
      BSHYDRO_SXY = STRESSENERGY_TXY
      BSHYDRO_SXZ = STRESSENERGY_TXZ
      BSHYDRO_SYY = STRESSENERGY_TYY
      BSHYDRO_SYZ = STRESSENERGY_TYZ
      BSHYDRO_SZZ = STRESSENERGY_TZZ

c     Add shift terms.

      if (shift_state .ne. 0) then

         BSHYDRO_RHO = BSHYDRO_RHO + BSHYDRO_IALP**2
     &               *(betax(i,j,k)**2*STRESSENERGY_TXX
     &               + betay(i,j,k)**2*STRESSENERGY_TYY
     &               + betaz(i,j,k)**2*STRESSENERGY_TZZ
     &               +(betax(i,j,k)*betay(i,j,k)*STRESSENERGY_TXY
     &               + betax(i,j,k)*betaz(i,j,k)*STRESSENERGY_TXZ
     &               + betay(i,j,k)*betaz(i,j,k)*STRESSENERGY_TYZ)*2.0D0
     &               -(betax(i,j,k)*STRESSENERGY_TTX
     &               + betay(i,j,k)*STRESSENERGY_TTY
     &               + betaz(i,j,k)*STRESSENERGY_TTZ)*2.0D0)

         BSHYDRO_SX = BSHYDRO_SX + BSHYDRO_IALP
     &              *(betax(i,j,k)*STRESSENERGY_TXX
     &              + betay(i,j,k)*STRESSENERGY_TXY
     &              + betaz(i,j,k)*STRESSENERGY_TXZ)

         BSHYDRO_SY = BSHYDRO_SY + BSHYDRO_IALP
     &              *(betax(i,j,k)*STRESSENERGY_TXY
     &              + betay(i,j,k)*STRESSENERGY_TYY
     &              + betaz(i,j,k)*STRESSENERGY_TYZ)

         BSHYDRO_SZ = BSHYDRO_SZ + BSHYDRO_IALP
     &              *(betax(i,j,k)*STRESSENERGY_TXZ
     &              + betay(i,j,k)*STRESSENERGY_TYZ
     &              + betaz(i,j,k)*STRESSENERGY_TZZ)

      end if

#endif
