/*@@
  @header   BSDXDG_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the first derivatives of the 
  BS metric with respect to x
  @enddesc
@@*/

#ifndef BSDXDG_GUTS
#define BSDXDG_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        BSDXDG_DXDGXX = BSSN_DX_2(ADM_BS_gxx,i,j,k)
        BSDXDG_DXDGXY = BSSN_DX_2(ADM_BS_gxy,i,j,k)
        BSDXDG_DXDGXZ = BSSN_DX_2(ADM_BS_gxz,i,j,k)
        BSDXDG_DXDGYY = BSSN_DX_2(ADM_BS_gyy,i,j,k)
        BSDXDG_DXDGYZ = BSSN_DX_2(ADM_BS_gyz,i,j,k)
        BSDXDG_DXDGZZ = BSSN_DX_2(ADM_BS_gzz,i,j,k)
      else   
        BSDXDG_DXDGXX = BSSN_DX_4(ADM_BS_gxx,i,j,k)
        BSDXDG_DXDGXY = BSSN_DX_4(ADM_BS_gxy,i,j,k)
        BSDXDG_DXDGXZ = BSSN_DX_4(ADM_BS_gxz,i,j,k)
        BSDXDG_DXDGYY = BSSN_DX_4(ADM_BS_gyy,i,j,k)
        BSDXDG_DXDGYZ = BSSN_DX_4(ADM_BS_gyz,i,j,k)
        BSDXDG_DXDGZZ = BSSN_DX_4(ADM_BS_gzz,i,j,k)
      end if
#endif
