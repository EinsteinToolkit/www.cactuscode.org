/*@@
  @header   DXZDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DXZDB_GUTS
#undef DXZDB_DECLARE


