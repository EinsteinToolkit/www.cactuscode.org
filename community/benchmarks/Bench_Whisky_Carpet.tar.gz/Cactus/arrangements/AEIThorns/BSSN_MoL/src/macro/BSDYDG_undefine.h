/*@@
  @header   BSDYDG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef BSDYDG_GUTS
#undef BSDYDG_DECLARE


