c     *********************************************************
c     ***   INCLUDE FILE FOR RADIATIVE BOUNDARY CONDITION   ***
c     *********************************************************

c     The main part of the boundary condition assumes that
c     we have an outgoing radial wave with some speed v0:
c
c
c     var  =  var0 + u(r-v0*t)/r
c
c
c     This implies the following differential equation:
c
c                  i
c     d var  =  - v d var  -  v0 (var - var0) / r
c      t             i
c
c     where  vi = v0 xi/r


c     Find local wave speeds.
 
      rp = r(i,j,k)
      rpi=1.0D0/rp

      vx = v0*x(i,j,k)*rpi
      vy = v0*y(i,j,k)*rpi
      vz = v0*z(i,j,k)*rpi

      svx = sign(one,vx)
      svy = sign(one,vy)
      svz = sign(one,vz)

c     Find x derivative.

      if ((i-2*svx<1).or.(i-2*svx>nx)) then
         derivx = half*(var(i+1,j,k)-var(i-1,j,k))*idx
      else
         derivx = svx*half*(3.0D0*var(i,j,k)
     .          - 4.0D0*var(i-svx,j,k) + var(i-2*svx,j,k))*idx
      end if

c     Find y derivative.

      if ((j-2*svy<1).or.(j-2*svy>ny)) then
         derivy = half*(var(i,j+1,k)-var(i,j-1,k))*idy
      else
         derivy = svy*half*(3.0D0*var(i,j,k)
     .          - 4.0D0*var(i,j-svy,k) + var(i,j-2*svy,k))*idy
      end if

c     Find z derivative.

      if ((k-2*svz<1).or.(k-2*svz>nz)) then
         derivz = half*(var(i,j,k+1)-var(i,j,k-1))*idz
      else
         derivz = svz*half*(3.0D0*var(i,j,k)
     .          - 4.0D0*var(i,j,k-svz) + var(i,j,k-2*svz))*idz
      end if

c     Calculate source term.

      source(i,j,k) = - vx*derivx - vy*derivy - vz*derivz
     .              - v0*(var(i,j,k) - var0)*rpi


c     *****************************************
c     ***   EXTRAPOLATION OF MISSING PART   ***
c     *****************************************

c     Here we try to extrapolate for the part of the boundary
c     that does not behave as a pure wave (i.e. Coulomb type
c     terms caused by infall of the coordinate lines).
c
c     This we do by comparing the source term one grid point
c     away from the boundary (which we already have), to what
c     we would have obtained if we had used the boundary
c     condition there.  The difference gives us an idea of
c     the missing part and we extrapolate that to the boundary
c     assuming a power-law decay.

      if (power >= 0.0D0) then

c        Find local wave speeds.

         ip = i-sx; jp = j-sy; kp = k-sz

         rp = r(ip,jp,kp)
         rpi=1.0D0/rp;

         vx = v0*x(ip,jp,kp)*rpi
         vy = v0*y(ip,jp,kp)*rpi
         vz = v0*z(ip,jp,kp)*rpi

         svx = sign(one,vx)
         svy = sign(one,vy)
         svz = sign(one,vz)

c        Find x derivative.

         if ((ip-2*svx<1).or.(ip-2*svx>nx)) then
            derivx = half*(var(ip+1,jp,kp)-var(ip-1,jp,kp))*idx
         else
            derivx = svx*half*(3.0D0*var(ip,jp,kp)
     .             - 4.0D0*var(ip-svx,jp,kp) + var(ip-2*svx,jp,kp))*idx
         end if

c        Find y derivative.

         if ((jp-2*svy<1).or.(jp-2*svy>ny)) then
            derivy = half*(var(ip,jp+1,kp)-var(ip,jp-1,kp))*idy
         else
            derivy = svy*half*(3.0D0*var(ip,jp,kp)
     .             - 4.0D0*var(ip,jp-svy,kp) + var(ip,jp-2*svy,kp))*idy
         end if

c        Find z derivative.

         if ((kp-2*svz<1).or.(kp-2*svz>nz)) then
            derivz = half*(var(ip,jp,kp+1)-var(ip,jp,kp-1))*idz
         else
            derivz = svz*half*(3.0D0*var(ip,jp,kp)
     .             - 4.0D0*var(ip,jp,kp-svz) + var(ip,jp,kp-2*svz))*idz
         end if

c        Find difference in sources.

         aux = source(ip,jp,kp) + vx*derivx + vy*derivy + vz*derivz
     .       + v0*(var(ip,jp,kp) - var0)*rpi

c        Extrapolate difference and add it to source in boundary.

         if (power.eq.1.0) then
           source(i,j,k) = source(i,j,k) + aux*(rp/r(i,j,k))
         else 
          if (power.eq.2.0) then
            source(i,j,k) = source(i,j,k) + aux*(rp*rp/(r(i,j,k)*r(i,j,k)))
          else 
            if (power.eq.3.0) then
              source(i,j,k) = source(i,j,k) + aux*(rp*rp*rp/(r(i,j,k)*r(i,j,k)*r(i,j,k)))
            else 
              source(i,j,k) = source(i,j,k) + aux*(rp/r(i,j,k))**power
            end if
           end if
         end if

      end if






