/*@@
  @header   BSMOM_guts.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc

  Macro to calculate the BS covariant (lower index) momentum constraints:


        ~ab / ~  ~        ~         \
  M  =  g   | D  A   +  6 A   d phi |  -  2/3  d trK
   i        \  a  bi       bi  a    /           i


  with \tilde{D}_a the covariant derivative with respect
  to the conformal metric.

  Notice that this expression is missing matter terms!

  @enddesc
@@*/

#ifndef BSMOM_GUTS
#define BSMOM_GUTS

#include "BSUPPERMET_guts.h"
#include "DPHI_guts.h"
#include "DTRK_guts.h"
#include "DIVA_guts.h"

#ifdef OPT
      BSMOM_MOMX = DIVA_DIVAX - twothird*DTRK_DXDTRK + 6.0D0
     .   *(BSUPPERMET_UXX*lA(XX,i,j,kc)*DPHI_DXDPHI
     .   + BSUPPERMET_UYY*lA(XY,i,j,kc)*DPHI_DYDPHI
     .   + BSUPPERMET_UZZ*lA(XZ,i,j,kc)*DPHI_DZDPHI
     .   + BSUPPERMET_UXY*(lA(XX,i,j,kc)*DPHI_DYDPHI
     .   + lA(XY,i,j,kc)*DPHI_DXDPHI)
     .   + BSUPPERMET_UXZ*(lA(XX,i,j,kc)*DPHI_DZDPHI
     .   + lA(XZ,i,j,kc)*DPHI_DXDPHI)
     .   + BSUPPERMET_UYZ*(lA(XY,i,j,kc)*DPHI_DZDPHI
     .   + lA(XZ,i,j,kc)*DPHI_DYDPHI))

      BSMOM_MOMY = DIVA_DIVAY - twothird*DTRK_DYDTRK + 6.0D0
     .   *(BSUPPERMET_UXX*lA(XY,i,j,kc)*DPHI_DXDPHI
     .   + BSUPPERMET_UYY*lA(YY,i,j,kc)*DPHI_DYDPHI
     .   + BSUPPERMET_UZZ*lA(YZ,i,j,kc)*DPHI_DZDPHI
     .   + BSUPPERMET_UXY*(lA(XY,i,j,kc)*DPHI_DYDPHI
     .   + lA(YY,i,j,kc)*DPHI_DXDPHI)
     .   + BSUPPERMET_UXZ*(lA(XY,i,j,kc)*DPHI_DZDPHI
     .   + lA(YZ,i,j,kc)*DPHI_DXDPHI)
     .   + BSUPPERMET_UYZ*(lA(YY,i,j,kc)*DPHI_DZDPHI
     .   + lA(YZ,i,j,kc)*DPHI_DYDPHI))

      BSMOM_MOMZ = DIVA_DIVAZ - twothird*DTRK_DZDTRK + 6.0D0
     .   *(BSUPPERMET_UXX*ADM_BS_lA(XZ,kc)*DPHI_DXDPHI
     .   + BSUPPERMET_UYY*ADM_BS_lA(YZ,kc)*DPHI_DYDPHI
     .   + BSUPPERMET_UZZ*ADM_BS_lA(ZZ,kc)*DPHI_DZDPHI
     .   + BSUPPERMET_UXY*(lA(XZ,i,j,kc)*DPHI_DYDPHI
     .   + lA(YZ,i,j,kc)*DPHI_DXDPHI)
     .   + BSUPPERMET_UXZ*(lA(XZ,i,j,kc)*DPHI_DZDPHI
     .   + lA(ZZ,i,j,kc)*DPHI_DXDPHI)
     .   + BSUPPERMET_UYZ*(lA(YZ,i,j,kc)*DPHI_DZDPHI
     .   + lA(ZZ,i,j,kc)*DPHI_DYDPHI))

#else

      BSMOM_MOMX = DIVA_DIVAX - twothird*DTRK_DXDTRK + 6.0D0
     .   *(BSUPPERMET_UXX*ADM_BS_Axx(i,j,k)*DPHI_DXDPHI
     .   + BSUPPERMET_UYY*ADM_BS_Axy(i,j,k)*DPHI_DYDPHI
     .   + BSUPPERMET_UZZ*ADM_BS_Axz(i,j,k)*DPHI_DZDPHI
     .   + BSUPPERMET_UXY*(ADM_BS_Axx(i,j,k)*DPHI_DYDPHI
     .   + ADM_BS_Axy(i,j,k)*DPHI_DXDPHI)
     .   + BSUPPERMET_UXZ*(ADM_BS_Axx(i,j,k)*DPHI_DZDPHI
     .   + ADM_BS_Axz(i,j,k)*DPHI_DXDPHI)
     .   + BSUPPERMET_UYZ*(ADM_BS_Axy(i,j,k)*DPHI_DZDPHI
     .   + ADM_BS_Axz(i,j,k)*DPHI_DYDPHI))

      BSMOM_MOMY = DIVA_DIVAY - twothird*DTRK_DYDTRK + 6.0D0
     .   *(BSUPPERMET_UXX*ADM_BS_Axy(i,j,k)*DPHI_DXDPHI
     .   + BSUPPERMET_UYY*ADM_BS_Ayy(i,j,k)*DPHI_DYDPHI
     .   + BSUPPERMET_UZZ*ADM_BS_Ayz(i,j,k)*DPHI_DZDPHI
     .   + BSUPPERMET_UXY*(ADM_BS_Axy(i,j,k)*DPHI_DYDPHI
     .   + ADM_BS_Ayy(i,j,k)*DPHI_DXDPHI)
     .   + BSUPPERMET_UXZ*(ADM_BS_Axy(i,j,k)*DPHI_DZDPHI
     .   + ADM_BS_Ayz(i,j,k)*DPHI_DXDPHI)
     .   + BSUPPERMET_UYZ*(ADM_BS_Ayy(i,j,k)*DPHI_DZDPHI
     .   + ADM_BS_Ayz(i,j,k)*DPHI_DYDPHI))

      BSMOM_MOMZ = DIVA_DIVAZ - twothird*DTRK_DZDTRK + 6.0D0
     .   *(BSUPPERMET_UXX*ADM_BS_Axz(i,j,k)*DPHI_DXDPHI
     .   + BSUPPERMET_UYY*ADM_BS_Ayz(i,j,k)*DPHI_DYDPHI
     .   + BSUPPERMET_UZZ*ADM_BS_Azz(i,j,k)*DPHI_DZDPHI
     .   + BSUPPERMET_UXY*(ADM_BS_Axz(i,j,k)*DPHI_DYDPHI
     .   + ADM_BS_Ayz(i,j,k)*DPHI_DXDPHI)
     .   + BSUPPERMET_UXZ*(ADM_BS_Axz(i,j,k)*DPHI_DZDPHI
     .   + ADM_BS_Azz(i,j,k)*DPHI_DXDPHI)
     .   + BSUPPERMET_UYZ*(ADM_BS_Ayz(i,j,k)*DPHI_DZDPHI
     .   + ADM_BS_Azz(i,j,k)*DPHI_DYDPHI))
#endif

#endif
  
