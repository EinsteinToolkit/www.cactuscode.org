/*@@
  @header   RICCITF_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for the components of the tracefree Ricci tensor 
  Eq. 19 of the BS paper.
  @enddesc
@@*/


#ifndef RICCITF_GUTS
#define RICCITF_GUTS

#include "BSRICCI_guts.h"
#include "RICCIPHI_guts.h"
#include "TRAA_guts.h"
#include "BSHYDRO_guts.h"

      RICCITF_PHIFAC = exp(4.0d0*ADM_BS_phi(i,j,k))

      IF (conformal_state == 0) THEN
         RICCITF_PSIFAC = 1.0d0
      ELSE
         RICCITF_PSIFAC = psi(i,j,k)**4
      ENDIF

      RICCITF_TEMP = third*RICCITF_PSIFAC*RICCITF_PHIFAC

      if (RfromH.eq.0) then
#include "BSRICSCAL_guts.h"
         RICCITF_TEMP = RICCITF_TEMP*BSRICSCAL_R
#include "BSRICSCAL_undefine.h"
      else
         RICCITF_TEMP = RICCITF_TEMP*(TRAA_TRAA
     &      - twothird*ADM_BS_K(i,j,k)**2 + 2.0D0*eightpi*BSHYDRO_RHO)
      end if

#ifdef OPT
      RICCITF_RXX = BSRICCI_RXX + RICCIPHI_RXX
     &            - RICCITF_TEMP*lg(XX,i,j,kc)
      RICCITF_RXY = BSRICCI_RXY + RICCIPHI_RXY 
     &            - RICCITF_TEMP*lg(XY,i,j,kc)
      RICCITF_RXZ = BSRICCI_RXZ + RICCIPHI_RXZ 
     &            - RICCITF_TEMP*lg(XZ,i,j,kc)
      RICCITF_RYY = BSRICCI_RYY + RICCIPHI_RYY 
     &            - RICCITF_TEMP*lg(YY,i,j,kc)
      RICCITF_RYZ = BSRICCI_RYZ + RICCIPHI_RYZ 
     &            - RICCITF_TEMP*lg(YZ,i,j,kc)
      RICCITF_RZZ = BSRICCI_RZZ + RICCIPHI_RZZ 
     &            - RICCITF_TEMP*lg(ZZ,i,j,kc)
#else
      RICCITF_RXX = BSRICCI_RXX + RICCIPHI_RXX
     &            - RICCITF_TEMP*ADM_BS_gxx(i,j,k)
      RICCITF_RXY = BSRICCI_RXY + RICCIPHI_RXY 
     &            - RICCITF_TEMP*ADM_BS_gxy(i,j,k)
      RICCITF_RXZ = BSRICCI_RXZ + RICCIPHI_RXZ 
     &            - RICCITF_TEMP*ADM_BS_gxz(i,j,k)
      RICCITF_RYY = BSRICCI_RYY + RICCIPHI_RYY 
     &            - RICCITF_TEMP*ADM_BS_gyy(i,j,k)
      RICCITF_RYZ = BSRICCI_RYZ + RICCIPHI_RYZ 
     &            - RICCITF_TEMP*ADM_BS_gyz(i,j,k)
      RICCITF_RZZ = BSRICCI_RZZ + RICCIPHI_RZZ 
     &            - RICCITF_TEMP*ADM_BS_gzz(i,j,k)
#endif

#endif
