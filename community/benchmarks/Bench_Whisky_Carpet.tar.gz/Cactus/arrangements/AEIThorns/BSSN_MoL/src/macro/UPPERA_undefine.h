/*@@
  @header   UPPERA_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to the upper components of the BS conformal TF variable A
  (using the conformal metric)

  @enddesc
@@*/

#undef UPPERA_GUTS
#undef UPPERA_DECLARE

#include "macro/BSUPPERMET_undefine.h"
