/*@@
  @header   BSDYDA_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef BSDYDA_DECLARE
#define BSDYDA_DECLARE

/* Input variables */
#undef  BSDYDA_AXX_JP   
#define BSDYDA_AXX_JP   ADM_BS_Axx(i,j+1,k)
#undef  BSDYDA_AXY_JP   
#define BSDYDA_AXY_JP   ADM_BS_Axy(i,j+1,k)
#undef  BSDYDA_AXZ_JP  
#define BSDYDA_AXZ_JP   ADM_BS_Axz(i,j+1,k)
#undef  BSDYDA_AYY_JP    
#define BSDYDA_AYY_JP   ADM_BS_Ayy(i,j+1,k)
#undef  BSDYDA_AYZ_JP   
#define BSDYDA_AYZ_JP   ADM_BS_Ayz(i,j+1,k)
#undef  BSDYDA_AZZ_JP   
#define BSDYDA_AZZ_JP   ADM_BS_Azz(i,j+1,k)

#undef  BSDYDA_AXX_JM   
#define BSDYDA_AXX_JM   ADM_BS_Axx(i,j-1,k)
#undef  BSDYDA_AXY_JM   
#define BSDYDA_AXY_JM   ADM_BS_Axy(i,j-1,k)
#undef  BSDYDA_AXZ_JM  
#define BSDYDA_AXZ_JM   ADM_BS_Axz(i,j-1,k)
#undef  BSDYDA_AYY_JM    
#define BSDYDA_AYY_JM   ADM_BS_Ayy(i,j-1,k)
#undef  BSDYDA_AYZ_JM   
#define BSDYDA_AYZ_JM   ADM_BS_Ayz(i,j-1,k)
#undef  BSDYDA_AZZ_JM   
#define BSDYDA_AZZ_JM   ADM_BS_Azz(i,j-1,k)

/* Output variables */ 
#undef  BSDYDA_DYDAXX
#define BSDYDA_DYDAXX  bsdyda_dydaxx
#undef  BSDYDA_DYDAXY
#define BSDYDA_DYDAXY  bsdyda_dydaxy
#undef  BSDYDA_DYDAXZ
#define BSDYDA_DYDAXZ  bsdyda_dydaxz
#undef  BSDYDA_DYDAYY
#define BSDYDA_DYDAYY  bsdyda_dydayy
#undef  BSDYDA_DYDAYZ
#define BSDYDA_DYDAYZ  bsdyda_dydayz
#undef  BSDYDA_DYDAZZ
#define BSDYDA_DYDAZZ  bsdyda_dydazz

/* Internal variables */
#undef  BSDYDA_DYFAC
#define BSDYDA_DYFAC   bsdyda_dyfac

/* Declare internal variables */
      CCTK_REAL BSDYDA_DYFAC;

/* Declare output variables */
      CCTK_REAL BSDYDA_DYDAXX;
      CCTK_REAL BSDYDA_DYDAXY;
      CCTK_REAL BSDYDA_DYDAXZ;
      CCTK_REAL BSDYDA_DYDAYY;
      CCTK_REAL BSDYDA_DYDAYZ;
      CCTK_REAL BSDYDA_DYDAZZ;

#endif
