/*@@
  @header   BSHAM_guts.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc

  Macro to calculate the BS Hamiltonian constraint:

             ~  ~ij
  H  =  R  - A  A   +  2/3  trK
              ij

  with R the Ricci scalar of the physical metric, and
  with the indeices in tilde{A}_{ij} raised with the
  conformal metric.

  Notice that this expression is missing matter terms!

  @enddesc
@@*/

#ifndef BSHAM_GUTS
#define BSHAM_GUTS

#include "macro/TRAA_guts.h"
#include "macro/BSRICSCAL_guts.h"
 
      BSHAM_BSHAM = BSRICSCAL_R - TRAA_TRAA
     .            + twothird*ADM_BS_K(i,j,k)**2

#endif
  
