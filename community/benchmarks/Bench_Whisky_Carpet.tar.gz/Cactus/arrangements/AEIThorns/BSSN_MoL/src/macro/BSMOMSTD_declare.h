/*@@
  @header   BSMOMSTD_declare.h
  @date     July 2002
  @author   Denis Pollney
  @desc

  Declarations for BS covariant momentum constraints.

  @enddesc
@@*/

#ifndef BSMOMSTD_DECLARE
#define BSMOMSTD_DECLARE

#include "macro/DPHI_declare.h"
#include "macro/BSMOM_declare.h"

#undef  BSMOMSTD_MOMX
#define BSMOMSTD_MOMX bsmomstd_momx
#undef  BSMOMSTD_MOMY
#define BSMOMSTD_MOMY bsmomstd_momy
#undef  BSMOMSTD_MOMZ
#define BSMOMSTD_MOMZ bsmomstd_momz

       CCTK_REAL BSMOMSTD_MOMX
       CCTK_REAL BSMOMSTD_MOMY
       CCTK_REAL BSMOMSTD_MOMZ

#endif
