/*@@
  @header   BSDG_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all the first derivatives of the 
  BS metric with respect to x, y, z

  @enddesc
@@*/

#ifndef BSDG_GUTS
#define BSDG_GUTS

#include "macro/BSDXDG_guts.h"
#include "macro/BSDYDG_guts.h"
#include "macro/BSDZDG_guts.h"

#endif
