/*@@
  @header   BSHAM_undefine.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef BSHAM_DECLARE
#undef BSHAM_GUTS

#include "macro/TRAA_undefine.h"
#include "macro/BSRICSCAL_undefine.h"




  
