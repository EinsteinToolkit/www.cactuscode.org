/*@@
  @header   TRAA_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef TRAA_GUTS
#undef TRAA_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/AA_undefine.h"


  
