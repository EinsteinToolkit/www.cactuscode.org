/*@@
  @header   BSRICSCAL_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for Ricci scalar where the Ricci tensor is given
  by Eq ?? of BS
  @enddesc
@@*/


#ifndef BSRICSCAL_GUTS
#define BSRICSCAL_GUTS

#include "macro/BSUPPERMET_guts.h"
#include "macro/BSRICCI_guts.h"
#include "macro/RICCIPHI_guts.h"

      BSRICSCAL_RXX = BSRICCI_RXX + RICCIPHI_RXX
      BSRICSCAL_RXY = BSRICCI_RXY + RICCIPHI_RXY
      BSRICSCAL_RXZ = BSRICCI_RXZ + RICCIPHI_RXZ
      BSRICSCAL_RYY = BSRICCI_RYY + RICCIPHI_RYY
      BSRICSCAL_RYZ = BSRICCI_RYZ + RICCIPHI_RYZ
      BSRICSCAL_RZZ = BSRICCI_RZZ + RICCIPHI_RZZ

      BSRICSCAL_R = BSUPPERMET_UXX*BSRICSCAL_RXX
     &            + BSUPPERMET_UYY*BSRICSCAL_RYY
     &            + BSUPPERMET_UZZ*BSRICSCAL_RZZ
     &            +(BSUPPERMET_UXY*BSRICSCAL_RXY
     &            + BSUPPERMET_UXZ*BSRICSCAL_RXZ
     &            + BSUPPERMET_UYZ*BSRICSCAL_RYZ)*2.0d0

      BSRICSCAL_R = BSRICSCAL_R*exp(-4.0d0*ADM_BS_PHI(i,j,k))

#endif
