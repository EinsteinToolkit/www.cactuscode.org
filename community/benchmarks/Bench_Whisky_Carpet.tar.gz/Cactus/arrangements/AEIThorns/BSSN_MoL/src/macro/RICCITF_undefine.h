/*@@
  @header   RICCITF_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for the components of the tracefree Ricci tensor 
  Eq. 19 of the BS paper.
  @enddesc
@@*/

#undef RICCITF_GUTS
#undef RICCITF_DECLARE

#include "macro/BSRICCI_undefine.h"
#include "macro/RICCIPHI_undefine.h"
#include "macro/BSRICSCAL_undefine.h"
#include "macro/TRAA_undefine.h"
#include "macro/BSHYDRO_undefine.h"

