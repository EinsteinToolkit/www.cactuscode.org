/*@@
  @header   BSTRS_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the trace of the BS matter variable
  Sij, note that it uses the definition of Sij in Eq 8
  to do this
  scheme
  @enddesc
@@*/

#ifndef BSTRS_GUTS
#define BSTRS_GUTS

/* This gives up the Tmunus */

#include "macro/BSUPPERMET_guts.h"
#include "macro/BSHYDRO_guts.h"

      BSTRS_TRS = BSUPPERMET_UXX*BSHYDRO_SXX 
     &          + BSUPPERMET_UYY*BSHYDRO_SYY
     &          + BSUPPERMET_UZZ*BSHYDRO_SZZ
     &          +(BSUPPERMET_UXY*BSHYDRO_SXY
     &          + BSUPPERMET_UXZ*BSHYDRO_SXZ
     &          + BSUPPERMET_UYZ*BSHYDRO_SYZ)*2.0d0

      BSTRS_TRS = BSTRS_TRS*exp(-4.0d0*ADM_BS_PHI(i,j,k))

#endif
