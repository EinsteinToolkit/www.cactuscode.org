/*@@
  @header   BSUPPERMET_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to the components of upper BS metric

  @enddesc
@@*/

#undef BSUPPERMET_GUTS
#undef BSUPPERMET_DECLARE

#include "macro/BSDETG_undefine.h"
