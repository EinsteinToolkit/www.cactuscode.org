/*@@
  @header   DDPHI_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#ifndef DDPHI_DECLARE
#define DDPHI_DECLARE

/* Input variables */
#undef  DDPHI_PHI
#define DDPHI_PHI ADM_BS_phi(i,j,k)
#undef  DDPHI_PHI_IP 
#define DDPHI_PHI_IP ADM_BS_phi(i+1,j,k)
#undef  DDPHI_PHI_IM
#define DDPHI_PHI_IM ADM_BS_phi(i-1,j,k)
#undef  DDPHI_PHI_JP 
#define DDPHI_PHI_JP ADM_BS_phi(i,j+1,k)
#undef  DDPHI_PHI_JM 
#define DDPHI_PHI_JM ADM_BS_phi(i,j-1,k)
#undef  DDPHI_PHI_KP 
#define DDPHI_PHI_KP ADM_BS_phi(i,j,k+1)
#undef  DDPHI_PHI_KM
#define DDPHI_PHI_KM ADM_BS_phi(i,j,k-1)
#undef  DDPHI_PHI_IPJP 
#define DDPHI_PHI_IPJP ADM_BS_phi(i+1,j+1,k)
#undef  DDPHI_PHI_IPJM 
#define DDPHI_PHI_IPJM ADM_BS_phi(i+1,j-1,k)
#undef  DDPHI_PHI_IMJP 
#define DDPHI_PHI_IMJP ADM_BS_phi(i-1,j+1,k)
#undef  DDPHI_PHI_IMJM 
#define DDPHI_PHI_IMJM ADM_BS_phi(i-1,j-1,k)
#undef  DDPHI_PHI_IPKP 
#define DDPHI_PHI_IPKP ADM_BS_phi(i+1,j,k+1)
#undef  DDPHI_PHI_IPKM 
#define DDPHI_PHI_IPKM ADM_BS_phi(i+1,j,k-1)
#undef  DDPHI_PHI_IMKP 
#define DDPHI_PHI_IMKP ADM_BS_phi(i-1,j,k+1)
#undef  DDPHI_PHI_IMKM 
#define DDPHI_PHI_IMKM ADM_BS_phi(i-1,j,k-1)
#undef  DDPHI_PHI_JPKP 
#define DDPHI_PHI_JPKP ADM_BS_phi(i,j+1,k+1)
#undef  DDPHI_PHI_JPKM 
#define DDPHI_PHI_JPKM ADM_BS_phi(i,j+1,k-1)
#undef  DDPHI_PHI_JMKP 
#define DDPHI_PHI_JMKP ADM_BS_phi(i,j-1,k+1)
#undef  DDPHI_PHI_JMKM 
#define DDPHI_PHI_JMKM ADM_BS_phi(i,j-1,k-1)
#undef  DDPHI_DXDPSI_O_PSI 
#define DDPHI_DXDPSI_O_PSI psix(i,j,k)
#undef  DDPHI_DYDPSI_O_PSI 
#define DDPHI_DYDPSI_O_PSI psiy(i,j,k)
#undef  DDPHI_DZDPSI_O_PSI 
#define DDPHI_DZDPSI_O_PSI psiz(i,j,k)
#undef  DDPHI_DXXDPSI_O_PSI 
#define DDPHI_DXXDPSI_O_PSI psixx(i,j,k)
#undef  DDPHI_DXYDPSI_O_PSI 
#define DDPHI_DXYDPSI_O_PSI psixy(i,j,k)
#undef  DDPHI_DXZDPSI_O_PSI 
#define DDPHI_DXZDPSI_O_PSI psixz(i,j,k)
#undef  DDPHI_DYYDPSI_O_PSI 
#define DDPHI_DYYDPSI_O_PSI psiyy(i,j,k)
#undef  DDPHI_DYZDPSI_O_PSI 
#define DDPHI_DYZDPSI_O_PSI psiyz(i,j,k)
#undef  DDPHI_DZZDPSI_O_PSI 
#define DDPHI_DZZDPSI_O_PSI psizz(i,j,k)

/* Output variables */ 
#undef  DDPHI_DXXDPHI
#define DDPHI_DXXDPHI ddphi_dxxda
#undef  DDPHI_DXYDPHI
#define DDPHI_DXYDPHI ddphi_dxyda
#undef  DDPHI_DXZDPHI
#define DDPHI_DXZDPHI ddphi_dxzda
#undef  DDPHI_DYYDPHI
#define DDPHI_DYYDPHI ddphi_dyyda
#undef  DDPHI_DYZDPHI
#define DDPHI_DYZDPHI ddphi_dyzda
#undef  DDPHI_DZZDPHI
#define DDPHI_DZZDPHI ddphi_dzzda

/* Internal variables */
#undef  DDPHI_OODX2   
#define DDPHI_OODX2 ddphi_oodx2
#undef  DDPHI_OODY2   
#define DDPHI_OODY2 ddphi_oody2
#undef  DDPHI_OODZ2   
#define DDPHI_OODZ2 ddphi_oodz2
#undef  DDPHI_OO4DXDY
#define DDPHI_OO4DXDY ddphi_oo4dxdy
#undef  DDPHI_OO4DXDZ
#define DDPHI_OO4DXDZ ddphi_oo4dxdz
#undef  DDPHI_OO4DYDZ
#define DDPHI_OO4DYDZ ddphi_oo4dydz
#undef  DDPHI_DX
#define DDPHI_DX dx
#undef  DDPHI_DY
#define DDPHI_DY dy
#undef  DDPHI_DZ
#define DDPHI_DZ dz
#undef  DDPHI_FACXX
#define DDPHI_FACXX ddphi_facxx
#undef  DDPHI_FACXY
#define DDPHI_FACXY ddphi_facxy
#undef  DDPHI_FACXZ
#define DDPHI_FACXZ ddphi_facxz
#undef  DDPHI_FACYY
#define DDPHI_FACYY ddphi_facyy
#undef  DDPHI_FACYZ
#define DDPHI_FACYZ ddphi_facyz
#undef  DDPHI_FACZZ
#define DDPHI_FACZZ ddphi_faczz
#undef  DDPHI_TWOPHI
#define DDPHI_TWOPHI ddphi_twophi

/* Declare internal variables */
      CCTK_REAL DDPHI_OODX2
      CCTK_REAL DDPHI_OODY2
      CCTK_REAL DDPHI_OODZ2
      CCTK_REAL DDPHI_OO4DXDY
      CCTK_REAL DDPHI_OO4DXDZ
      CCTK_REAL DDPHI_OO4DYDZ
      CCTK_REAL DDPHI_FACXX
      CCTK_REAL DDPHI_FACXY
      CCTK_REAL DDPHI_FACXZ
      CCTK_REAL DDPHI_FACYY
      CCTK_REAL DDPHI_FACYZ
      CCTK_REAL DDPHI_FACZZ
      CCTK_REAL DDPHI_TWOPHI

/* Declare output variables */
      CCTK_REAL DDPHI_DXXDPHI
      CCTK_REAL DDPHI_DXYDPHI
      CCTK_REAL DDPHI_DXZDPHI
      CCTK_REAL DDPHI_DYYDPHI
      CCTK_REAL DDPHI_DYZDPHI
      CCTK_REAL DDPHI_DZZDPHI

#endif



