/*@@
  @header   DDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate all the second derivatives of the shift.
  @enddesc
@@*/ 

#ifndef DDB_GUTS
#define DDB_GUTS

#include "macro/DXXDB_guts.h"
#include "macro/DYYDB_guts.h"
#include "macro/DZZDB_guts.h"

#include "macro/DXYDB_guts.h"
#include "macro/DXZDB_guts.h"
#include "macro/DYZDB_guts.h"

#endif
