/*@@
  @header   DDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/ 

#undef DDB_GUTS
#undef DDB_DECLARE

#include "macro/DXXDB_undefine.h"
#include "macro/DXYDB_undefine.h"
#include "macro/DXZDB_undefine.h"
#include "macro/DYYDB_undefine.h"
#include "macro/DYZDB_undefine.h"
#include "macro/DZZDB_undefine.h"
