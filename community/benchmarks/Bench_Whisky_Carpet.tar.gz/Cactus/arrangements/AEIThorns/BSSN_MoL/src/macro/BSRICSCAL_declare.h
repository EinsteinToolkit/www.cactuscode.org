/*@@
  @header   BSRICSCAL_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for Ricci scalar where the Ricci tensor is given
  by Eq ?? of BS
  @enddesc
@@*/

#ifndef BSRICSCAL_DECLARE
#define BSRICSCAL_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/BSRICCI_declare.h"
#include "macro/RICCIPHI_declare.h"

#undef  BSRICSCAL_RXX
#define BSRICSCAL_RXX bsricscal_Rxx
#undef  BSRICSCAL_RXY
#define BSRICSCAL_RXY bsricscal_Rxy
#undef  BSRICSCAL_RXZ
#define BSRICSCAL_RXZ bsricscal_Rxz
#undef  BSRICSCAL_RYY
#define BSRICSCAL_RYY bsricscal_Ryy
#undef  BSRICSCAL_RYZ
#define BSRICSCAL_RYZ bsricscal_Ryz
#undef  BSRICSCAL_RZZ
#define BSRICSCAL_RZZ bsricscal_Rzz

#undef  BSRICSCAL_R
#define BSRICSCAL_R bsricscal_R

      CCTK_REAL BSRICSCAL_RXX
      CCTK_REAL BSRICSCAL_RXY
      CCTK_REAL BSRICSCAL_RXZ
      CCTK_REAL BSRICSCAL_RYY
      CCTK_REAL BSRICSCAL_RYZ
      CCTK_REAL BSRICSCAL_RZZ
      CCTK_REAL BSRICSCAL_R

#endif
