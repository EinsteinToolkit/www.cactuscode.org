/*@@
  @header   DYYDB_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DYYDB_GUTS
#undef DYYDB_DECLARE


