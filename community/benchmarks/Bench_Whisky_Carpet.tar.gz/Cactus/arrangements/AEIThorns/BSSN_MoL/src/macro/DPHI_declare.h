/*@@
  @header   DPHI_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all first spatial derivative of BS conformal phi
  @enddesc
@@*/

#ifndef DPHI_DECLARE
#define DPHI_DECLARE

#ifdef FCODE

/* Input variables */
#undef  DPHI_PHI_IP 
#define DPHI_PHI_IP ADM_BS_phi(i+1,j,k)
#undef  DPHI_PHI_IM
#define DPHI_PHI_IM ADM_BS_phi(i-1,j,k)
#undef  DPHI_PHI_JP 
#define DPHI_PHI_JP ADM_BS_phi(i,j+1,k)
#undef  DPHI_PHI_JM 
#define DPHI_PHI_JM ADM_BS_phi(i,j-1,k)
#undef  DPHI_PHI_KP 
#define DPHI_PHI_KP ADM_BS_phi(i,j,k+1)
#undef  DPHI_PHI_KM
#define DPHI_PHI_KM ADM_BS_phi(i,j,k-1)

#undef  DPHI_DXDPSI_O_PSI 
#define DPHI_DXDPSI_O_PSI psix(i,j,k)
#undef  DPHI_DYDPSI_O_PSI 
#define DPHI_DYDPSI_O_PSI psiy(i,j,k)
#undef  DPHI_DZDPSI_O_PSI 
#define DPHI_DZDPSI_O_PSI psiz(i,j,k)

/* Output variables */ 
#undef  DPHI_DXDPHI
#define DPHI_DXDPHI  dphi_dxdphi
#undef  DPHI_DYDPHI
#define DPHI_DYDPHI  dphi_dydphi
#undef  DPHI_DZDPHI
#define DPHI_DZDPHI  dphi_dzdphi

/* Internal variables */
#undef  DPHI_OO2DX   
#define DPHI_OO2DX dphi_oo2dx
#undef  DPHI_OO2DY   
#define DPHI_OO2DY dphi_oo2dy
#undef  DPHI_OO2DZ   
#define DPHI_OO2DZ dphi_oo2dz
#undef  DPHI_DX   
#define DPHI_DX dx
#undef  DPHI_DY   
#define DPHI_DY dy
#undef  DPHI_DZ   
#define DPHI_DZ dz
#undef  DPHI_FACX 
#define DPHI_FACX dphi_facx
#undef  DPHI_FACY 
#define DPHI_FACY dphi_facy
#undef  DPHI_FACZ 
#define DPHI_FACZ dphi_facz

/* Declare internal variables */
      CCTK_REAL DPHI_OO2DX
      CCTK_REAL DPHI_OO2DY
      CCTK_REAL DPHI_OO2DZ
      CCTK_REAL DPHI_FACX
      CCTK_REAL DPHI_FACY
      CCTK_REAL DPHI_FACZ

/* Declare output variables */
      CCTK_REAL DPHI_DXDPHI
      CCTK_REAL DPHI_DYDPHI
      CCTK_REAL DPHI_DZDPHI

#endif


#ifdef CCODE

/* Input variables */
#undef  DPHI_PHI_IP 
#define DPHI_PHI_IP ADM_BS_phi[ di + ijk]
#undef  DPHI_PHI_IM
#define DPHI_PHI_IM ADM_BS_phi[-di + ijk]
#undef  DPHI_PHI_JP 
#define DPHI_PHI_JP ADM_BS_phi[ dj + ijk]
#undef  DPHI_PHI_JM 
#define DPHI_PHI_JM ADM_BS_phi[-dj + ijk]
#undef  DPHI_PHI_KP 
#define DPHI_PHI_KP ADM_BS_phi[ dk + ijk]
#undef  DPHI_PHI_KM
#define DPHI_PHI_KM ADM_BS_phi[-dk + ijk]

/* Output variables */ 
#undef  DPHI_DXDPHI
#define DPHI_DXDPHI dphi_dxdphi
#undef  DPHI_DYDPHI
#define DPHI_DYDPHI dphi_dydphi
#undef  DPHI_DZDPHI
#define DPHI_DZDPHI dphi_dzdphi

/* Internal variables */
#undef  DPHI_OO2DX   
#define DPHI_OO2DX dphi_oo2dx
#undef  DPHI_OO2DY   
#define DPHI_OO2DY dphi_oo2dy
#undef  DPHI_OO2DZ   
#define DPHI_OO2DZ dphi_oo2dz

/* Declare internal variables */
      CCTK_REAL DPHI_OO2DX;
      CCTK_REAL DPHI_OO2DY;
      CCTK_REAL DPHI_OO2DZ;

/* Declare output variables */
      CCTK_REAL DPHI_DXDPHI;
      CCTK_REAL DPHI_DYDPHI;
      CCTK_REAL DPHI_DZDPHI;

#endif

#endif


