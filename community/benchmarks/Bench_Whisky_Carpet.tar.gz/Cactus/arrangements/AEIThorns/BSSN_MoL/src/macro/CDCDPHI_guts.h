/*@@
  @header   CDCDPHI_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all second covariant spatial derivative of phi
  wrt BS metric

  That is phi_{;ij}

  @enddesc
@@*/

#ifndef CDCDPHI_GUTS
#define CDCDPHI_GUTS

#include "macro/DPHI_guts.h"
#include "macro/DDPHI_guts.h"
#include "macro/BSCHR2_guts.h"

      CDCDPHI_CDXXDPHI = (DDPHI_DXXDPHI-BSCHR2_XXX*DPHI_DXDPHI
     &          -BSCHR2_YXX*DPHI_DYDPHI-BSCHR2_ZXX*DPHI_DZDPHI)
      CDCDPHI_CDXYDPHI = (DDPHI_DXYDPHI-BSCHR2_XXY*DPHI_DXDPHI
     &          -BSCHR2_YXY*DPHI_DYDPHI-BSCHR2_ZXY*DPHI_DZDPHI)
      CDCDPHI_CDXZDPHI = (DDPHI_DXZDPHI-BSCHR2_XXZ*DPHI_DXDPHI
     &          -BSCHR2_YXZ*DPHI_DYDPHI-BSCHR2_ZXZ*DPHI_DZDPHI)
      CDCDPHI_CDYYDPHI = (DDPHI_DYYDPHI-BSCHR2_XYY*DPHI_DXDPHI
     &          -BSCHR2_YYY*DPHI_DYDPHI-BSCHR2_ZYY*DPHI_DZDPHI)
      CDCDPHI_CDYZDPHI = (DDPHI_DYZDPHI-BSCHR2_XYZ*DPHI_DXDPHI
     &          -BSCHR2_YYZ*DPHI_DYDPHI-BSCHR2_ZYZ*DPHI_DZDPHI)
      CDCDPHI_CDZZDPHI = (DDPHI_DZZDPHI-BSCHR2_XZZ*DPHI_DXDPHI
     &          -BSCHR2_YZZ*DPHI_DYDPHI-BSCHR2_ZZZ*DPHI_DZDPHI)

#endif

