/*@@
  @header   GAMMASOURCES_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
    Macro for source term of the BS Gamma evolution equation 
    Eq. 24 of the BS paper.
  @enddesc
@@*/

#ifndef GAMMASOURCES_DECLARE
#define GAMMASOURCES_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DA_declare.h"
#include "macro/BSCHR2_declare.h"
#include "macro/UPPERA_declare.h"
#include "macro/DPHI_declare.h"
#include "macro/DTRK_declare.h"
#include "macro/BSUPPERMET_declare.h"
#include "macro/BSHYDRO_declare.h"

/* Internal variables */

#undef  GAMMASOURCES_TERM1 
#define GAMMASOURCES_TERM1   gammasources_term1
#undef  GAMMASOURCES_TERM2A 
#define GAMMASOURCES_TERM2A  gammasources_term2a
#undef  GAMMASOURCES_TERM2B 
#define GAMMASOURCES_TERM2B  gammasources_term2b
#undef  GAMMASOURCES_TERM2C 
#define GAMMASOURCES_TERM2C  gammasources_term2c
#undef  GAMMASOURCES_TERM2D 
#define GAMMASOURCES_TERM2D  gammasources_term2d

#undef  GAMMASOURCES_METRICX 
#define GAMMASOURCES_METRICX gammasources_metricx
#undef  GAMMASOURCES_METRICY 
#define GAMMASOURCES_METRICY gammasources_metricy
#undef  GAMMASOURCES_METRICZ 
#define GAMMASOURCES_METRICZ gammasources_metricz

#undef  GAMMASOURCES_MATTERX 
#define GAMMASOURCES_MATTERX gammasources_matterx
#undef  GAMMASOURCES_MATTERY 
#define GAMMASOURCES_MATTERY gammasources_mattery
#undef  GAMMASOURCES_MATTERZ 
#define GAMMASOURCES_MATTERZ gammasources_matterz

#undef  GAMMASOURCES_TWOALP
#define GAMMASOURCES_TWOALP  gammasources_twoalp

      CCTK_REAL GAMMASOURCES_TERM1
      CCTK_REAL GAMMASOURCES_TERM2A
      CCTK_REAL GAMMASOURCES_TERM2B
      CCTK_REAL GAMMASOURCES_TERM2C
      CCTK_REAL GAMMASOURCES_TERM2D

      CCTK_REAL GAMMASOURCES_METRICX
      CCTK_REAL GAMMASOURCES_METRICY
      CCTK_REAL GAMMASOURCES_METRICZ

      CCTK_REAL GAMMASOURCES_MATTERX
      CCTK_REAL GAMMASOURCES_MATTERY
      CCTK_REAL GAMMASOURCES_MATTERZ

      CCTK_REAL GAMMASOURCES_TWOALP

#endif











