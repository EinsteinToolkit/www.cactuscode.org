/*@@
  @header   NABPHI_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the nabla operator acting on phi.
  @enddesc
@@*/

#ifndef NABPHI_GUTS
#define NABPHI_GUTS

#include "macro/BSUPPERMET_guts.h"
#include "macro/CDCDPHI_guts.h"

      NABPHI_NABPHI = BSUPPERMET_UXX*CDCDPHI_CDXXDPHI
     &              + BSUPPERMET_UYY*CDCDPHI_CDYYDPHI
     &              + BSUPPERMET_UZZ*CDCDPHI_CDZZDPHI
     &              +(BSUPPERMET_UXY*CDCDPHI_CDXYDPHI
     &              + BSUPPERMET_UXZ*CDCDPHI_CDXZDPHI
     &              + BSUPPERMET_UYZ*CDCDPHI_CDYZDPHI)*2.0d0

#endif

