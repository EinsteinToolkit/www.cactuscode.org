/*@@
  @header   CDCDPHI_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc

  @enddesc
@@*/

#ifndef CDCDPHI_DECLARE
#define CDCDPHI_DECLARE

#include "macro/DPHI_declare.h"
#include "macro/DDPHI_declare.h"
#include "macro/BSCHR2_declare.h"

/* Output variables */ 
#undef  CDCDPHI_CDXXDPHI
#define CDCDPHI_CDXXDPHI cdcdphi_cdxxdphi
#undef  CDCDPHI_CDXYDPHI
#define CDCDPHI_CDXYDPHI cdcdphi_cdxydphi
#undef  CDCDPHI_CDXZDPHI
#define CDCDPHI_CDXZDPHI cdcdphi_cdxzdphi
#undef  CDCDPHI_CDYYDPHI
#define CDCDPHI_CDYYDPHI cdcdphi_cdyydphi
#undef  CDCDPHI_CDYZDPHI
#define CDCDPHI_CDYZDPHI cdcdphi_cdyzdphi
#undef  CDCDPHI_CDZZDPHI
#define CDCDPHI_CDZZDPHI cdcdphi_cdzzdphi

/* Declare output variables */
      CCTK_REAL CDCDPHI_CDXXDPHI
      CCTK_REAL CDCDPHI_CDXYDPHI
      CCTK_REAL CDCDPHI_CDXZDPHI
      CCTK_REAL CDCDPHI_CDYYDPHI
      CCTK_REAL CDCDPHI_CDYZDPHI
      CCTK_REAL CDCDPHI_CDZZDPHI

#endif

