/*@@
  @header   DDK_undefine.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef DDK_GUTS
#undef DDK_DECLARE

