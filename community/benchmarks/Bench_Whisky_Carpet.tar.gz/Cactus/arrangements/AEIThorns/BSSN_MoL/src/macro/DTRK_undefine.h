/*@@
  @header   DTRK_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all first spatial derivative of BS variable trk
  @enddesc
@@*/

#undef DTRK_GUTS
#undef DTRK_DECLARE



