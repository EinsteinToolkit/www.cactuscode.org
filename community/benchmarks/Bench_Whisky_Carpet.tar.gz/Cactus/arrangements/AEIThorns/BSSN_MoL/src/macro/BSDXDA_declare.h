/*@@
  @header   BSDXDA_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef BSDXDA_DECLARE
#define BSDXDA_DECLARE

/* Input variables */
#ifdef OPT

#undef  BSDXDA_AXX_IP
#define BSDXDA_AXX_IP   lA(XX,i+1,j,kc)
#undef  BSDXDA_AXY_IP
#define BSDXDA_AXY_IP   lA(XY,i+1,j,kc)
#undef  BSDXDA_AXZ_IP
#define BSDXDA_AXZ_IP   lA(XZ,i+1,j,kc)
#undef  BSDXDA_AYY_IP
#define BSDXDA_AYY_IP   lA(YY,i+1,j,kc)
#undef  BSDXDA_AYZ_IP
#define BSDXDA_AYZ_IP   lA(YZ,i+1,j,kc)
#undef  BSDXDA_AZZ_IP
#define BSDXDA_AZZ_IP   lA(ZZ,i+1,j,kc)

#undef  BSDXDA_AXX_IM
#define BSDXDA_AXX_IM   lA(XX,i-1,j,kc)
#undef  BSDXDA_AXY_IM
#define BSDXDA_AXY_IM   lA(XY,i-1,j,kc)
#undef  BSDXDA_AXZ_IM
#define BSDXDA_AXZ_IM   lA(XZ,i-1,j,kc)
#undef  BSDXDA_AYY_IM
#define BSDXDA_AYY_IM   lA(YY,i-1,j,kc)
#undef  BSDXDA_AYZ_IM
#define BSDXDA_AYZ_IM   lA(YZ,i-1,j,kc)
#undef  BSDXDA_AZZ_IM
#define BSDXDA_AZZ_IM   lA(ZZ,i-1,j,kc)

#else

#undef  BSDXDA_AXX_IP
#define BSDXDA_AXX_IP   ADM_BS_Axx(i+1,j,k)
#undef  BSDXDA_AXY_IP
#define BSDXDA_AXY_IP   ADM_BS_Axy(i+1,j,k)
#undef  BSDXDA_AXZ_IP
#define BSDXDA_AXZ_IP   ADM_BS_Axz(i+1,j,k)
#undef  BSDXDA_AYY_IP
#define BSDXDA_AYY_IP   ADM_BS_Ayy(i+1,j,k)
#undef  BSDXDA_AYZ_IP
#define BSDXDA_AYZ_IP   ADM_BS_Ayz(i+1,j,k)
#undef  BSDXDA_AZZ_IP
#define BSDXDA_AZZ_IP   ADM_BS_Azz(i+1,j,k)

#undef  BSDXDA_AXX_IM   
#define BSDXDA_AXX_IM   ADM_BS_Axx(i-1,j,k)
#undef  BSDXDA_AXY_IM   
#define BSDXDA_AXY_IM   ADM_BS_Axy(i-1,j,k)
#undef  BSDXDA_AXZ_IM  
#define BSDXDA_AXZ_IM   ADM_BS_Axz(i-1,j,k)
#undef  BSDXDA_AYY_IM    
#define BSDXDA_AYY_IM   ADM_BS_Ayy(i-1,j,k)
#undef  BSDXDA_AYZ_IM   
#define BSDXDA_AYZ_IM   ADM_BS_Ayz(i-1,j,k)
#undef  BSDXDA_AZZ_IM   
#define BSDXDA_AZZ_IM   ADM_BS_Azz(i-1,j,k)

#endif

/* Output variables */ 
#undef  BSDXDA_DXDAXX
#define BSDXDA_DXDAXX  bsdxda_dxdaxx
#undef  BSDXDA_DXDAXY
#define BSDXDA_DXDAXY  bsdxda_dxdaxy
#undef  BSDXDA_DXDAXZ
#define BSDXDA_DXDAXZ  bsdxda_dxdaxz
#undef  BSDXDA_DXDAYY
#define BSDXDA_DXDAYY  bsdxda_dxdayy
#undef  BSDXDA_DXDAYZ
#define BSDXDA_DXDAYZ  bsdxda_dxdayz
#undef  BSDXDA_DXDAZZ
#define BSDXDA_DXDAZZ  bsdxda_dxdazz

/* Internal variables */
#undef  BSDXDA_DXFAC
#define BSDXDA_DXFAC   bsdxda_dxfac

/* Declare internal variables */
      CCTK_REAL BSDXDA_DXFAC;

/* Declare output variables */
      CCTK_REAL BSDXDA_DXDAXX;
      CCTK_REAL BSDXDA_DXDAXY;
      CCTK_REAL BSDXDA_DXDAXZ;
      CCTK_REAL BSDXDA_DXDAYY;
      CCTK_REAL BSDXDA_DXDAYZ;
      CCTK_REAL BSDXDA_DXDAZZ;

#endif
