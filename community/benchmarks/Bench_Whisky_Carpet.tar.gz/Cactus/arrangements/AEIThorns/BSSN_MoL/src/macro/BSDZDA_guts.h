/*@@
  @header   BSDZDA_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the first derivatives of the 
     BS Aij with respect to x
  @enddesc
@@*/

#ifndef BSDZDA_GUTS
#define BSDZDA_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        BSDZDA_DZDAXX = BSSN_DZ_2(ADM_BS_Axx,i,j,k)
        BSDZDA_DZDAXY = BSSN_DZ_2(ADM_BS_Axy,i,j,k)
        BSDZDA_DZDAXZ = BSSN_DZ_2(ADM_BS_Axz,i,j,k)
        BSDZDA_DZDAYY = BSSN_DZ_2(ADM_BS_Ayy,i,j,k)
        BSDZDA_DZDAYZ = BSSN_DZ_2(ADM_BS_Ayz,i,j,k)
        BSDZDA_DZDAZZ = BSSN_DZ_2(ADM_BS_Azz,i,j,k)
     else
        BSDZDA_DZDAXX = BSSN_DZ_4(ADM_BS_Axx,i,j,k)
        BSDZDA_DZDAXY = BSSN_DZ_4(ADM_BS_Axy,i,j,k)
        BSDZDA_DZDAXZ = BSSN_DZ_4(ADM_BS_Axz,i,j,k)
        BSDZDA_DZDAYY = BSSN_DZ_4(ADM_BS_Ayy,i,j,k)
        BSDZDA_DZDAYZ = BSSN_DZ_4(ADM_BS_Ayz,i,j,k)
        BSDZDA_DZDAZZ = BSSN_DZ_4(ADM_BS_Azz,i,j,k)
      end if

#endif
