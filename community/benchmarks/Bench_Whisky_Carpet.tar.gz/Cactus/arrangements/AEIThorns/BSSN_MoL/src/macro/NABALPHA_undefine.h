/*@@
  @header   NABALPHA_undefine.h
  @date     October 99
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef NABALPHA_GUTS
#undef NABALPHA_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/CDCDALPHA_undefine.h"

