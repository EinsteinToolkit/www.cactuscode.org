/*@@
  @header   SHIFTGAMMA_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
  @@*/

#ifndef SHIFTGAMMA_DECLARE
#define SHIFTGAMMA_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_declare.h"
#include "macro/DDB_declare.h"
#include "macro/BSUPPERMET_declare.h"
#include "macro/BSGAMMA_declare.h"

/* Output variables */

#undef  SHIFTGAMMAX
#define SHIFTGAMMAX shiftgammax
#undef  SHIFTGAMMAY
#define SHIFTGAMMAY shiftgammay
#undef  SHIFTGAMMAZ
#define SHIFTGAMMAZ shiftgammaz

#undef  SHIFTGAMMA_TEMP
#define SHIFTGAMMA_TEMP shiftgamma_temp

/* Declare output variables */

      CCTK_REAL SHIFTGAMMAX
      CCTK_REAL SHIFTGAMMAY
      CCTK_REAL SHIFTGAMMAZ

      CCTK_REAL SHIFTGAMMA_TEMP

#endif
