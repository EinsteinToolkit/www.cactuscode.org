/*@@
  @header   DDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DDB_DECLARE
#define DDB_DECLARE

#include "macro/DXXDB_declare.h"
#include "macro/DXYDB_declare.h"
#include "macro/DXZDB_declare.h"
#include "macro/DYYDB_declare.h"
#include "macro/DYZDB_declare.h"
#include "macro/DZZDB_declare.h"

#undef  DDB_DXXDBX
#define DDB_DXXDBX DXXDB_DXXDBX
#undef  DDB_DXYDBX
#define DDB_DXYDBX DXYDB_DXYDBX
#undef  DDB_DXZDBX
#define DDB_DXZDBX DXZDB_DXZDBX
#undef  DDB_DYYDBX
#define DDB_DYYDBX DYYDB_DYYDBX
#undef  DDB_DYZDBX
#define DDB_DYZDBX DYZDB_DYZDBX
#undef  DDB_DZZDBX
#define DDB_DZZDBX DZZDB_DZZDBX

#undef  DDB_DXXDBY
#define DDB_DXXDBY DXXDB_DXXDBY
#undef  DDB_DXYDBY
#define DDB_DXYDBY DXYDB_DXYDBY
#undef  DDB_DXZDBY
#define DDB_DXZDBY DXZDB_DXZDBY
#undef  DDB_DYYDBY
#define DDB_DYYDBY DYYDB_DYYDBY
#undef  DDB_DYZDBY
#define DDB_DYZDBY DYZDB_DYZDBY
#undef  DDB_DZZDBY
#define DDB_DZZDBY DZZDB_DZZDBY

#undef  DDB_DXXDBZ
#define DDB_DXXDBZ DXXDB_DXXDBZ
#undef  DDB_DXYDBZ
#define DDB_DXYDBZ DXYDB_DXYDBZ
#undef  DDB_DXZDBZ
#define DDB_DXZDBZ DXZDB_DXZDBZ
#undef  DDB_DYYDBZ
#define DDB_DYYDBZ DYYDB_DYYDBZ
#undef  DDB_DYZDBZ
#define DDB_DYZDBZ DYZDB_DYZDBZ
#undef  DDB_DZZDBZ
#define DDB_DZZDBZ DZZDB_DZZDBZ

#endif
