/*@@
  @header   DXXDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DXXDB_DECLARE
#define DXXDB_DECLARE

/* Input variables */

#undef  DXXDB_BX   
#define DXXDB_BX   betax(i,j,k)
#undef  DXXDB_BY   
#define DXXDB_BY   betay(i,j,k)
#undef  DXXDB_BZ  
#define DXXDB_BZ   betaz(i,j,k)

#undef  DXXDB_BX_IP   
#define DXXDB_BX_IP   betax(i+1,j,k)
#undef  DXXDB_BY_IP   
#define DXXDB_BY_IP   betay(i+1,j,k)
#undef  DXXDB_BZ_IP  
#define DXXDB_BZ_IP   betaz(i+1,j,k)

#undef  DXXDB_BX_IM   
#define DXXDB_BX_IM   betax(i-1,j,k)
#undef  DXXDB_BY_IM   
#define DXXDB_BY_IM   betay(i-1,j,k)
#undef  DXXDB_BZ_IM  
#define DXXDB_BZ_IM   betaz(i-1,j,k)

/* Internal variables */

#undef  DXXDB_TEMP
#define DXXDB_TEMP  dxxdb_temp

/* Output variables */ 

#undef  DXXDB_DXXDBX
#define DXXDB_DXXDBX  dxxdb_dxxdbx
#undef  DXXDB_DXXDBY
#define DXXDB_DXXDBY  dxxdb_dxxdby
#undef  DXXDB_DXXDBZ
#define DXXDB_DXXDBZ  dxxdb_dxxdbz

/* Declare variables */

      CCTK_REAL DXXDB_TEMP
      CCTK_REAL DXXDB_DXXDBX
      CCTK_REAL DXXDB_DXXDBY
      CCTK_REAL DXXDB_DXXDBZ

#endif
