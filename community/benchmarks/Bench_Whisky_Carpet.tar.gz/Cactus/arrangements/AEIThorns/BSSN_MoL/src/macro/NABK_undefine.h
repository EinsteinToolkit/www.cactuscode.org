/*@@
  @header   NABK_undefine.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef NABK_GUTS
#undef NABK_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/CDCDK_undefine.h"


