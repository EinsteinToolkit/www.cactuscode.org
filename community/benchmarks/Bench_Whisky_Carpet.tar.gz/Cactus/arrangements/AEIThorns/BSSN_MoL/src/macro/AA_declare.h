/*@@
  @header   AA_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc

  Declarations for macro to calculate term ~A_{ik}~A^{k}_{l}

  @enddesc
@@*/

#ifndef INSOURCES
/* This macro is being called from outside of Sources.F */
#ifdef OPT
  OPT is defined while not in Sources.F
#endif
#undef OPT
#endif

#ifndef AA_DECLARE
#define AA_DECLARE

#include "BSUPPERMET_declare.h"

/* Input variables */
#ifdef OPT
#undef  AA_AXX
#define AA_AXX lA(XX,i,j,kc)
#undef  AA_AXY
#define AA_AXY lA(XY,i,j,kc)
#undef  AA_AXZ
#define AA_AXZ lA(XZ,i,j,kc)
#undef  AA_AYY
#define AA_AYY lA(YY,i,j,kc)
#undef  AA_AYZ
#define AA_AYZ lA(YZ,i,j,kc)
#undef  AA_AZZ
#define AA_AZZ lA(ZZ,i,j,kc)

#else

#undef  AA_AXX
#define AA_AXX ADM_BS_Axx(i,j,k)
#undef  AA_AXY
#define AA_AXY ADM_BS_Axy(i,j,k)
#undef  AA_AXZ
#define AA_AXZ ADM_BS_Axz(i,j,k)
#undef  AA_AYY
#define AA_AYY ADM_BS_Ayy(i,j,k)
#undef  AA_AYZ
#define AA_AYZ ADM_BS_Ayz(i,j,k)
#undef  AA_AZZ
#define AA_AZZ ADM_BS_Azz(i,j,k)

#endif

/* Output variables */
#undef  AA_AAXX
#define AA_AAXX AA11
#undef  AA_AAXY
#define AA_AAXY AA12
#undef  AA_AAXZ
#define AA_AAXZ AA13
#undef  AA_AAYY
#define AA_AAYY AA22
#undef  AA_AAYZ
#define AA_AAYZ AA23
#undef  AA_AAZZ
#define AA_AAZZ AA33

/* Declare output variables */
      CCTK_REAL AA_AAXX
      CCTK_REAL AA_AAXY
      CCTK_REAL AA_AAXZ
      CCTK_REAL AA_AAYY
      CCTK_REAL AA_AAYZ
      CCTK_REAL AA_AAZZ

#endif

