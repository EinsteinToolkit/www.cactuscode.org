/*@@
  @header   PHISOURCES_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef PHISOURCES_GUTS
#undef PHISOURCES_DECLARE
