/*@@
  @header   DIVA_declare.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DIVA_DECLARE
#define DIVA_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/BSCHR2_declare.h"
#include "macro/BSGAMMA_declare.h"

/* Output variables */

      CCTK_REAL DIVA_DIVAX
      CCTK_REAL DIVA_DIVAY
      CCTK_REAL DIVA_DIVAZ

#endif

