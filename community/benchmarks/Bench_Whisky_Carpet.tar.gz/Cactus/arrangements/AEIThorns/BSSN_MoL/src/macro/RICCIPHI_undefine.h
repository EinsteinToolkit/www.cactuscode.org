/*@@
  @header   RICCIPHI_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for the components of the "Ricci" tensor for the BS 
  variable phi. Eq. 20 of the BS paper.
  @enddesc
@@*/


#undef RICCIPHI_GUTS
#undef RICCIPHI_DECLARE

#include "macro/CDCDPHI_undefine.h"
#include "macro/DPHI_undefine.h"
#include "macro/NABPHI_undefine.h"
#include "macro/BSUPPERMET_undefine.h"

