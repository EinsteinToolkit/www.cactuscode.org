/*@@
  @header   SHIFTGAMMA_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
  @@*/

#undef SHIFTGAMMA_GUTS
#undef SHIFTGAMMA_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_undefine.h"
#include "macro/DDB_undefine.h"
#include "macro/BSUPPERMET_undefine.h"
#include "macro/BSGAMMA_undefine.h"
