/*@@
  @header   LIEA_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef LIEA_GUTS
#undef LIEA_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_undefine.h"

