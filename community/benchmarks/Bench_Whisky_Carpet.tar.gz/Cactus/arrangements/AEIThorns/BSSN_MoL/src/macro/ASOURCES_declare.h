/*@@
  @header   ASOURCES_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for source term of the BS A evolution equation 
  Eq. 17 of the BS paper.
  @enddesc
@@*/

#ifndef ASOURCES_DECLARE
#define ASOURCES_DECLARE

#include "macro/BSSTF_declare.h"
#include "macro/CDCDALPHA_declare.h"
#include "macro/NABALPHA_declare.h"
#include "macro/RICCITF_declare.h"
#include "macro/AA_declare.h"
#include "macro/BSUPPERMET_declare.h"

#undef  ASOURCES_ALP
#define ASOURCES_ALP asources_alp
#undef  ASOURCES_K
#define ASOURCES_K   asources_k   

#undef  ASOURCES_EXPTERM
#define ASOURCES_EXPTERM asources_expterm

#undef  ASOURCES_MATTERXX
#define ASOURCES_MATTERXX asources_matterxx
#undef  ASOURCES_MATTERXY
#define ASOURCES_MATTERXY asources_matterxy
#undef  ASOURCES_MATTERXZ
#define ASOURCES_MATTERXZ asources_matterxz
#undef  ASOURCES_MATTERYY
#define ASOURCES_MATTERYY asources_matteryy
#undef  ASOURCES_MATTERYZ
#define ASOURCES_MATTERYZ asources_matteryz
#undef  ASOURCES_MATTERZZ
#define ASOURCES_MATTERZZ asources_matterzz

#undef  ASOURCES_METRICXX
#define ASOURCES_METRICXX asources_metricxx
#undef  ASOURCES_METRICXY
#define ASOURCES_METRICXY asources_metricxy
#undef  ASOURCES_METRICXZ
#define ASOURCES_METRICXZ asources_metricxz
#undef  ASOURCES_METRICYY
#define ASOURCES_METRICYY asources_metricyy
#undef  ASOURCES_METRICYZ
#define ASOURCES_METRICYZ asources_metricyz
#undef  ASOURCES_METRICZZ
#define ASOURCES_METRICZZ asources_metriczz

#undef  ASOURCES_TERM1
#define ASOURCES_TERM1 asources_term1
#undef  ASOURCES_TERM2
#define ASOURCES_TERM2 asources_term2
#undef  ASOURCES_TERM3
#define ASOURCES_TERM3 asources_term3
#undef  ASOURCES_TERM4
#define ASOURCES_TERM4 asources_term4

#undef  ASOURCES_PSIFAC
#define ASOURCES_PSIFAC asources_psifac

#undef  ASOURCES_PHIFAC
#define ASOURCES_PHIFAC asources_phifac

#undef  ASOURCES_TEMP
#define ASOURCES_TEMP asources_temp

      CCTK_REAL ASOURCES_ALP
      CCTK_REAL ASOURCES_K
      CCTK_REAL ASOURCES_EXPTERM
      CCTK_REAL ASOURCES_PSIFAC
      CCTK_REAL ASOURCES_PHIFAC
      CCTK_REAL ASOURCES_TEMP

      CCTK_REAL ASOURCES_MATTERXX
      CCTK_REAL ASOURCES_MATTERXY
      CCTK_REAL ASOURCES_MATTERXZ
      CCTK_REAL ASOURCES_MATTERYY
      CCTK_REAL ASOURCES_MATTERYZ
      CCTK_REAL ASOURCES_MATTERZZ

      CCTK_REAL ASOURCES_METRICXX
      CCTK_REAL ASOURCES_METRICXY
      CCTK_REAL ASOURCES_METRICXZ
      CCTK_REAL ASOURCES_METRICYY
      CCTK_REAL ASOURCES_METRICYZ
      CCTK_REAL ASOURCES_METRICZZ

      CCTK_REAL ASOURCES_TERM1
      CCTK_REAL ASOURCES_TERM2
      CCTK_REAL ASOURCES_TERM3
      CCTK_REAL ASOURCES_TERM4

#endif
