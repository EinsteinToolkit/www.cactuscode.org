/*@@
  @header   BSDA_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate all the first derivatives of the 
     BS Aij with respect to x, y, z
  @enddesc
@@*/

#ifndef BSDA_GUTS
#define BSDA_GUTS

#include "macro/BSDXDA_guts.h"
#include "macro/BSDYDA_guts.h"
#include "macro/BSDZDA_guts.h"

#endif
