/*@@
  @header   BSDDG_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Declarations for macro to calculate all the second 
  derivatives of the BS metric with respect to x, y, z.
  @enddesc
@@*/

#ifndef BSDDG_DECLARE
#define BSDDG_DECLARE

#include "BSDXDG_declare.h"
#include "BSDYDG_declare.h"
#include "BSDZDG_declare.h"

/* Output variables */
#undef  BSDDG_DXXDGXX
#define BSDDG_DXXDGXX bsddg_dxxdgxx
#undef  BSDDG_DXXDGXY
#define BSDDG_DXXDGXY bsddg_dxxdgxy
#undef  BSDDG_DXXDGXZ
#define BSDDG_DXXDGXZ bsddg_dxxdgxz
#undef  BSDDG_DXXDGYY
#define BSDDG_DXXDGYY bsddg_dxxdgyy
#undef  BSDDG_DXXDGYZ
#define BSDDG_DXXDGYZ bsddg_dxxdgyz
#undef  BSDDG_DXXDGZZ
#define BSDDG_DXXDGZZ bsddg_dxxdgzz

#undef  BSDDG_DXYDGXX
#define BSDDG_DXYDGXX bsddg_dxydgxx
#undef  BSDDG_DXYDGXY
#define BSDDG_DXYDGXY bsddg_dxydgxy
#undef  BSDDG_DXYDGXZ
#define BSDDG_DXYDGXZ bsddg_dxydgxz
#undef  BSDDG_DXYDGYY
#define BSDDG_DXYDGYY bsddg_dxydgyy
#undef  BSDDG_DXYDGYZ
#define BSDDG_DXYDGYZ bsddg_dxydgyz
#undef  BSDDG_DXYDGZZ
#define BSDDG_DXYDGZZ bsddg_dxydgzz

#undef  BSDDG_DXZDGXX
#define BSDDG_DXZDGXX bsddg_dxzdgxx
#undef  BSDDG_DXZDGXY
#define BSDDG_DXZDGXY bsddg_dxzdgxy
#undef  BSDDG_DXZDGXZ
#define BSDDG_DXZDGXZ bsddg_dxzdgxz
#undef  BSDDG_DXZDGYY
#define BSDDG_DXZDGYY bsddg_dxzdgyy
#undef  BSDDG_DXZDGYZ
#define BSDDG_DXZDGYZ bsddg_dxzdgyz
#undef  BSDDG_DXZDGZZ
#define BSDDG_DXZDGZZ bsddg_dxzdgzz

#undef  BSDDG_DYYDGXX
#define BSDDG_DYYDGXX bsddg_dyydgxx
#undef  BSDDG_DYYDGXY
#define BSDDG_DYYDGXY bsddg_dyydgxy
#undef  BSDDG_DYYDGXZ
#define BSDDG_DYYDGXZ bsddg_dyydgxz
#undef  BSDDG_DYYDGYY
#define BSDDG_DYYDGYY bsddg_dyydgyy
#undef  BSDDG_DYYDGYZ
#define BSDDG_DYYDGYZ bsddg_dyydgyz
#undef  BSDDG_DYYDGZZ
#define BSDDG_DYYDGZZ bsddg_dyydgzz

#undef  BSDDG_DYZDGXX
#define BSDDG_DYZDGXX bsddg_dyzdgxx
#undef  BSDDG_DYZDGXY
#define BSDDG_DYZDGXY bsddg_dyzdgxy
#undef  BSDDG_DYZDGXZ
#define BSDDG_DYZDGXZ bsddg_dyzdgxz
#undef  BSDDG_DYZDGYY
#define BSDDG_DYZDGYY bsddg_dyzdgyy
#undef  BSDDG_DYZDGYZ
#define BSDDG_DYZDGYZ bsddg_dyzdgyz
#undef  BSDDG_DYZDGZZ
#define BSDDG_DYZDGZZ bsddg_dyzdgzz

#undef  BSDDG_DZZDGXX
#define BSDDG_DZZDGXX bsddg_dzzdgxx
#undef  BSDDG_DZZDGXY
#define BSDDG_DZZDGXY bsddg_dzzdgxy
#undef  BSDDG_DZZDGXZ
#define BSDDG_DZZDGXZ bsddg_dzzdgxz
#undef  BSDDG_DZZDGYY
#define BSDDG_DZZDGYY bsddg_dzzdgyy
#undef  BSDDG_DZZDGYZ
#define BSDDG_DZZDGYZ bsddg_dzzdgyz
#undef  BSDDG_DZZDGZZ
#define BSDDG_DZZDGZZ bsddg_dzzdgzz

/* Internal variables */
#undef  BSDDG_OODX2
#define BSDDG_OODX2 bsddg_oodx2
#undef  BSDDG_OODY2
#define BSDDG_OODY2 bsddg_oody2
#undef  BSDDG_OODZ2
#define BSDDG_OODZ2 bsddg_oodz2
#undef  BSDDG_OO4DXDY
#define BSDDG_OO4DXDY bsddg_oo4dxdy
#undef  BSDDG_OO4DXDZ
#define BSDDG_OO4DXDZ bsddg_oo4dxdz
#undef  BSDDG_OO4DYDZ
#define BSDDG_OO4DYDZ bsddg_oo4dydz

/* Input variables */
#ifdef OPT

#undef  BSDDG_GXX 
#define BSDDG_GXX lg(XX,i,j,kc)
#undef  BSDDG_GXY 
#define BSDDG_GXY lg(XY,i,j,kc)
#undef  BSDDG_GXZ 
#define BSDDG_GXZ lg(XZ,i,j,kc)
#undef  BSDDG_GYY
#define BSDDG_GYY lg(YY,i,j,kc)
#undef  BSDDG_GYZ
#define BSDDG_GYZ lg(YZ,i,j,kc)
#undef  BSDDG_GZZ 
#define BSDDG_GZZ lg(ZZ,i,j,kc)

#undef  BSDDG_GXX_IPJP 
#define BSDDG_GXX_IPJP lg(XX,i+1,j+1,kc)
#undef  BSDDG_GXX_IPJM 
#define BSDDG_GXX_IPJM lg(XX,i+1,j-1,kc)
#undef  BSDDG_GXX_IMJP 
#define BSDDG_GXX_IMJP lg(XX,i-1,j+1,kc)
#undef  BSDDG_GXX_IMJM 
#define BSDDG_GXX_IMJM lg(XX,i-1,j-1,kc)

#undef  BSDDG_GXY_IPJP 
#define BSDDG_GXY_IPJP lg(XY,i+1,j+1,kc)
#undef  BSDDG_GXY_IPJM 
#define BSDDG_GXY_IPJM lg(XY,i+1,j-1,kc)
#undef  BSDDG_GXY_IMJP 
#define BSDDG_GXY_IMJP lg(XY,i-1,j+1,kc)
#undef  BSDDG_GXY_IMJM 
#define BSDDG_GXY_IMJM lg(XY,i-1,j-1,kc)

#undef  BSDDG_GXZ_IPJP 
#define BSDDG_GXZ_IPJP lg(XZ,i+1,j+1,kc)
#undef  BSDDG_GXZ_IPJM 
#define BSDDG_GXZ_IPJM lg(XZ,i+1,j-1,kc)
#undef  BSDDG_GXZ_IMJP 
#define BSDDG_GXZ_IMJP lg(XZ,i-1,j+1,kc)
#undef  BSDDG_GXZ_IMJM 
#define BSDDG_GXZ_IMJM lg(XZ,i-1,j-1,kc)

#undef  BSDDG_GYY_IPJP 
#define BSDDG_GYY_IPJP lg(YY,i+1,j+1,kc)
#undef  BSDDG_GYY_IPJM 
#define BSDDG_GYY_IPJM lg(YY,i+1,j-1,kc)
#undef  BSDDG_GYY_IMJP 
#define BSDDG_GYY_IMJP lg(YY,i-1,j+1,kc)
#undef  BSDDG_GYY_IMJM 
#define BSDDG_GYY_IMJM lg(YY,i-1,j-1,kc)

#undef  BSDDG_GYZ_IPJP 
#define BSDDG_GYZ_IPJP lg(YZ,i+1,j+1,kc)
#undef  BSDDG_GYZ_IPJM 
#define BSDDG_GYZ_IPJM lg(YZ,i+1,j-1,kc)
#undef  BSDDG_GYZ_IMJP 
#define BSDDG_GYZ_IMJP lg(YZ,i-1,j+1,kc)
#undef  BSDDG_GYZ_IMJM 
#define BSDDG_GYZ_IMJM lg(YZ,i-1,j-1,kc)

#undef  BSDDG_GZZ_IPJP 
#define BSDDG_GZZ_IPJP lg(ZZ,i+1,j+1,kc)
#undef  BSDDG_GZZ_IPJM 
#define BSDDG_GZZ_IPJM lg(ZZ,i+1,j-1,kc)
#undef  BSDDG_GZZ_IMJP 
#define BSDDG_GZZ_IMJP lg(ZZ,i-1,j+1,kc)
#undef  BSDDG_GZZ_IMJM 
#define BSDDG_GZZ_IMJM lg(ZZ,i-1,j-1,kc)

#undef  BSDDG_GXX_JPKP 
#define BSDDG_GXX_JPKP lg(XX,i,j+1,kp)
#undef  BSDDG_GXX_JPKM 
#define BSDDG_GXX_JPKM lg(XX,i,j+1,km)
#undef  BSDDG_GXX_JMKP 
#define BSDDG_GXX_JMKP lg(XX,i,j-1,kp)
#undef  BSDDG_GXX_JMKM 
#define BSDDG_GXX_JMKM lg(XX,i,j-1,km)

#undef  BSDDG_GXX_IPKP 
#define BSDDG_GXX_IPKP lg(XX,i+1,j,kp)
#undef  BSDDG_GXX_IPKM 
#define BSDDG_GXX_IPKM lg(XX,i+1,j,km)
#undef  BSDDG_GXX_IMKP 
#define BSDDG_GXX_IMKP lg(XX,i-1,j,kp)
#undef  BSDDG_GXX_IMKM 
#define BSDDG_GXX_IMKM lg(XX,i-1,j,km)

#undef  BSDDG_GXY_IPKP 
#define BSDDG_GXY_IPKP lg(XY,i+1,j,kp)
#undef  BSDDG_GXY_IPKM 
#define BSDDG_GXY_IPKM lg(XY,i+1,j,km)
#undef  BSDDG_GXY_IMKP 
#define BSDDG_GXY_IMKP lg(XY,i-1,j,kp)
#undef  BSDDG_GXY_IMKM 
#define BSDDG_GXY_IMKM lg(XY,i-1,j,km)

#undef  BSDDG_GXZ_IPKP 
#define BSDDG_GXZ_IPKP lg(XZ,i+1,j,kp)
#undef  BSDDG_GXZ_IPKM 
#define BSDDG_GXZ_IPKM lg(XZ,i+1,j,km)
#undef  BSDDG_GXZ_IMKP 
#define BSDDG_GXZ_IMKP lg(XZ,i-1,j,kp)
#undef  BSDDG_GXZ_IMKM 
#define BSDDG_GXZ_IMKM lg(XZ,i-1,j,km)

#undef  BSDDG_GYY_IPKP 
#define BSDDG_GYY_IPKP lg(YY,i+1,j,kp)
#undef  BSDDG_GYY_IPKM 
#define BSDDG_GYY_IPKM lg(YY,i+1,j,km)
#undef  BSDDG_GYY_IMKP 
#define BSDDG_GYY_IMKP lg(YY,i-1,j,kp)
#undef  BSDDG_GYY_IMKM 
#define BSDDG_GYY_IMKM lg(YY,i-1,j,km)

#undef  BSDDG_GYZ_IPKP 
#define BSDDG_GYZ_IPKP lg(YZ,i+1,j,kp)
#undef  BSDDG_GYZ_IPKM 
#define BSDDG_GYZ_IPKM lg(YZ,i+1,j,km)
#undef  BSDDG_GYZ_IMKP 
#define BSDDG_GYZ_IMKP lg(YZ,i-1,j,kp)
#undef  BSDDG_GYZ_IMKM 
#define BSDDG_GYZ_IMKM lg(YZ,i-1,j,km)

#undef  BSDDG_GZZ_IPKP 
#define BSDDG_GZZ_IPKP lg(ZZ,i+1,j,kp)
#undef  BSDDG_GZZ_IPKM 
#define BSDDG_GZZ_IPKM lg(ZZ,i+1,j,km)
#undef  BSDDG_GZZ_IMKP 
#define BSDDG_GZZ_IMKP lg(ZZ,i-1,j,kp)
#undef  BSDDG_GZZ_IMKM 
#define BSDDG_GZZ_IMKM lg(ZZ,i-1,j,km)

#undef  BSDDG_GXY_JPKP 
#define BSDDG_GXY_JPKP lg(XY,i,j+1,kp)
#undef  BSDDG_GXY_JPKM 
#define BSDDG_GXY_JPKM lg(XY,i,j+1,km)
#undef  BSDDG_GXY_JMKP 
#define BSDDG_GXY_JMKP lg(XY,i,j-1,kp)
#undef  BSDDG_GXY_JMKM 
#define BSDDG_GXY_JMKM lg(XY,i,j-1,km)

#undef  BSDDG_GXZ_JPKP 
#define BSDDG_GXZ_JPKP lg(XZ,i,j+1,kp)
#undef  BSDDG_GXZ_JPKM 
#define BSDDG_GXZ_JPKM lg(XZ,i,j+1,km)
#undef  BSDDG_GXZ_JMKP 
#define BSDDG_GXZ_JMKP lg(XZ,i,j-1,kp)
#undef  BSDDG_GXZ_JMKM 
#define BSDDG_GXZ_JMKM lg(XZ,i,j-1,km)

#undef  BSDDG_GYY_JPKP 
#define BSDDG_GYY_JPKP lg(YY,i,j+1,kp)
#undef  BSDDG_GYY_JPKM 
#define BSDDG_GYY_JPKM lg(YY,i,j+1,km)
#undef  BSDDG_GYY_JMKP 
#define BSDDG_GYY_JMKP lg(YY,i,j-1,kp)
#undef  BSDDG_GYY_JMKM 
#define BSDDG_GYY_JMKM lg(YY,i,j-1,km)

#undef  BSDDG_GYZ_JPKP 
#define BSDDG_GYZ_JPKP lg(YZ,i,j+1,kp)
#undef  BSDDG_GYZ_JPKM 
#define BSDDG_GYZ_JPKM lg(YZ,i,j+1,km)
#undef  BSDDG_GYZ_JMKP 
#define BSDDG_GYZ_JMKP lg(YZ,i,j-1,kp)
#undef  BSDDG_GYZ_JMKM 
#define BSDDG_GYZ_JMKM lg(YZ,i,j-1,km)

#undef  BSDDG_GZZ_JPKP 
#define BSDDG_GZZ_JPKP lg(ZZ,i,j+1,kp)
#undef  BSDDG_GZZ_JPKM 
#define BSDDG_GZZ_JPKM lg(ZZ,i,j+1,km)
#undef  BSDDG_GZZ_JMKP 
#define BSDDG_GZZ_JMKP lg(ZZ,i,j-1,kp)
#undef  BSDDG_GZZ_JMKM 
#define BSDDG_GZZ_JMKM lg(ZZ,i,j-1,km)

#else

#undef  BSDDG_GXX 
#define BSDDG_GXX ADM_BS_gxx(i,j,k)
#undef  BSDDG_GXY 
#define BSDDG_GXY ADM_BS_gxy(i,j,k)
#undef  BSDDG_GXZ 
#define BSDDG_GXZ ADM_BS_gxz(i,j,k)
#undef  BSDDG_GYY
#define BSDDG_GYY ADM_BS_gyy(i,j,k)
#undef  BSDDG_GYZ
#define BSDDG_GYZ ADM_BS_gyz(i,j,k)
#undef  BSDDG_GZZ 
#define BSDDG_GZZ ADM_BS_gzz(i,j,k)

#undef  BSDDG_GXX_IPJP 
#define BSDDG_GXX_IPJP ADM_BS_gxx(i+1,j+1,k)
#undef  BSDDG_GXX_IPJM 
#define BSDDG_GXX_IPJM ADM_BS_gxx(i+1,j-1,k)
#undef  BSDDG_GXX_IMJP 
#define BSDDG_GXX_IMJP ADM_BS_gxx(i-1,j+1,k)
#undef  BSDDG_GXX_IMJM 
#define BSDDG_GXX_IMJM ADM_BS_gxx(i-1,j-1,k)

#undef  BSDDG_GXY_IPJP 
#define BSDDG_GXY_IPJP ADM_BS_gxy(i+1,j+1,k)
#undef  BSDDG_GXY_IPJM 
#define BSDDG_GXY_IPJM ADM_BS_gxy(i+1,j-1,k)
#undef  BSDDG_GXY_IMJP 
#define BSDDG_GXY_IMJP ADM_BS_gxy(i-1,j+1,k)
#undef  BSDDG_GXY_IMJM 
#define BSDDG_GXY_IMJM ADM_BS_gxy(i-1,j-1,k)

#undef  BSDDG_GXZ_IPJP 
#define BSDDG_GXZ_IPJP ADM_BS_gxz(i+1,j+1,k)
#undef  BSDDG_GXZ_IPJM 
#define BSDDG_GXZ_IPJM ADM_BS_gxz(i+1,j-1,k)
#undef  BSDDG_GXZ_IMJP 
#define BSDDG_GXZ_IMJP ADM_BS_gxz(i-1,j+1,k)
#undef  BSDDG_GXZ_IMJM 
#define BSDDG_GXZ_IMJM ADM_BS_gxz(i-1,j-1,k)

#undef  BSDDG_GYY_IPJP 
#define BSDDG_GYY_IPJP ADM_BS_gyy(i+1,j+1,k)
#undef  BSDDG_GYY_IPJM 
#define BSDDG_GYY_IPJM ADM_BS_gyy(i+1,j-1,k)
#undef  BSDDG_GYY_IMJP 
#define BSDDG_GYY_IMJP ADM_BS_gyy(i-1,j+1,k)
#undef  BSDDG_GYY_IMJM 
#define BSDDG_GYY_IMJM ADM_BS_gyy(i-1,j-1,k)

#undef  BSDDG_GYZ_IPJP 
#define BSDDG_GYZ_IPJP ADM_BS_gyz(i+1,j+1,k)
#undef  BSDDG_GYZ_IPJM 
#define BSDDG_GYZ_IPJM ADM_BS_gyz(i+1,j-1,k)
#undef  BSDDG_GYZ_IMJP 
#define BSDDG_GYZ_IMJP ADM_BS_gyz(i-1,j+1,k)
#undef  BSDDG_GYZ_IMJM 
#define BSDDG_GYZ_IMJM ADM_BS_gyz(i-1,j-1,k)

#undef  BSDDG_GZZ_IPJP 
#define BSDDG_GZZ_IPJP ADM_BS_gzz(i+1,j+1,k)
#undef  BSDDG_GZZ_IPJM 
#define BSDDG_GZZ_IPJM ADM_BS_gzz(i+1,j-1,k)
#undef  BSDDG_GZZ_IMJP 
#define BSDDG_GZZ_IMJP ADM_BS_gzz(i-1,j+1,k)
#undef  BSDDG_GZZ_IMJM 
#define BSDDG_GZZ_IMJM ADM_BS_gzz(i-1,j-1,k)

#undef  BSDDG_GXX_JPKP 
#define BSDDG_GXX_JPKP ADM_BS_gxx(i,j+1,k+1)
#undef  BSDDG_GXX_JPKM 
#define BSDDG_GXX_JPKM ADM_BS_gxx(i,j+1,k-1)
#undef  BSDDG_GXX_JMKP 
#define BSDDG_GXX_JMKP ADM_BS_gxx(i,j-1,k+1)
#undef  BSDDG_GXX_JMKM 
#define BSDDG_GXX_JMKM ADM_BS_gxx(i,j-1,k-1)

#undef  BSDDG_GXX_IPKP 
#define BSDDG_GXX_IPKP ADM_BS_gxx(i+1,j,k+1)
#undef  BSDDG_GXX_IPKM 
#define BSDDG_GXX_IPKM ADM_BS_gxx(i+1,j,k-1)
#undef  BSDDG_GXX_IMKP 
#define BSDDG_GXX_IMKP ADM_BS_gxx(i-1,j,k+1)
#undef  BSDDG_GXX_IMKM 
#define BSDDG_GXX_IMKM ADM_BS_gxx(i-1,j,k-1)

#undef  BSDDG_GXY_IPKP 
#define BSDDG_GXY_IPKP ADM_BS_gxy(i+1,j,k+1)
#undef  BSDDG_GXY_IPKM 
#define BSDDG_GXY_IPKM ADM_BS_gxy(i+1,j,k-1)
#undef  BSDDG_GXY_IMKP 
#define BSDDG_GXY_IMKP ADM_BS_gxy(i-1,j,k+1)
#undef  BSDDG_GXY_IMKM 
#define BSDDG_GXY_IMKM ADM_BS_gxy(i-1,j,k-1)

#undef  BSDDG_GXZ_IPKP 
#define BSDDG_GXZ_IPKP ADM_BS_gxz(i+1,j,k+1)
#undef  BSDDG_GXZ_IPKM 
#define BSDDG_GXZ_IPKM ADM_BS_gxz(i+1,j,k-1)
#undef  BSDDG_GXZ_IMKP 
#define BSDDG_GXZ_IMKP ADM_BS_gxz(i-1,j,k+1)
#undef  BSDDG_GXZ_IMKM 
#define BSDDG_GXZ_IMKM ADM_BS_gxz(i-1,j,k-1)

#undef  BSDDG_GYY_IPKP 
#define BSDDG_GYY_IPKP ADM_BS_gyy(i+1,j,k+1)
#undef  BSDDG_GYY_IPKM 
#define BSDDG_GYY_IPKM ADM_BS_gyy(i+1,j,k-1)
#undef  BSDDG_GYY_IMKP 
#define BSDDG_GYY_IMKP ADM_BS_gyy(i-1,j,k+1)
#undef  BSDDG_GYY_IMKM 
#define BSDDG_GYY_IMKM ADM_BS_gyy(i-1,j,k-1)

#undef  BSDDG_GYZ_IPKP 
#define BSDDG_GYZ_IPKP ADM_BS_gyz(i+1,j,k+1)
#undef  BSDDG_GYZ_IPKM 
#define BSDDG_GYZ_IPKM ADM_BS_gyz(i+1,j,k-1)
#undef  BSDDG_GYZ_IMKP 
#define BSDDG_GYZ_IMKP ADM_BS_gyz(i-1,j,k+1)
#undef  BSDDG_GYZ_IMKM 
#define BSDDG_GYZ_IMKM ADM_BS_gyz(i-1,j,k-1)

#undef  BSDDG_GZZ_IPKP 
#define BSDDG_GZZ_IPKP ADM_BS_gzz(i+1,j,k+1)
#undef  BSDDG_GZZ_IPKM 
#define BSDDG_GZZ_IPKM ADM_BS_gzz(i+1,j,k-1)
#undef  BSDDG_GZZ_IMKP 
#define BSDDG_GZZ_IMKP ADM_BS_gzz(i-1,j,k+1)
#undef  BSDDG_GZZ_IMKM 
#define BSDDG_GZZ_IMKM ADM_BS_gzz(i-1,j,k-1)

#undef  BSDDG_GXY_JPKP 
#define BSDDG_GXY_JPKP ADM_BS_gxy(i,j+1,k+1)
#undef  BSDDG_GXY_JPKM 
#define BSDDG_GXY_JPKM ADM_BS_gxy(i,j+1,k-1)
#undef  BSDDG_GXY_JMKP 
#define BSDDG_GXY_JMKP ADM_BS_gxy(i,j-1,k+1)
#undef  BSDDG_GXY_JMKM 
#define BSDDG_GXY_JMKM ADM_BS_gxy(i,j-1,k-1)

#undef  BSDDG_GXZ_JPKP 
#define BSDDG_GXZ_JPKP ADM_BS_gxz(i,j+1,k+1)
#undef  BSDDG_GXZ_JPKM 
#define BSDDG_GXZ_JPKM ADM_BS_gxz(i,j+1,k-1)
#undef  BSDDG_GXZ_JMKP 
#define BSDDG_GXZ_JMKP ADM_BS_gxz(i,j-1,k+1)
#undef  BSDDG_GXZ_JMKM 
#define BSDDG_GXZ_JMKM ADM_BS_gxz(i,j-1,k-1)

#undef  BSDDG_GYY_JPKP 
#define BSDDG_GYY_JPKP ADM_BS_gyy(i,j+1,k+1)
#undef  BSDDG_GYY_JPKM 
#define BSDDG_GYY_JPKM ADM_BS_gyy(i,j+1,k-1)
#undef  BSDDG_GYY_JMKP 
#define BSDDG_GYY_JMKP ADM_BS_gyy(i,j-1,k+1)
#undef  BSDDG_GYY_JMKM 
#define BSDDG_GYY_JMKM ADM_BS_gyy(i,j-1,k-1)

#undef  BSDDG_GYZ_JPKP 
#define BSDDG_GYZ_JPKP ADM_BS_gyz(i,j+1,k+1)
#undef  BSDDG_GYZ_JPKM 
#define BSDDG_GYZ_JPKM ADM_BS_gyz(i,j+1,k-1)
#undef  BSDDG_GYZ_JMKP 
#define BSDDG_GYZ_JMKP ADM_BS_gyz(i,j-1,k+1)
#undef  BSDDG_GYZ_JMKM 
#define BSDDG_GYZ_JMKM ADM_BS_gyz(i,j-1,k-1)

#undef  BSDDG_GZZ_JPKP 
#define BSDDG_GZZ_JPKP ADM_BS_gzz(i,j+1,k+1)
#undef  BSDDG_GZZ_JPKM 
#define BSDDG_GZZ_JPKM ADM_BS_gzz(i,j+1,k-1)
#undef  BSDDG_GZZ_JMKP 
#define BSDDG_GZZ_JMKP ADM_BS_gzz(i,j-1,k+1)
#undef  BSDDG_GZZ_JMKM 
#define BSDDG_GZZ_JMKM ADM_BS_gzz(i,j-1,k-1)

#endif

/* Declare internal variables */
      CCTK_REAL BSDDG_OODX2
      CCTK_REAL BSDDG_OODY2
      CCTK_REAL BSDDG_OODZ2
      CCTK_REAL BSDDG_OO4DXDY
      CCTK_REAL BSDDG_OO4DXDZ
      CCTK_REAL BSDDG_OO4DYDZ


/* Declare output variables */
      CCTK_REAL BSDDG_DXXDGXX
      CCTK_REAL BSDDG_DXXDGXY
      CCTK_REAL BSDDG_DXXDGXZ
      CCTK_REAL BSDDG_DXXDGYY
      CCTK_REAL BSDDG_DXXDGYZ
      CCTK_REAL BSDDG_DXXDGZZ

      CCTK_REAL BSDDG_DXYDGXX
      CCTK_REAL BSDDG_DXYDGXY
      CCTK_REAL BSDDG_DXYDGXZ
      CCTK_REAL BSDDG_DXYDGYY
      CCTK_REAL BSDDG_DXYDGYZ
      CCTK_REAL BSDDG_DXYDGZZ

      CCTK_REAL BSDDG_DXZDGXX
      CCTK_REAL BSDDG_DXZDGXY
      CCTK_REAL BSDDG_DXZDGXZ
      CCTK_REAL BSDDG_DXZDGYY
      CCTK_REAL BSDDG_DXZDGYZ
      CCTK_REAL BSDDG_DXZDGZZ

      CCTK_REAL BSDDG_DYYDGXX
      CCTK_REAL BSDDG_DYYDGXY
      CCTK_REAL BSDDG_DYYDGXZ
      CCTK_REAL BSDDG_DYYDGYY
      CCTK_REAL BSDDG_DYYDGYZ
      CCTK_REAL BSDDG_DYYDGZZ

      CCTK_REAL BSDDG_DYZDGXX
      CCTK_REAL BSDDG_DYZDGXY
      CCTK_REAL BSDDG_DYZDGXZ
      CCTK_REAL BSDDG_DYZDGYY
      CCTK_REAL BSDDG_DYZDGYZ
      CCTK_REAL BSDDG_DYZDGZZ

      CCTK_REAL BSDDG_DZZDGXX
      CCTK_REAL BSDDG_DZZDGXY
      CCTK_REAL BSDDG_DZZDGXZ
      CCTK_REAL BSDDG_DZZDGYY
      CCTK_REAL BSDDG_DZZDGYZ
      CCTK_REAL BSDDG_DZZDGZZ

#endif
