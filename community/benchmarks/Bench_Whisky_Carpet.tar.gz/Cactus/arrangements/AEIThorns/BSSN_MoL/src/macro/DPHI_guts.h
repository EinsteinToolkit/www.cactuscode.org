/*@@
  @header   DPHI_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all first spatial derivative of BS conformal phi
  @enddesc
@@*/

#ifndef DPHI_GUTS
#define DPHI_GUTS

#ifdef FCODE 

#include "macro/BSSN_Derivative.h"

      IF (conformal_state == 0) THEN
         DPHI_FACX = 0.0d0
         DPHI_FACY = 0.0d0
         DPHI_FACZ = 0.0d0
      ELSE
         DPHI_FACX = DPHI_DXDPSI_O_PSI
         DPHI_FACY = DPHI_DYDPSI_O_PSI
         DPHI_FACZ = DPHI_DZDPSI_O_PSI
      ENDIF

      if (local_spatial_order.eq.2) then
        DPHI_DXDPHI = BSSN_DX_2(ADM_BS_phi,i,j,k) + DPHI_FACX
        DPHI_DYDPHI = BSSN_DY_2(ADM_BS_phi,i,j,k) + DPHI_FACY
        DPHI_DZDPHI = BSSN_DZ_2(ADM_BS_phi,i,j,k) + DPHI_FACZ
      else
        DPHI_DXDPHI = BSSN_DX_4(ADM_BS_phi,i,j,k) + DPHI_FACX
        DPHI_DYDPHI = BSSN_DY_4(ADM_BS_phi,i,j,k) + DPHI_FACY
        DPHI_DZDPHI = BSSN_DZ_4(ADM_BS_phi,i,j,k) + DPHI_FACZ
      end if
#endif

#ifdef CCODE

      DPHI_DXDPHI = DPHI_OO2DX*(DPHI_PHI_IP - DPHI_PHI_IM);
      DPHI_DYDPHI = DPHI_OO2DY*(DPHI_PHI_JP - DPHI_PHI_JM);
      DPHI_DZDPHI = DPHI_OO2DZ*(DPHI_PHI_KP - DPHI_PHI_KM);

#endif

#endif
