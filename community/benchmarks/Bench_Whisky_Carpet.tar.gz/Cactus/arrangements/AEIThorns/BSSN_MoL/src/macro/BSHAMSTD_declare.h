/*@@
  @header   BSHAMSTD_declare.h
  @date     23 May 2002
  @author   Denis Pollney
  @desc
  Macro to calculate the spacetime part of the 
  Hamiltonian Constraint. That is:

       R - K^i_j K^j_i + trK^2 

  @enddesc
@@*/

#ifndef BSHAMSTD_DECLARE
#define BSHAMSTD_DECLARE

#include "TRAA_declare.h"
#include "CactusEinstein/ADMMacros/src/macro/TRK_declare.h"
#include "BSRICSCAL_declare.h"

#define BSHAMSTD_HAM bshamstd_ham
#define BSHAMSTD_ABSHAM bshamstd_absham

       CCTK_REAL BSHAMSTD_HAM
       CCTK_REAL BSHAMSTD_ABSHAM

#endif
