/*@@
  @header   BSMOM_declare.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc

  Declarations for BS covariant momentum constraints.

  @enddesc
@@*/

#ifndef BSMOM_DECLARE
#define BSMOM_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/DPHI_declare.h"
#include "macro/DTRK_declare.h"
#include "macro/DIVA_declare.h"

#undef  BSMOM_MOMX
#define BSMOM_MOMX bsmom_momx
#undef  BSMOM_MOMY
#define BSMOM_MOMY bsmom_momy
#undef  BSMOM_MOMZ
#define BSMOM_MOMZ bsmom_momz

       CCTK_REAL BSMOM_MOMX
       CCTK_REAL BSMOM_MOMY
       CCTK_REAL BSMOM_MOMZ

#endif
