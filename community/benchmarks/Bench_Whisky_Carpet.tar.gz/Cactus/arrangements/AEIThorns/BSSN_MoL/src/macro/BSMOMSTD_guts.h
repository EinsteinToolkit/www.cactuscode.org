/*@@
  @header   BSMOMSTD_guts.h
  @date     July 2002
  @author   Denis Pollney
  @desc

  Macro to calculate the covariant momentum constraints according
  to YS2.26:


        ~ab / ~  ~        ~         \                      ~ ~ 
  M  =  g   | D  A   +  6 A   d phi |  -  2/3  d trK + 2 trA d phi
   i        \  a  bi       bi  a    /           i             i


  Note that except for the last term, this quantity is exactly
  that calculated by the BSMOM_guts.h macro. The last term includes
  a contribution due to the trA, which is zero when the constraints
  are satisfied identically.

  @enddesc
@@*/

#ifndef BSMOMSTD_GUTS
#define BSMOMSTD_GUTS

#include "DPHI_guts.h"
#include "BSMOM_guts.h"

      BSMOMSTD_MOMX = BSMOM_MOMX + 2.D0 * constraint_A(i,j,k) *
     .  DPHI_DXDPHI

      BSMOMSTD_MOMY = BSMOM_MOMY + 2.D0 * constraint_A(i,j,k) *
     .  DPHI_DYDPHI

      BSMOMSTD_MOMZ = BSMOM_MOMZ + 2.D0 * constraint_A(i,j,k) *
     .  DPHI_DZDPHI

#endif
  
