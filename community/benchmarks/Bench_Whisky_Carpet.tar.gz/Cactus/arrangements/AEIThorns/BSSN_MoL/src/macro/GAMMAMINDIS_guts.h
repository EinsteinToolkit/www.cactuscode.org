/*@@
  @header   GAMMAMINDIS_guts.h
  @date     February 2001
  @author   Miguel Alcubierre
  @desc
    Macro for source term of the BS Gamma evolution equation
    when using a minimal distortion shift vector.
  @enddesc
@@*/

#ifndef GAMMAMINDIS_GUTS
#define GAMMAMINDIS_GUTS

#include "macro/BSCHR2_guts.h"
#include "macro/DPHI_guts.h"
#include "macro/BSUPPERMET_guts.h"


/* Calculate time derivatives of upper conformal metric */
/* ---------------------------------------------------- */

c     The time derivative of the upper metric is found by
c     rasising the two indices of the time derivative of
c     the metric and changing the sign.

      GAMMAMINDIS_DTUPPERGXX = 
     &   -(BSUPPERMET_UXX**2*adm_bs_sgxx(i,j,k)
     &   + BSUPPERMET_UXY**2*adm_bs_sgyy(i,j,k)
     &   + BSUPPERMET_UXZ**2*adm_bs_sgzz(i,j,k)
     &   +(BSUPPERMET_UXX*BSUPPERMET_UXY*adm_bs_sgxy(i,j,k)
     &   + BSUPPERMET_UXX*BSUPPERMET_UXZ*adm_bs_sgxz(i,j,k)
     &   + BSUPPERMET_UXY*BSUPPERMET_UXZ*adm_bs_sgyz(i,j,k))*2.0d0)

      GAMMAMINDIS_DTUPPERGYY = 
     &   -(BSUPPERMET_UXY**2*adm_bs_sgxx(i,j,k)
     &   + BSUPPERMET_UYY**2*adm_bs_sgyy(i,j,k)
     &   + BSUPPERMET_UYZ**2*adm_bs_sgzz(i,j,k)
     &   +(BSUPPERMET_UXY*BSUPPERMET_UYY*adm_bs_sgxy(i,j,k)
     &   + BSUPPERMET_UYZ*BSUPPERMET_UXY*adm_bs_sgxz(i,j,k)
     &   + BSUPPERMET_UYZ*BSUPPERMET_UYY*adm_bs_sgyz(i,j,k))*2.0d0)

      GAMMAMINDIS_DTUPPERGZZ = 
     &   -(BSUPPERMET_UXZ**2*adm_bs_sgxx(i,j,k)
     &   + BSUPPERMET_UYZ**2*adm_bs_sgyy(i,j,k)
     &   + BSUPPERMET_UZZ**2*adm_bs_sgzz(i,j,k)
     &   +(BSUPPERMET_UZX*BSUPPERMET_UZY*adm_bs_sgxy(i,j,k)
     &   + BSUPPERMET_UZX*BSUPPERMET_UZZ*adm_bs_sgxz(i,j,k)
     &   + BSUPPERMET_UZY*BSUPPERMET_UZZ*adm_bs_sgyz(i,j,k))*2.0d0)

      GAMMAMINDIS_DTUPPERGXY = 
     &   -(BSUPPERMET_UXX*BSUPPERMET_UYX*adm_bs_sgxx(i,j,k)
     &   + BSUPPERMET_UXY*BSUPPERMET_UYY*adm_bs_sgyy(i,j,k)
     &   + BSUPPERMET_UXZ*BSUPPERMET_UYZ*adm_bs_sgzz(i,j,k)
     &   +(BSUPPERMET_UXX*BSUPPERMET_UYY
     &   + BSUPPERMET_UXY*BSUPPERMET_UYX)*adm_bs_sgxy(i,j,k)
     &   +(BSUPPERMET_UXZ*BSUPPERMET_UYX
     &   + BSUPPERMET_UXX*BSUPPERMET_UYZ)*adm_bs_sgxz(i,j,k)
     &   +(BSUPPERMET_UXZ*BSUPPERMET_UYY
     &   + BSUPPERMET_UXY*BSUPPERMET_UYZ)*adm_bs_sgyz(i,j,k))

      GAMMAMINDIS_DTUPPERGXZ = 
     &   -(BSUPPERMET_UXX*BSUPPERMET_UZX*adm_bs_sgxx(i,j,k)
     &   + BSUPPERMET_UXY*BSUPPERMET_UZY*adm_bs_sgyy(i,j,k)
     &   + BSUPPERMET_UXZ*BSUPPERMET_UZZ*adm_bs_sgzz(i,j,k)
     &   +(BSUPPERMET_UXX*BSUPPERMET_UZY
     &   + BSUPPERMET_UXY*BSUPPERMET_UZX)*adm_bs_sgxy(i,j,k)
     &   +(BSUPPERMET_UXX*BSUPPERMET_UZZ
     &   + BSUPPERMET_UXZ*BSUPPERMET_UZX)*adm_bs_sgxz(i,j,k)
     &   +(BSUPPERMET_UXY*BSUPPERMET_UZZ
     &   + BSUPPERMET_UXZ*BSUPPERMET_UZY)*adm_bs_sgyz(i,j,k))

      GAMMAMINDIS_DTUPPERGYZ = 
     &   -(BSUPPERMET_UYX*BSUPPERMET_UZX*adm_bs_sgxx(i,j,k)
     &   + BSUPPERMET_UYY*BSUPPERMET_UZY*adm_bs_sgyy(i,j,k)
     &   + BSUPPERMET_UYZ*BSUPPERMET_UZZ*adm_bs_sgzz(i,j,k)
     &   +(BSUPPERMET_UYX*BSUPPERMET_UZY
     &   + BSUPPERMET_UYY*BSUPPERMET_UZX)*adm_bs_sgxy(i,j,k)
     &   +(BSUPPERMET_UYX*BSUPPERMET_UZZ
     &   + BSUPPERMET_UYZ*BSUPPERMET_UZX)*adm_bs_sgxz(i,j,k)
     &   +(BSUPPERMET_UYY*BSUPPERMET_UZZ
     &   + BSUPPERMET_UYZ*BSUPPERMET_UZY)*adm_bs_sgyz(i,j,k))


/* Calculate source term */
/* --------------------- */


c     GAMMA_X.

      GAMMAMINDIS_TERM1 = BSCHR2_XXX*GAMMAMINDIS_DTUPPERGXX
     &                  + BSCHR2_XYY*GAMMAMINDIS_DTUPPERGYY
     &                  + BSCHR2_XZZ*GAMMAMINDIS_DTUPPERGZZ
     &                  +(BSCHR2_XXY*GAMMAMINDIS_DTUPPERGXY
     &                  + BSCHR2_XXZ*GAMMAMINDIS_DTUPPERGXZ
     &                  + BSCHR2_XYZ*GAMMAMINDIS_DTUPPERGYZ)*2.0D0

      GAMMAMINDIS_TERM2 = (DPHI_DXDPHI*GAMMAMINDIS_DTUPPERGXX
     &                   + DPHI_DYDPHI*GAMMAMINDIS_DTUPPERGXY
     &                   + DPHI_DZDPHI*GAMMAMINDIS_DTUPPERGXZ)*6.0D0

      GAMMAMINDIS_SOURCEX = GAMMAMINDIS_TERM1 + GAMMAMINDIS_TERM2

c     GAMMA_Y.

      GAMMAMINDIS_TERM1 = BSCHR2_YXX*GAMMAMINDIS_DTUPPERGXX
     &                  + BSCHR2_YYY*GAMMAMINDIS_DTUPPERGYY
     &                  + BSCHR2_YZZ*GAMMAMINDIS_DTUPPERGZZ
     &                  +(BSCHR2_YXY*GAMMAMINDIS_DTUPPERGXY
     &                  + BSCHR2_YXZ*GAMMAMINDIS_DTUPPERGXZ
     &                  + BSCHR2_YYZ*GAMMAMINDIS_DTUPPERGYZ)*2.0D0

      GAMMAMINDIS_TERM2 = (DPHI_DXDPHI*GAMMAMINDIS_DTUPPERGXY
     &                   + DPHI_DYDPHI*GAMMAMINDIS_DTUPPERGYY
     &                   + DPHI_DZDPHI*GAMMAMINDIS_DTUPPERGYZ)*6.0D0

      GAMMAMINDIS_SOURCEY = GAMMAMINDIS_TERM1 + GAMMAMINDIS_TERM2

c     GAMMA_Z.

      GAMMAMINDIS_TERM1 = BSCHR2_ZXX*GAMMAMINDIS_DTUPPERGXX
     &                  + BSCHR2_ZYY*GAMMAMINDIS_DTUPPERGYY
     &                  + BSCHR2_ZZZ*GAMMAMINDIS_DTUPPERGZZ
     &                  +(BSCHR2_ZXY*GAMMAMINDIS_DTUPPERGXY
     &                  + BSCHR2_ZXZ*GAMMAMINDIS_DTUPPERGXZ
     &                  + BSCHR2_ZYZ*GAMMAMINDIS_DTUPPERGYZ)*2.0D0

      GAMMAMINDIS_TERM2 = (DPHI_DXDPHI*GAMMAMINDIS_DTUPPERGXZ
     &                   + DPHI_DYDPHI*GAMMAMINDIS_DTUPPERGYZ
     &                   + DPHI_DZDPHI*GAMMAMINDIS_DTUPPERGZZ)*6.0D0

      GAMMAMINDIS_SOURCEZ = GAMMAMINDIS_TERM1 + GAMMAMINDIS_TERM2

#endif
