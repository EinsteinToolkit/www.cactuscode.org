/*@@
  @header   CDCDK_declare.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc

  @enddesc
@@*/

#ifndef CDCDK_DECLARE
#define CDCDK_DECLARE

#include "macro/DTRK_declare.h"
#include "macro/DDK_declare.h"
#include "macro/BSCHR2_declare.h"

/* Output variables */ 
#undef  CDCDK_CDXXDK
#define CDCDK_CDXXDK cdcdK_cdxxdK
#undef  CDCDK_CDXYDK
#define CDCDK_CDXYDK cdcdK_cdxydK
#undef  CDCDK_CDXZDK
#define CDCDK_CDXZDK cdcdK_cdxzdK
#undef  CDCDK_CDYYDK
#define CDCDK_CDYYDK cdcdK_cdyydK
#undef  CDCDK_CDYZDK
#define CDCDK_CDYZDK cdcdK_cdyzdK
#undef  CDCDK_CDZZDK
#define CDCDK_CDZZDK cdcdK_cdzzdK

/* Declare output variables */
      CCTK_REAL CDCDK_CDXXDK
      CCTK_REAL CDCDK_CDXYDK
      CCTK_REAL CDCDK_CDXZDK
      CCTK_REAL CDCDK_CDYYDK
      CCTK_REAL CDCDK_CDYZDK
      CCTK_REAL CDCDK_CDZZDK

#endif

