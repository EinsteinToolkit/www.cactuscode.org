/*@@
  @header   BSDETG_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Determinant of BS 3-metric
  @enddesc
@@*/

#ifndef BSDETG_DECLARE
#define BSDETG_DECLARE

#ifdef FCODE

/* Input variables */

#ifdef OPT

#undef  BSDETG_GXX
#define BSDETG_GXX lg(XX,i,j,kc)
#undef  BSDETG_GXY
#define BSDETG_GXY lg(XY,i,j,kc)
#undef  BSDETG_GXZ
#define BSDETG_GXZ lg(XZ,i,j,kc)
#undef  BSDETG_GYY
#define BSDETG_GYY lg(YY,i,j,kc)
#undef  BSDETG_GYZ
#define BSDETG_GYZ lg(YZ,i,j,kc)
#undef  BSDETG_GZZ
#define BSDETG_GZZ lg(ZZ,i,j,kc)

#else

#undef  BSDETG_GXX
#define BSDETG_GXX ADM_BS_gxx(i,j,k)
#undef  BSDETG_GXY
#define BSDETG_GXY ADM_BS_gxy(i,j,k)
#undef  BSDETG_GXZ
#define BSDETG_GXZ ADM_BS_gxz(i,j,k)
#undef  BSDETG_GYY
#define BSDETG_GYY ADM_BS_gyy(i,j,k)
#undef  BSDETG_GYZ
#define BSDETG_GYZ ADM_BS_gyz(i,j,k)
#undef  BSDETG_GZZ
#define BSDETG_GZZ ADM_BS_gzz(i,j,k)

#endif

/* Output variables */

#undef  BSDETG_DETG
#define BSDETG_DETG bsdetg_detg

/* Temporary variables */

#undef  BSDETG_UXX
#define BSDETG_UXX bsdetg_uxx
#undef  BSDETG_UXY
#define BSDETG_UXY bsdetg_uxy
#undef  BSDETG_UXZ
#define BSDETG_UXZ bsdetg_uxz
#undef  BSDETG_UYY
#define BSDETG_UYY bsdetg_uyy
#undef  BSDETG_UYZ
#define BSDETG_UYZ bsdetg_uyz
#undef  BSDETG_UZZ
#define BSDETG_UZZ bsdetg_uzz

/* Declare output variables */

      CCTK_REAL BSDETG_DETG
      CCTK_REAL BSDETG_UXX, BSDETG_UXY, BSDETG_UXZ
      CCTK_REAL BSDETG_UYY, BSDETG_UYZ, BSDETG_UZZ

#endif




#ifdef CCODE

/* Input variables */

#undef  BSDETG_GXX
#define BSDETG_GXX ADM_BS_gxx[ijk]
#undef  BSDETG_GXY
#define BSDETG_GXY ADM_BS_gxy[ijk]
#undef  BSDETG_GXZ
#define BSDETG_GXZ ADM_BS_gxz[ijk]
#undef  BSDETG_GYY
#define BSDETG_GYY ADM_BS_gyy[ijk]
#undef  BSDETG_GYZ
#define BSDETG_GYZ ADM_BS_gyz[ijk]
#undef  BSDETG_GZZ
#define BSDETG_GZZ ADM_BS_gzz[ijk]

/* Output variables */

#undef  BSDETG_DETG
#define BSDETG_DETG  bsdetg_detg

/* Internal variables */

#undef  BSDETG_UXX
#define BSDETG_UXX bsdetg_uxx
#undef  BSDETG_UXY
#define BSDETG_UXY bsdetg_uxy
#undef  BSDETG_UXZ
#define BSDETG_UXZ bsdetg_uxz
#undef  BSDETG_UYY
#define BSDETG_UYY bsdetg_uyy
#undef  BSDETG_UYZ
#define BSDETG_UYZ bsdetg_uyz
#undef  BSDETG_UZZ
#define BSDETG_UZZ bsdetg_uzz

/* Declare internal variables */

CCTK_REAL BSDETG_UXX;
CCTK_REAL BSDETG_UXY;
CCTK_REAL BSDETG_UXZ;
CCTK_REAL BSDETG_UYY;
CCTK_REAL BSDETG_UYZ;
CCTK_REAL BSDETG_UZZ;

/* Declare output variables */

CCTK_REAL BSDETG_BSDETG;

#endif

#endif


