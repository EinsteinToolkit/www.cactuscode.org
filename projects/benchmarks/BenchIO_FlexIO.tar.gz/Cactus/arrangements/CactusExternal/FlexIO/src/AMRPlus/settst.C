#include <iostream.h>
#include "flexset.h"
#include <unistd.h>

int iseven(const int &y){return !(y&1);}
struct orec;
struct irec{
    int key, data;
    irec(int nkey=0, int ndata=0){key=nkey;data=ndata;}
    int operator<(const irec &b) const{return key<b.key;}
    int operator==(const irec &b) const{return key==b.key;}
    int operator<(const orec &b) const;
    int operator==(const orec &b) const;
};

struct orec{
    int key;
    char *str;
    orec(int nkey=0){key=nkey;}
    int operator<(const orec &b) const{return key<b.key;}
    int operator==(const orec &b) const{return key==b.key;}
    int operator<(const irec &b) const{return key<b.key;}
    int operator==(const irec &b) const{return key==b.key;}
};

int irec::operator<(const orec &b) const{return key<b.key;};
int irec::operator==(const orec &b) const{return key<b.key;};
    
void main(){
    flexset<irec> arr1, arr2, arr3, arr4, arr5;
    flexset<orec> iarr1, iarr2;
    irec tst;
    int ii;
  
    for (ii=0;ii<20;ii++){
	tst.key=rand()%20; 
	tst.data=ii; 
	arr1.insert(tst);
    }
    
    for (ii=0;ii<20;ii++){
	iarr1.insert(rand()%20);
    }
    
    setdifferences(arr1, iarr1, arr2, iarr2);
    for (ii=0;ii<arr1.getSize();ii++)
	cout<<arr1[ii].key<<"   :   "<<arr1[ii].data<<endl;
    cout<<endl;
    for (ii=0;ii<iarr1.getSize();ii++)
	cout<<iarr1[ii].key<<endl;
    cout<<endl;
    for (ii=0;ii<arr2.getSize();ii++)
	cout<<arr2[ii].key<<"   :   "<<arr2[ii].data<<endl;
    cout<<endl;
    for (ii=0;ii<iarr2.getSize();ii++)
	cout<<iarr2[ii].key<<endl;
    cout<<endl;
   
}
