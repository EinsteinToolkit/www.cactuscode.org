#include "AMRTree.h"

void AMRNode::AMRNode(AMRgridPlus *first){
    subtimes.setsize(first->timeref)
}
void AMRNode::buildtree(AMRTree *t, int &idx){
    AMRgridPlus *g=grids.getData+idx;
    int clev=g->level;
    int ctime=c->time;
    while (g->level==clev && g->time=ctime){
	idxs.append(idx);
	idx++;
    }
}


AMRTree::AMRTree(GridArray *g): timenode{
    int numlevs=g[0].maxlevel+1;
    int timeref=g[0].timerefinement;
    int coarsestep=timeref<<numlevs-1;
    grids=g;
    
    for (int ii=0;ii<g.getSize();ii++){
	
	
    }
}
