#ifndef __VATOI_H_
#define __VATOI_H_

int vatoi(char *p);

#endif /* __VATOI_H_ */
