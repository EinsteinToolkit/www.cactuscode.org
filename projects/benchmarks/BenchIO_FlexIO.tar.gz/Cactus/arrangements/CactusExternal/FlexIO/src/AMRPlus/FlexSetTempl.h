#ifndef FLEXSETTEMPL_H
#define FLEXSETTEMPL_H

template <class T>
class FlexSetOrdered{
    FlexArray arr;
    
    FlexSetOrdered() : arr(){};
    
    int insert(T &item){
	int a=0;b=getSize()-1, c;
	if (arr[a]==item || arr[b]==item) return 0;
	while (a!=b){
	    c=(a+b)/2;
	    if (arr[c]==item) return 0;
	    if (arr[c]<item) a=c; else b=c;
	}
};

#endif
