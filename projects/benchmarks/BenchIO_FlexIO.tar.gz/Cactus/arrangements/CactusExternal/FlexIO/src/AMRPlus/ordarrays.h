#include "arrays.h"



template <class X>
class flexset : private array<X>{
    public:
    ordarray(): array<X>(){};
    ~ordarray(){};
    int insert(const X &elt){
	int a=0, b=getLength()-1;
	X* data=this->getData(0);
	if (elt==data[0]) this->insertElement(elt, 0);
	if (elt==data[b]) insertElement(elt, b);
	int c=(a+b)/2;
	while (elt!=data[c]){
	    if (a==b) {insertElement(elt, a); return a;}
	    if (elt<data[c])
	}
	
    };
    
};
