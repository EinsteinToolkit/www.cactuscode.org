/*@@
  @header   SHIFTGAMMA_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc

     Shift terms for the source of the Gamma^i evolution.  These
     terms have the form:

               i       j       i        j      i            i      j
     SHIFTGAMMA  = beta d Gamma  - Gamma d beta  + 2/3 Gamma d beta
                         j                j                   j

                   ~jk        i       ~ij        k
                 + g  d d beta  + 1/3 g  d d beta
                       j k                j k

     Notice that the first 3 terms are what one would expect for the
     Lie derivative of a vector density.  The last 2 terms that involve
     second derivatives of the shift appear because Gamma^i is not a
     vector, but is rather contracted Christoffel symbols.

  @enddesc
  @@*/

#ifndef SHIFTGAMMA_GUTS
#define SHIFTGAMMA_GUTS

#include "macro/BSSN_Derivative.h"

#include "CactusEinstein/ADMMacros/src/macro/DB_guts.h"

#include "macro/DDB_guts.h"
#include "macro/BSUPPERMET_guts.h"
#include "macro/BSGAMMA_guts.h"

c     Advection terms.

      SHIFTGAMMAX = BSSN_ADV_DX_2(ADM_BS_Gx,i,j,k,wx,sx,ssx)
     &            + BSSN_ADV_DY_2(ADM_BS_Gx,i,j,k,wy,sy,ssy)
     &            + BSSN_ADV_DZ_2(ADM_BS_Gx,i,j,k,wz,sz,ssz)
      SHIFTGAMMAY = BSSN_ADV_DX_2(ADM_BS_Gy,i,j,k,wx,sx,ssx)
     &            + BSSN_ADV_DY_2(ADM_BS_Gy,i,j,k,wy,sy,ssy)
     &            + BSSN_ADV_DZ_2(ADM_BS_Gy,i,j,k,wz,sz,ssz)
      SHIFTGAMMAZ = BSSN_ADV_DX_2(ADM_BS_Gz,i,j,k,wx,sx,ssx)
     &            + BSSN_ADV_DY_2(ADM_BS_Gz,i,j,k,wy,sy,ssy)
     &            + BSSN_ADV_DZ_2(ADM_BS_Gz,i,j,k,wz,sz,ssz)

c     Lie derivative terms.  There are two different ways in which we
c     can calculate this.  The first uses the contracted Christoffel
c     symbols and the second the Gammas.  Notice that only one should
c     be used (the other should be commented out), or we will end up
c     adding this term twice.

      SHIFTGAMMA_TEMP = twothird*(DXDB_DXDBX + DYDB_DYDBY + DZDB_DZDBZ)

      SHIFTGAMMAX = SHIFTGAMMAX - (BSGAMMA_GAMMAX*DXDB_DXDBX
     &   + BSGAMMA_GAMMAY*DYDB_DYDBX + BSGAMMA_GAMMAZ*DZDB_DZDBX)
     &   + BSGAMMA_GAMMAX*SHIFTGAMMA_TEMP

      SHIFTGAMMAY = SHIFTGAMMAY - (BSGAMMA_GAMMAX*DXDB_DXDBY
     &   + BSGAMMA_GAMMAY*DYDB_DYDBY + BSGAMMA_GAMMAZ*DZDB_DZDBY)
     &   + BSGAMMA_GAMMAY*SHIFTGAMMA_TEMP

      SHIFTGAMMAZ = SHIFTGAMMAZ - (BSGAMMA_GAMMAX*DXDB_DXDBZ
     &   + BSGAMMA_GAMMAY*DYDB_DYDBZ + BSGAMMA_GAMMAZ*DZDB_DZDBZ)
     &   + BSGAMMA_GAMMAZ*SHIFTGAMMA_TEMP

c     SHIFTGAMMAX = SHIFTGAMMAX - (ADM_BS_Gx(i,j,k)*DXDB_DXDBX
c    &   + ADM_BS_Gy(i,j,k)*DYDB_DYDBX + ADM_BS_Gz(i,j,k)*DZDB_DZDBX)
c    &   + ADM_BS_Gx(i,j,k)*SHIFTGAMMA_TEMP

c     SHIFTGAMMAY = SHIFTGAMMAY - (ADM_BS_Gx(i,j,k)*DXDB_DXDBY
c    &   + ADM_BS_Gy(i,j,k)*DYDB_DYDBY + ADM_BS_Gz(i,j,k)*DZDB_DZDBY)
c    &   + ADM_BS_Gy(i,j,k)*SHIFTGAMMA_TEMP

c     SHIFTGAMMAZ = SHIFTGAMMAZ - (ADM_BS_Gx(i,j,k)*DXDB_DXDBZ
c    &   + ADM_BS_Gy(i,j,k)*DYDB_DYDBZ + ADM_BS_Gz(i,j,k)*DZDB_DZDBZ)
c    &   + ADM_BS_Gz(i,j,k)*SHIFTGAMMA_TEMP

c     Extra terms that compensate for the fact that Gamma^i is not a tensor.
c     All this terms involve second derivatives of the shift.

      SHIFTGAMMAX = SHIFTGAMMAX + BSUPPERMET_UXX*DXXDB_DXXDBX
     &   + BSUPPERMET_UYY*DYYDB_DYYDBX + BSUPPERMET_UZZ*DZZDB_DZZDBX
     &   + 2.0D0*(BSUPPERMET_UXY*DXYDB_DXYDBX + BSUPPERMET_UXZ*DXZDB_DXZDBX
     &   + BSUPPERMET_UYZ*DYZDB_DYZDBX) + third
     &   *(BSUPPERMET_UXX*(DXXDB_DXXDBX + DXYDB_DXYDBY + DXZDB_DXZDBZ)
     &   + BSUPPERMET_UXY*(DXYDB_DXYDBX + DYYDB_DYYDBY + DYZDB_DYZDBZ)
     &   + BSUPPERMET_UXZ*(DXZDB_DXZDBX + DYZDB_DYZDBY + DZZDB_DZZDBZ))

      SHIFTGAMMAY = SHIFTGAMMAY + BSUPPERMET_UXX*DXXDB_DXXDBY
     &   + BSUPPERMET_UYY*DYYDB_DYYDBY + BSUPPERMET_UZZ*DZZDB_DZZDBY
     &   + 2.0D0*(BSUPPERMET_UXY*DXYDB_DXYDBY + BSUPPERMET_UXZ*DXZDB_DXZDBY
     &   + BSUPPERMET_UYZ*DYZDB_DYZDBY) + third
     &   *(BSUPPERMET_UXY*(DXXDB_DXXDBX + DXYDB_DXYDBY + DXZDB_DXZDBZ)
     &   + BSUPPERMET_UYY*(DXYDB_DXYDBX + DYYDB_DYYDBY + DYZDB_DYZDBZ)
     &   + BSUPPERMET_UYZ*(DXZDB_DXZDBX + DYZDB_DYZDBY + DZZDB_DZZDBZ))

      SHIFTGAMMAZ = SHIFTGAMMAZ + BSUPPERMET_UXX*DXXDB_DXXDBZ
     &   + BSUPPERMET_UYY*DYYDB_DYYDBZ + BSUPPERMET_UZZ*DZZDB_DZZDBZ
     &   + 2.0D0*(BSUPPERMET_UXY*DXYDB_DXYDBZ + BSUPPERMET_UXZ*DXZDB_DXZDBZ
     &   + BSUPPERMET_UYZ*DYZDB_DYZDBZ) + third
     &   *(BSUPPERMET_UXZ*(DXXDB_DXXDBX + DXYDB_DXYDBY + DXZDB_DXZDBZ)
     &   + BSUPPERMET_UYZ*(DXYDB_DXYDBX + DYYDB_DYYDBY + DYZDB_DYZDBZ)
     &   + BSUPPERMET_UZZ*(DXZDB_DXZDBX + DYZDB_DYZDBY + DZZDB_DZZDBZ))

#endif
