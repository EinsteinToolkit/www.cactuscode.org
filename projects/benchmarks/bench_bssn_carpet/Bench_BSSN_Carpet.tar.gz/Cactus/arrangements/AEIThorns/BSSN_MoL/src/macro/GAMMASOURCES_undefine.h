/*@@
  @header   GAMMASOURCES_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef GAMMASOURCES_GUTS
#undef GAMMASOURCES_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DA_undefine.h"
#include "macro/BSCHR2_undefine.h"
#include "macro/UPPERA_undefine.h"
#include "macro/DPHI_undefine.h"
#include "macro/DTRK_undefine.h"
#include "macro/BSUPPERMET_undefine.h"
#include "macro/BSHYDRO_undefine.h"

