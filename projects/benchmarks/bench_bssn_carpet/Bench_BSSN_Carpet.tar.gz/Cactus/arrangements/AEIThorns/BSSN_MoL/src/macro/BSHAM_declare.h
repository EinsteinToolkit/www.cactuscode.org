/*@@
  @header   BSHAM_declare.h
  @date     July 2000
  @author   Miguel Alcubierre
  @desc

  Declarations for BS Hamiltonian constraint.

  @enddesc
@@*/

#ifndef BSHAM_DECLARE
#define BSHAM_DECLARE

#include "macro/TRAA_declare.h"
#include "macro/BSRICSCAL_declare.h"

#undef  BSHAM_BSHAM
#define BSHAM_BSHAM bsham_bsham

      CCTK_REAL BSHAM_BSHAM

#endif
