/*@@
  @header   BSCHR2_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Declarations for macro to calculate the Christoffel symbols of the
  second kind

  That is BSCHR2_cab =  BSg^cd BSCHR1_dab

                   =  1/2 BSg^cd (BSg_ad,b + BSgbd,a - BSgab,d)

  @enddesc
@@*/

#ifndef BSCHR2_DECLARE
#define BSCHR2_DECLARE

#include "macro/BSCHR1_declare.h"
#include "macro/BSUPPERMET_declare.h"

#ifdef FCODE

/* Output variables */
#undef  BSCHR2_XXX 
#define BSCHR2_XXX bschr2_111
#undef  BSCHR2_XXY 
#define BSCHR2_XXY bschr2_112 
#undef  BSCHR2_XXZ 
#define BSCHR2_XXZ bschr2_113 
#undef  BSCHR2_XYY 
#define BSCHR2_XYY bschr2_122
#undef  BSCHR2_XYZ 
#define BSCHR2_XYZ bschr2_123
#undef  BSCHR2_XZZ
#define BSCHR2_XZZ bschr2_133
#undef  BSCHR2_YXX
#define BSCHR2_YXX bschr2_211
#undef  BSCHR2_YXY
#define BSCHR2_YXY bschr2_212
#undef  BSCHR2_YXZ
#define BSCHR2_YXZ bschr2_213
#undef  BSCHR2_YYY
#define BSCHR2_YYY bschr2_222
#undef  BSCHR2_YYZ
#define BSCHR2_YYZ bschr2_223
#undef  BSCHR2_YZZ
#define BSCHR2_YZZ bschr2_233
#undef  BSCHR2_ZXX
#define BSCHR2_ZXX bschr2_311
#undef  BSCHR2_ZXY
#define BSCHR2_ZXY bschr2_312
#undef  BSCHR2_ZXZ
#define BSCHR2_ZXZ bschr2_313
#undef  BSCHR2_ZYY
#define BSCHR2_ZYY bschr2_322
#undef  BSCHR2_ZYZ
#define BSCHR2_ZYZ bschr2_323
#undef  BSCHR2_ZZZ
#define BSCHR2_ZZZ bschr2_333

/* Declare output variables */
      CCTK_REAL BSCHR2_XXX
      CCTK_REAL BSCHR2_XXY
      CCTK_REAL BSCHR2_XXZ
      CCTK_REAL BSCHR2_XYY
      CCTK_REAL BSCHR2_XYZ
      CCTK_REAL BSCHR2_XZZ
      CCTK_REAL BSCHR2_YXX
      CCTK_REAL BSCHR2_YXY
      CCTK_REAL BSCHR2_YXZ
      CCTK_REAL BSCHR2_YYY
      CCTK_REAL BSCHR2_YYZ
      CCTK_REAL BSCHR2_YZZ
      CCTK_REAL BSCHR2_ZXX
      CCTK_REAL BSCHR2_ZXY
      CCTK_REAL BSCHR2_ZXZ
      CCTK_REAL BSCHR2_ZYY
      CCTK_REAL BSCHR2_ZYZ
      CCTK_REAL BSCHR2_ZZZ

#endif


#ifdef CCODE

/* Output variables */
#undef  BSCHR2_XXX 
#define BSCHR2_XXX bschr2_111
#undef  BSCHR2_XXY 
#define BSCHR2_XXY bschr2_112 
#undef  BSCHR2_XXZ 
#define BSCHR2_XXZ bschr2_113 
#undef  BSCHR2_XYY 
#define BSCHR2_XYY bschr2_122
#undef  BSCHR2_XYZ 
#define BSCHR2_XYZ bschr2_123
#undef  BSCHR2_XZZ
#define BSCHR2_XZZ bschr2_133
#undef  BSCHR2_YXX
#define BSCHR2_YXX bschr2_211
#undef  BSCHR2_YXY
#define BSCHR2_YXY bschr2_212
#undef  BSCHR2_YXZ
#define BSCHR2_YXZ bschr2_213
#undef  BSCHR2_YYY
#define BSCHR2_YYY bschr2_222
#undef  BSCHR2_YYZ
#define BSCHR2_YYZ bschr2_223
#undef  BSCHR2_YZZ
#define BSCHR2_YZZ bschr2_233
#undef  BSCHR2_ZXX
#define BSCHR2_ZXX bschr2_311
#undef  BSCHR2_ZXY
#define BSCHR2_ZXY bschr2_312
#undef  BSCHR2_ZXZ
#define BSCHR2_ZXZ bschr2_313
#undef  BSCHR2_ZYY
#define BSCHR2_ZYY bschr2_322
#undef  BSCHR2_ZYZ
#define BSCHR2_ZYZ bschr2_323
#undef  BSCHR2_ZZZ
#define BSCHR2_ZZZ bschr2_333

/* Declare output variables */
CCTK_REAL BSCHR2_XXX;
CCTK_REAL BSCHR2_XXY;
CCTK_REAL BSCHR2_XXZ;
CCTK_REAL BSCHR2_XYY;
CCTK_REAL BSCHR2_XYZ;
CCTK_REAL BSCHR2_XZZ;
CCTK_REAL BSCHR2_YXX;
CCTK_REAL BSCHR2_YXY;
CCTK_REAL BSCHR2_YXZ;
CCTK_REAL BSCHR2_YYY;
CCTK_REAL BSCHR2_Y2Z;
CCTK_REAL BSCHR2_YZZ;
CCTK_REAL BSCHR2_ZXX;
CCTK_REAL BSCHR2_ZXY;
CCTK_REAL BSCHR2_ZXZ;
CCTK_REAL BSCHR2_ZYY;
CCTK_REAL BSCHR2_ZYZ;
CCTK_REAL BSCHR2_ZZZ;

#endif

/* Symmetries */
#undef  BSCHR2_XYX 
#define BSCHR2_XYX BSCHR2_XXY
#undef  BSCHR2_XZX 
#define BSCHR2_XZX BSCHR2_XXZ
#undef  BSCHR2_XZY 
#define BSCHR2_XZY BSCHR2_XYZ
#undef  BSCHR2_YYX
#define BSCHR2_YYX BSCHR2_YXY
#undef  BSCHR2_YZX
#define BSCHR2_YZX BSCHR2_YXZ
#undef  BSCHR2_YZY
#define BSCHR2_YZY BSCHR2_YYZ
#undef  BSCHR2_ZYX
#define BSCHR2_ZYX BSCHR2_ZXY
#undef  BSCHR2_ZZX
#define BSCHR2_ZZX BSCHR2_ZXZ
#undef  BSCHR2_ZZY
#define BSCHR2_ZZY BSCHR2_ZYZ

#endif



