/*@@
  @header   DDPHI_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all second spatial derivative of phi
  @enddesc
@@*/

#ifndef DDPHI_GUTS
#define DDPHI_GUTS

#include "macro/BSSN_Derivative.h"

      IF (conformal_state == 0) THEN
         DDPHI_FACXX = 0.0d0
         DDPHI_FACXY = 0.0d0
         DDPHI_FACXZ = 0.0d0
         DDPHI_FACYY = 0.0d0
         DDPHI_FACYZ = 0.0d0
         DDPHI_FACZZ = 0.0d0
      ELSE
         DDPHI_FACXX = -DDPHI_DXDPSI_O_PSI*DDPHI_DXDPSI_O_PSI
     &               + DDPHI_DXXDPSI_O_PSI
         DDPHI_FACXY = -DDPHI_DXDPSI_O_PSI*DDPHI_DYDPSI_O_PSI
     &               + DDPHI_DXYDPSI_O_PSI
         DDPHI_FACXZ = -DDPHI_DXDPSI_O_PSI*DDPHI_DZDPSI_O_PSI
     &               + DDPHI_DXZDPSI_O_PSI
         DDPHI_FACYY = -DDPHI_DYDPSI_O_PSI*DDPHI_DYDPSI_O_PSI
     &               + DDPHI_DYYDPSI_O_PSI
         DDPHI_FACYZ = -DDPHI_DYDPSI_O_PSI*DDPHI_DZDPSI_O_PSI
     &               + DDPHI_DYZDPSI_O_PSI
         DDPHI_FACZZ = -DDPHI_DZDPSI_O_PSI*DDPHI_DZDPSI_O_PSI
     &               + DDPHI_DZZDPSI_O_PSI
      ENDIF

      if (local_spatial_order.eq.2) then 
        DDPHI_DXXDA = BSSN_DXX_2(ADM_BS_phi,i,j,k) + DDPHI_FACXX
        DDPHI_DYYDA = BSSN_DYY_2(ADM_BS_phi,i,j,k) + DDPHI_FACYY
        DDPHI_DZZDA = BSSN_DZZ_2(ADM_BS_phi,i,j,k) + DDPHI_FACZZ
        DDPHI_DXYDA = BSSN_DXY_2(ADM_BS_phi,i,j,k) + DDPHI_FACXY
        DDPHI_DXZDA = BSSN_DXZ_2(ADM_BS_phi,i,j,k) + DDPHI_FACXZ
        DDPHI_DYZDA = BSSN_DYZ_2(ADM_BS_phi,i,j,k) + DDPHI_FACYZ
      else
        DDPHI_DXXDA = BSSN_DXX_4(ADM_BS_phi,i,j,k) + DDPHI_FACXX
        DDPHI_DYYDA = BSSN_DYY_4(ADM_BS_phi,i,j,k) + DDPHI_FACYY
        DDPHI_DZZDA = BSSN_DZZ_4(ADM_BS_phi,i,j,k) + DDPHI_FACZZ
        DDPHI_DXYDA = BSSN_DXY_4(ADM_BS_phi,i,j,k) + DDPHI_FACXY
        DDPHI_DXZDA = BSSN_DXZ_4(ADM_BS_phi,i,j,k) + DDPHI_FACXZ
        DDPHI_DYZDA = BSSN_DYZ_4(ADM_BS_phi,i,j,k) + DDPHI_FACYZ
      end if
#endif

