/* $Header: /numrelcvs/AEIThorns/BSSN_MoL/src/Startup.c,v 1.7 2005/09/26 00:36:03 schnetter Exp $ */

#include <stdio.h>

#include <stdio.h>

#include "cctk.h"
#include "cctk_Parameters.h"
#include "Slicing.h"

/* Prototypes */
void ADM_BSSN_RegisterSlicing(void);
int ADM_BSSN_timetoslice(cGH *GH);


void ADM_BSSN_RegisterSlicing(void)
{
  DECLARE_CCTK_PARAMETERS

  if (CCTK_Equals(evolution_method,"adm_bssn"))
  {
    Einstein_RegisterSlicing("harmonic");
    Einstein_RegisterSlicing("1+log");
    Einstein_RegisterSlicing("shockavoid");
    Einstein_RegisterSlicing("shockavoid0");
    Einstein_RegisterSlicing("shockavoid1");
  }

  return;
}

int ADM_BSSN_timetoslice(cGH *GH)
{
  int tts;

  tts = ((GH->cctk_iteration>0) && (GH->cctk_iteration<3));

  printf("ADM_BSSN_timetoslice: %d tts: %d \n",GH->cctk_iteration, tts);

  return(tts);
}
