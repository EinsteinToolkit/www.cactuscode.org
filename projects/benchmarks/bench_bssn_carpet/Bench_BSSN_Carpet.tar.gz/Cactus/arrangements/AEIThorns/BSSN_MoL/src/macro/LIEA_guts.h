/*@@
  @header   LIEA_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the Lie derivative of the BS Aij.
  @enddesc
@@*/

#ifndef LIEA_GUTS
#define LIEA_GUTS

#include "macro/BSSN_Derivative.h"

#include "CactusEinstein/ADMMacros/src/macro/DB_guts.h"

c     Advection terms.

#ifdef OPT
      LIEA_LAXX =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lA(XX,i,j,kc) - 3.0D0*lA(XX,i+sx,j,kc)
     &   - lA(XX,i+ssx,j,kc) + lA(XX,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lA(XX,i,j,kc) - 3.0D0*lA(XX,i,j+sy,kc)
     &   - lA(XX,i,j+ssy,kc) + lA(XX,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lA(XX,i,j,kc) - 3.0D0*lA(XX,i,j,ks)
     &   - lA(XX,i,j,kss) + lA(XX,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lA(XX,i+1,j,kc) - lA(XX,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lA(XX,i,j+1,kc) - lA(XX,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lA(XX,i,j,kp) - lA(XX,i,j,km))

      LIEA_LAYY =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lA(YY,i,j,kc) - 3.0D0*lA(YY,i+sx,j,kc)
     &   - lA(YY,i+ssx,j,kc) + lA(YY,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lA(YY,i,j,kc) - 3.0D0*lA(YY,i,j+sy,kc)
     &   - lA(YY,i,j+ssy,kc) + lA(YY,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lA(YY,i,j,kc) - 3.0D0*lA(YY,i,j,ks)
     &   - lA(YY,i,j,kss) + lA(YY,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lA(YY,i+1,j,kc) - lA(YY,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lA(YY,i,j+1,kc) - lA(YY,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lA(YY,i,j,kp) - lA(YY,i,j,km))

      LIEA_LAZZ =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lA(ZZ,i,j,kc) - 3.0D0*lA(ZZ,i+sx,j,kc)
     &   - lA(ZZ,i+ssx,j,kc) + lA(ZZ,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lA(ZZ,i,j,kc) - 3.0D0*lA(ZZ,i,j+sy,kc)
     &   - lA(ZZ,i,j+ssy,kc) + lA(ZZ,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lA(ZZ,i,j,kc) - 3.0D0*lA(ZZ,i,j,ks)
     &   - lA(ZZ,i,j,kss) + lA(ZZ,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lA(ZZ,i+1,j,kc) - lA(ZZ,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lA(ZZ,i,j+1,kc) - lA(ZZ,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lA(ZZ,i,j,kp) - lA(ZZ,i,j,km))

      LIEA_LAXY =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lA(XY,i,j,kc) - 3.0D0*lA(XY,i+sx,j,kc)
     &   - lA(XY,i+ssx,j,kc) + lA(XY,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lA(XY,i,j,kc) - 3.0D0*lA(XY,i,j+sy,kc)
     &   - lA(XY,i,j+ssy,kc) + lA(XY,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lA(XY,i,j,kc) - 3.0D0*lA(XY,i,j,ks)
     &   - lA(XY,i,j,kss) + lA(XY,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lA(XY,i+1,j,kc) - lA(XY,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lA(XY,i,j+1,kc) - lA(XY,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lA(XY,i,j,kp) - lA(XY,i,j,km))

      LIEA_LAXZ =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lA(XZ,i,j,kc) - 3.0D0*lA(XZ,i+sx,j,kc)
     &   - lA(XZ,i+ssx,j,kc) + lA(XZ,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lA(XZ,i,j,kc) - 3.0D0*lA(XZ,i,j+sy,kc)
     &   - lA(XZ,i,j+ssy,kc) + lA(XZ,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lA(XZ,i,j,kc) - 3.0D0*lA(XZ,i,j,ks)
     &   - lA(XZ,i,j,kss) + lA(XZ,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lA(XZ,i+1,j,kc) - lA(XZ,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lA(XZ,i,j+1,kc) - lA(XZ,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lA(XZ,i,j,kp) - lA(XZ,i,j,km))

      LIEA_LAYZ =
     &   -(dble(wx*sx)*BETAX_TEMP
     &   *(3.0D0*lA(YZ,i,j,kc) - 3.0D0*lA(YZ,i+sx,j,kc)
     &   - lA(YZ,i+ssx,j,kc) + lA(YZ,i+sx+ssx,j,kc))
     &   + dble(wy*sy)*BETAY_TEMP
     &   *(3.0D0*lA(YZ,i,j,kc) - 3.0D0*lA(YZ,i,j+sy,kc)
     &   - lA(YZ,i,j+ssy,kc) + lA(YZ,i,j+sy+ssy,kc))
     &   + dble(wz*sz)*BETAZ_TEMP
     &   *(3.0D0*lA(YZ,i,j,kc) - 3.0D0*lA(YZ,i,j,ks)
     &   - lA(YZ,i,j,kss) + lA(YZ,i,j,ksss)))
     &   + dble(1-wx)*BETAX_TEMP*(lA(YZ,i+1,j,kc) - lA(YZ,i-1,j,kc))
     &   + dble(1-wy)*BETAY_TEMP*(lA(YZ,i,j+1,kc) - lA(YZ,i,j-1,kc))
     &   + dble(1-wz)*BETAZ_TEMP*(lA(YZ,i,j,kp) - lA(YZ,i,j,km))

#else

      LIEA_LAXX = BSSN_ADV_DX_2(ADM_BS_Axx,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_Axx,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_Axx,i,j,k,wz,sz,ssz)

      LIEA_LAYY = BSSN_ADV_DX_2(ADM_BS_Ayy,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_Ayy,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_Ayy,i,j,k,wz,sz,ssz)

      LIEA_LAZZ = BSSN_ADV_DX_2(ADM_BS_Azz,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_Azz,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_Azz,i,j,k,wz,sz,ssz)

      LIEA_LAXY = BSSN_ADV_DX_2(ADM_BS_Axy,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_Axy,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_Axy,i,j,k,wz,sz,ssz)

      LIEA_LAXZ = BSSN_ADV_DX_2(ADM_BS_Axz,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_Axz,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_Axz,i,j,k,wz,sz,ssz)

      LIEA_LAYZ = BSSN_ADV_DX_2(ADM_BS_Ayz,i,j,k,wx,sx,ssx) 
     &   + BSSN_ADV_DY_2(ADM_BS_Ayz,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_Ayz,i,j,k,wz,sz,ssz)

#endif

c     Extra terms in the Lie derivative.

      LIEA_TEMP = twothird*(DXDB_DXDBX + DYDB_DYDBY + DZDB_DZDBZ)

      LIEA_LAXX = LIEA_LAXX + 2.0D0*(DXDB_DXDBX*LIEA_AXX
     &   + DXDB_DXDBY*LIEA_AXY + DXDB_DXDBZ*LIEA_AXZ)
     &   - LIEA_AXX*LIEA_TEMP

      LIEA_LAYY = LIEA_LAYY + 2.0D0*(DYDB_DYDBX*LIEA_AXY
     &   + DYDB_DYDBY*LIEA_AYY + DYDB_DYDBZ*LIEA_AYZ)
     &   - LIEA_AYY*LIEA_TEMP

      LIEA_LAZZ = LIEA_LAZZ + 2.0D0*(DZDB_DZDBX*LIEA_AXZ
     &   + DZDB_DZDBY*LIEA_AYZ + DZDB_DZDBZ*LIEA_AZZ)
     &   - LIEA_AZZ*LIEA_TEMP

      LIEA_LAXY = LIEA_LAXY + DYDB_DYDBX*LIEA_AXX
     &   + (DXDB_DXDBX + DYDB_DYDBY)*LIEA_AXY
     &   + DYDB_DYDBZ*LIEA_AXZ + DXDB_DXDBY*LIEA_AYY
     &   + DXDB_DXDBZ*LIEA_AYZ - LIEA_AXY*LIEA_TEMP

      LIEA_LAXZ = LIEA_LAXZ + DZDB_DZDBX*LIEA_AXX
     &   + (DXDB_DXDBX + DZDB_DZDBZ)*LIEA_AXZ
     &   + DZDB_DZDBY*LIEA_AXY + DXDB_DXDBY*LIEA_AYZ
     &   + DXDB_DXDBZ*LIEA_AZZ - LIEA_AXZ*LIEA_TEMP

      LIEA_LAYZ = LIEA_LAYZ + DZDB_DZDBX*LIEA_AXY
     &   + (DYDB_DYDBY + DZDB_DZDBZ)*LIEA_AYZ
     &   + DYDB_DYDBX*LIEA_AXZ + DZDB_DZDBY*LIEA_AYY
     &   + DYDB_DYDBZ*LIEA_AZZ - LIEA_AYZ*LIEA_TEMP

#endif
