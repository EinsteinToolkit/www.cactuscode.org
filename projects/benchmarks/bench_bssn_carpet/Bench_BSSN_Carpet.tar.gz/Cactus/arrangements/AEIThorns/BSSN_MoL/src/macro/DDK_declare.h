/*@@
  @header   DDK_declare.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DDK_DECLARE
#define DDK_DECLARE

/* Input variables */
#undef  DDK_K
#define DDK_K ADM_BS_K(i,j,k)
#undef  DDK_K_IP 
#define DDK_K_IP ADM_BS_K(i+1,j,k)
#undef  DDK_K_IM
#define DDK_K_IM ADM_BS_K(i-1,j,k)
#undef  DDK_K_JP 
#define DDK_K_JP ADM_BS_K(i,j+1,k)
#undef  DDK_K_JM 
#define DDK_K_JM ADM_BS_K(i,j-1,k)
#undef  DDK_K_KP 
#define DDK_K_KP ADM_BS_K(i,j,k+1)
#undef  DDK_K_KM
#define DDK_K_KM ADM_BS_K(i,j,k-1)
#undef  DDK_K_IPJP 
#define DDK_K_IPJP ADM_BS_K(i+1,j+1,k)
#undef  DDK_K_IPJM 
#define DDK_K_IPJM ADM_BS_K(i+1,j-1,k)
#undef  DDK_K_IMJP 
#define DDK_K_IMJP ADM_BS_K(i-1,j+1,k)
#undef  DDK_K_IMJM 
#define DDK_K_IMJM ADM_BS_K(i-1,j-1,k)
#undef  DDK_K_IPKP 
#define DDK_K_IPKP ADM_BS_K(i+1,j,k+1)
#undef  DDK_K_IPKM 
#define DDK_K_IPKM ADM_BS_K(i+1,j,k-1)
#undef  DDK_K_IMKP 
#define DDK_K_IMKP ADM_BS_K(i-1,j,k+1)
#undef  DDK_K_IMKM 
#define DDK_K_IMKM ADM_BS_K(i-1,j,k-1)
#undef  DDK_K_JPKP 
#define DDK_K_JPKP ADM_BS_K(i,j+1,k+1)
#undef  DDK_K_JPKM 
#define DDK_K_JPKM ADM_BS_K(i,j+1,k-1)
#undef  DDK_K_JMKP 
#define DDK_K_JMKP ADM_BS_K(i,j-1,k+1)
#undef  DDK_K_JMKM 
#define DDK_K_JMKM ADM_BS_K(i,j-1,k-1)

/* Output variables */ 
#undef  DDK_DXXDK
#define DDK_DXXDK ddK_dxxda
#undef  DDK_DXYDK
#define DDK_DXYDK ddK_dxyda
#undef  DDK_DXZDK
#define DDK_DXZDK ddK_dxzda
#undef  DDK_DYYDK
#define DDK_DYYDK ddK_dyyda
#undef  DDK_DYZDK
#define DDK_DYZDK ddK_dyzda
#undef  DDK_DZZDK
#define DDK_DZZDK ddK_dzzda

/* Internal variables */
#undef  DDK_OODX2   
#define DDK_OODX2 ddK_oodx2
#undef  DDK_OODY2   
#define DDK_OODY2 ddK_oody2
#undef  DDK_OODZ2   
#define DDK_OODZ2 ddK_oodz2
#undef  DDK_OO4DXDY
#define DDK_OO4DXDY ddK_oo4dxdy
#undef  DDK_OO4DXDZ
#define DDK_OO4DXDZ ddK_oo4dxdz
#undef  DDK_OO4DYDZ
#define DDK_OO4DYDZ ddK_oo4dydz
#undef  DDK_DX
#define DDK_DX dx
#undef  DDK_DY
#define DDK_DY dy
#undef  DDK_DZ
#define DDK_DZ dz

/* Declare internal variables */
      CCTK_REAL DDK_OODX2
      CCTK_REAL DDK_OODY2
      CCTK_REAL DDK_OODZ2
      CCTK_REAL DDK_OO4DXDY
      CCTK_REAL DDK_OO4DXDZ
      CCTK_REAL DDK_OO4DYDZ

/* Declare output variables */
      CCTK_REAL DDK_DXXDK
      CCTK_REAL DDK_DXYDK
      CCTK_REAL DDK_DXZDK
      CCTK_REAL DDK_DYYDK
      CCTK_REAL DDK_DYZDK
      CCTK_REAL DDK_DZZDK

#endif



