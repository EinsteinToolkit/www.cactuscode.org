/*@@
  @header   DYZDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DYZDB_DECLARE
#define DYZDB_DECLARE

/* Input variables */

#undef  DYZDB_BX_JPKP
#define DYZDB_BX_JPKP   betax(i,j+1,k+1)
#undef  DYZDB_BY_JPKP
#define DYZDB_BY_JPKP   betay(i,j+1,k+1)
#undef  DYZDB_BZ_JPKP
#define DYZDB_BZ_JPKP   betaz(i,j+1,k+1)

#undef  DYZDB_BX_JPKM
#define DYZDB_BX_JPKM   betax(i,j+1,k-1)
#undef  DYZDB_BY_JPKM
#define DYZDB_BY_JPKM   betay(i,j+1,k-1)
#undef  DYZDB_BZ_JPKM
#define DYZDB_BZ_JPKM   betaz(i,j+1,k-1)

#undef  DYZDB_BX_JMKP
#define DYZDB_BX_JMKP   betax(i,j-1,k+1)
#undef  DYZDB_BY_JMKP
#define DYZDB_BY_JMKP   betay(i,j-1,k+1)
#undef  DYZDB_BZ_JMKP
#define DYZDB_BZ_JMKP   betaz(i,j-1,k+1)

#undef  DYZDB_BX_JMKM
#define DYZDB_BX_JMKM   betax(i,j-1,k-1)
#undef  DYZDB_BY_JMKM
#define DYZDB_BY_JMKM   betay(i,j-1,k-1)
#undef  DYZDB_BZ_JMKM
#define DYZDB_BZ_JMKM   betaz(i,j-1,k-1)

/* Internal variables */

#undef  DYZDB_TEMP
#define DYZDB_TEMP  dyzdb_temp

/* Output variables */ 

#undef  DYZDB_DYZDBX
#define DYZDB_DYZDBX  dyzdb_dyzdbx
#undef  DYZDB_DYZDBY
#define DYZDB_DYZDBY  dyzdb_dyzdby
#undef  DYZDB_DYZDBZ
#define DYZDB_DYZDBZ  dyzdb_dyzdbz

/* Declare variables */

      CCTK_REAL DYZDB_TEMP
      CCTK_REAL DYZDB_DYZDBX
      CCTK_REAL DYZDB_DYZDBY
      CCTK_REAL DYZDB_DYZDBZ

#endif
