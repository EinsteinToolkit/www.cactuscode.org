
#ifndef ALPSOURCES_DECLARE
#define ALPSOURCES_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DA_declare.h"
#include "CactusEinstein/ADMMacros/src/macro/DDA_declare.h"
#include "macro/NABALPHA_declare.h"

#undef  ALPSOURCES_TEMP
#define ALPSOURCES_TEMP alpsources_temp

      CCTK_REAL ALPSOURCES_TEMP

#endif
