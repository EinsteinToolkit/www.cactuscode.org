/*@@
  @header   BSSN_Derivative.h
  @date     June 2002
  @author   Denis Pollney
  @desc
            Derivative operators.
  @enddesc
@@*/


#ifndef BSSN_DERIVATIVE_H
#define BSSN_DERIVATIVE_H

#include "CactusEinstein/ADMMacros/src/macro/ADM_Spacing.h"

/*
 *   2nd order centred operators.
 */ 

#define BSSN_DX_2(var,i,j,k)   I2DX*(var(i+1,j,k) - var(i-1,j,k))
#define BSSN_DY_2(var,i,j,k)   I2DY*(var(i,j+1,k) - var(i,j-1,k))
#define BSSN_DZ_2(var,i,j,k)   I2DZ*(var(i,j,k+1) - var(i,j,k-1))

#define BSSN_DXX_2(var,i,j,k)  IDXX*(var(i+1,j,k) - 2.d0*var(i,j,k) \
                                     + var(i-1,j,k))
#define BSSN_DYY_2(var,i,j,k)  IDYY*(var(i,j+1,k) - 2.d0*var(i,j,k) \
                                     + var(i,j-1,k))
#define BSSN_DZZ_2(var,i,j,k)  IDZZ*(var(i,j,k+1) - 2.d0*var(i,j,k) \
                                     + var(i,j,k-1))

#define BSSN_DXY_2(var,i,j,k)  IDXY*(var(i+1,j+1,k) - var(i+1,j-1,k) \
                                     - var(i-1,j+1,k) + var(i-1,j-1,k))
#define BSSN_DXZ_2(var,i,j,k)  IDXZ*(var(i+1,j,k+1) - var(i+1,j,k-1) \
                                     - var(i-1,j,k+1) + var(i-1,j,k-1))
#define BSSN_DYZ_2(var,i,j,k)  IDYZ*(var(i,j+1,k+1) - var(i,j+1,k-1) \
                                     - var(i,j-1,k+1) + var(i,j-1,k-1))
/*
 *   4th order centred operators.
 */

#define BSSN_DX_4(var,i,j,k)   I12DX*(-var(i+2,j,k) + var(i-2,j,k) \
                                      + 8.d0*(var(i+1,j,k) - var(i-1,j,k)))
#define BSSN_DY_4(var,i,j,k)   I12DY*(-var(i,j+2,k) + var(i,j-2,k) \
                                      + 8.d0*(var(i,j+1,k) - var(i,j-1,k)))
#define BSSN_DZ_4(var,i,j,k)   I12DZ*(-var(i,j,k+2) + var(i,j,k-2) \
                                      + 8.d0*(var(i,j,k+1) - var(i,j,k-1)))

#define BSSN_DXX_4(var,i,j,k)  I12DXX*(-var(i+2,j,k) - var(i-2,j,k) \
                                       + 16.d0*(var(i+1,j,k) + var(i-1,j,k)) \
                                       - 30.d0*var(i,j,k))
#define BSSN_DYY_4(var,i,j,k)  I12DYY*(-var(i,j+2,k) - var(i,j-2,k) \
                                       + 16.d0*(var(i,j+1,k) + var(i,j-1,k)) \
                                       - 30.d0*var(i,j,k))
#define BSSN_DZZ_4(var,i,j,k)  I12DZZ*(-var(i,j,k+2) - var(i,j,k-2) \
                                       + 16.d0*(var(i,j,k+1) + var(i,j,k-1)) \
                                       - 30.d0*var(i,j,k))

#define BSSN_DXY_4(var,i,j,k)  I36DXY* \
  (var(i+2,j+2,k) - var(i+2,j-2,k) - var(i-2,j+2,k) + var(i-2,j-2,k) \
 + 8.d0*(-var(i+2,j+1,k) + var(i+2,j-1,k) - var(i+1,j+2,k) + var(i+1,j-2,k) \
         + var(i-2,j+1,k) - var(i-2,j-1,k) - var(i-1,j-2,k) + var(i-1,j+2,k)) \
 + 64.d0*(var(i+1,j+1,k) - var(i+1,j-1,k) - var(i-1,j+1,k) + var(i-1,j-1,k)))
#define BSSN_DXZ_4(var,i,j,k)  I36DXZ* \
  (var(i+2,j,k+2) - var(i+2,j,k-2) - var(i-2,j,k+2) + var(i-2,j,k-2) \
 + 8.d0*(-var(i+2,j,k+1) + var(i+2,j,k-1) - var(i+1,j,k+2) + var(i+1,j,k-2) \
         + var(i-2,j,k+1) - var(i-2,j,k-1) - var(i-1,j,k-2) + var(i-1,j,k+2)) \
 + 64.d0*(var(i+1,j,k+1) - var(i+1,j,k-1) - var(i-1,j,k+1) + var(i-1,j,k-1)))
#define BSSN_DYZ_4(var,i,j,k)  I36DYZ* \
  (var(i,j+2,k+2) - var(i,j+2,k-2) - var(i,j-2,k+2) + var(i,j-2,k-2) \
 + 8.d0*(-var(i,j+2,k+1) + var(i,j+2,k-1) - var(i,j+1,k+2) + var(i,j+1,k-2) \
         + var(i,j-2,k+1) - var(i,j-2,k-1) - var(i,j-1,k-2) + var(i,j-1,k+2)) \
 + 64.d0*(var(i,j+1,k+1) - var(i,j+1,k-1) - var(i,j-1,k+1) + var(i,j-1,k-1)))


/* advection terms */

#define BSSN_ADV_DX_2(var,i,j,k,wx,sx,ssx) I2DX*betax(i,j,k)* ( \
                          -dble(wx*sx)*(3.d0*(var(i,j,k) - var(i+sx,j,k)) \
 			                - var(i+ssx,j,k) + var(i+sx+ssx,j,k)) \
                          + dble(1-wx)*(var(i+1,j,k) - var(i-1,j,k)))
#define BSSN_ADV_DY_2(var,i,j,k,wy,sy,syy) I2DY*betay(i,j,k)* ( \
                          -dble(wy*sy)*(3.d0*(var(i,j,k) - var(i,j+sy,k)) \
                                        - var(i,j+ssy,k) + var(i,j+sy+syy,k)) \
                          + dble(1-wy)*(var(i,j+1,k) - var(i,j-1,k)))
#define BSSN_ADV_DZ_2(var,i,j,k,wz,sz,szz) I2DZ*betaz(i,j,k)* ( \
                          -dble(wz*sz)*(3.d0*(var(i,j,k) - var(i,j,k+sz)) \
                                        - var(i,j,k+ssz) + var(i,j,k+sz+ssz)) \
                          + dble(1-wz)*(var(i,j,k+1) - var(i,j,k-1)))

#endif
