/*@@
  @header   WAVEBSG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate wave operator acting on the BS metric 

  That is BSg^lm BSg_ij,lm

  @enddesc
@@*/

#undef WAVEBSG_GUTS
#undef WAVEBSG_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/BSDDG_undefine.h"

