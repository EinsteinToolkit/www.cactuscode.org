/*@@
  @header   BSTRS_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the trace of the BS matter variable
  Sij, note that it uses the definition of Sij in Eq 8
  to do this
  scheme
  @enddesc
@@*/

#undef BSTRS_GUTS
#undef BSTRS_DECLARE

#include "macro/BSUPPERMET_undefine.h"
#include "macro/BSHYDRO_undefine.h"


