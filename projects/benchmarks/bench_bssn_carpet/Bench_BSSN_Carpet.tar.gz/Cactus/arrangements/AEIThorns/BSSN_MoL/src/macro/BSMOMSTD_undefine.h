/*@@
  @header   BSMOMSTD_undefine.h
  @date     July 2002
  @author   Denis Pollney
  @desc
  @enddesc
@@*/

#undef BSMOMSTD_GUTS
#undef BSMOMSTD_DECLARE

#include "macro/DPHI_undefine.h"
#include "macro/BSMOM_undefine.h"





  
