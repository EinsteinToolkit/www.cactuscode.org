/*@@
  @header   DXXDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DXXDB_GUTS
#define DXXDB_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        DXXDB_DXXDBX = BSSN_DXX_2(betax,i,j,k)
        DXXDB_DXXDBY = BSSN_DXX_2(betay,i,j,k)
        DXXDB_DXXDBZ = BSSN_DXX_2(betaz,i,j,k)
      else
        DXXDB_DXXDBX = BSSN_DXX_4(betax,i,j,k)
        DXXDB_DXXDBY = BSSN_DXX_4(betay,i,j,k)
        DXXDB_DXXDBZ = BSSN_DXX_4(betaz,i,j,k)
      end if
#endif
