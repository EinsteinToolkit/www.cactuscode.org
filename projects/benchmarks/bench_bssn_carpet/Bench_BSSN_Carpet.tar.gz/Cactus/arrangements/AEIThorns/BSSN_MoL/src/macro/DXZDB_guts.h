/*@@
  @header   DXZDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DXZDB_GUTS
#define DXZDB_GUTS

#include "macro/BSSN_Derivative.h"

      if (local_spatial_order.eq.2) then
        DXZDB_DXZDBX = BSSN_DXZ_2(betax,i,j,k)
        DXZDB_DXZDBY = BSSN_DXZ_2(betay,i,j,k)
        DXZDB_DXZDBZ = BSSN_DXZ_2(betaz,i,j,k)
      else
        DXZDB_DXZDBX = BSSN_DXZ_4(betax,i,j,k)
        DXZDB_DXZDBY = BSSN_DXZ_4(betay,i,j,k)
        DXZDB_DXZDBZ = BSSN_DXZ_4(betaz,i,j,k)
      end if
#endif
