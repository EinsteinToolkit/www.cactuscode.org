/*@@
  @header   DXZDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DXZDB_DECLARE
#define DXZDB_DECLARE

/* Input variables */

#undef  DXZDB_BX_IPKP
#define DXZDB_BX_IPKP   betax(i+1,j,k+1)
#undef  DXZDB_BY_IPKP
#define DXZDB_BY_IPKP   betay(i+1,j,k+1)
#undef  DXZDB_BZ_IPKP
#define DXZDB_BZ_IPKP   betaz(i+1,j,k+1)

#undef  DXZDB_BX_IPKM
#define DXZDB_BX_IPKM   betax(i+1,j,k-1)
#undef  DXZDB_BY_IPKM
#define DXZDB_BY_IPKM   betay(i+1,j,k-1)
#undef  DXZDB_BZ_IPKM
#define DXZDB_BZ_IPKM   betaz(i+1,j,k-1)

#undef  DXZDB_BX_IMKP
#define DXZDB_BX_IMKP   betax(i-1,j,k+1)
#undef  DXZDB_BY_IMKP
#define DXZDB_BY_IMKP   betay(i-1,j,k+1)
#undef  DXZDB_BZ_IMKP
#define DXZDB_BZ_IMKP   betaz(i-1,j,k+1)

#undef  DXZDB_BX_IMKM
#define DXZDB_BX_IMKM   betax(i-1,j,k-1)
#undef  DXZDB_BY_IMKM
#define DXZDB_BY_IMKM   betay(i-1,j,k-1)
#undef  DXZDB_BZ_IMKM
#define DXZDB_BZ_IMKM   betaz(i-1,j,k-1)

/* Internal variables */

#undef  DXZDB_TEMP
#define DXZDB_TEMP  dxzdb_temp

/* Output variables */ 

#undef  DXZDB_DXZDBX
#define DXZDB_DXZDBX  dxzdb_dxzdbx
#undef  DXZDB_DXZDBY
#define DXZDB_DXZDBY  dxzdb_dxzdby
#undef  DXZDB_DXZDBZ
#define DXZDB_DXZDBZ  dxzdb_dxzdbz

/* Declare variables */

      CCTK_REAL DXZDB_TEMP
      CCTK_REAL DXZDB_DXZDBX
      CCTK_REAL DXZDB_DXZDBY
      CCTK_REAL DXZDB_DXZDBZ

#endif
