/*@@
  @header   BSDYDA_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the first derivatives of the 
     BS Aij with respect to x
  @enddesc
@@*/

#ifndef BSDYDA_GUTS
#define BSDYDA_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        BSDYDA_DYDAXX = BSSN_DY_2(ADM_BS_Axx,i,j,k)
        BSDYDA_DYDAXY = BSSN_DY_2(ADM_BS_Axy,i,j,k)
        BSDYDA_DYDAXZ = BSSN_DY_2(ADM_BS_Axz,i,j,k)
        BSDYDA_DYDAYY = BSSN_DY_2(ADM_BS_Ayy,i,j,k)
        BSDYDA_DYDAYZ = BSSN_DY_2(ADM_BS_Ayz,i,j,k)
        BSDYDA_DYDAZZ = BSSN_DY_2(ADM_BS_Azz,i,j,k)
      else
        BSDYDA_DYDAXX = BSSN_DY_4(ADM_BS_Axx,i,j,k)
        BSDYDA_DYDAXY = BSSN_DY_4(ADM_BS_Axy,i,j,k)
        BSDYDA_DYDAXZ = BSSN_DY_4(ADM_BS_Axz,i,j,k)
        BSDYDA_DYDAYY = BSSN_DY_4(ADM_BS_Ayy,i,j,k)
        BSDYDA_DYDAYZ = BSSN_DY_4(ADM_BS_Ayz,i,j,k)
        BSDYDA_DYDAZZ = BSSN_DY_4(ADM_BS_Azz,i,j,k)
      end if   
#endif

