/*@@
  @header   BSDETG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Determinant of BS 3-metric
  @enddesc
@@*/

#undef BSDETG_GUTS
#undef BSDETG_DECLARE

