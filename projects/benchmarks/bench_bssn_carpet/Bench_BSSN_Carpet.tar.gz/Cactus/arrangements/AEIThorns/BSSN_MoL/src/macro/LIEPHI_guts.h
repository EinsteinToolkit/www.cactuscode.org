/*@@
  @header   LIEPHI_guts.h
  @date     August 2001
  @author   Miguel Alcubierre
  @desc
     Macro to calculate the Lie derivative
     of the conformal factor phi.
  @enddesc
@@*/

#ifndef LIEPHI_GUTS
#define LIEPHI_GUTS

#include "macro/BSSN_Derivative.h"
#include "CactusEinstein/ADMMacros/src/macro/DB_guts.h"

c     Advection.

      LIEPHI_LPHI = BSSN_ADV_DX_2(ADM_BS_phi,i,j,k,wx,sx,ssx)
     &   + BSSN_ADV_DY_2(ADM_BS_phi,i,j,k,wy,sy,ssy)
     &   + BSSN_ADV_DZ_2(ADM_BS_phi,i,j,k,wz,sz,ssz)

c     Add static conformal factor term.

      if (conformal_state .ne. 0) then
         LIEPHI_LPHI = LIEPHI_LPHI
     &      + betax(i,j,k)*psix(i,j,k)
     &      + betay(i,j,k)*psiy(i,j,k)
     &      + betaz(i,j,k)*psiz(i,j,k)
      end if

c     Extra terms in the Lie derivative.

      LIEPHI_LPHI = LIEPHI_LPHI
     &   + sixth*(DXDB_DXDBX + DYDB_DYDBY + DZDB_DZDBZ)

#endif
