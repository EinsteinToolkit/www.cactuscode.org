/*@@
  @header   AA_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef AA_GUTS
#undef AA_DECLARE

#include "macro/BSUPPERMET_undefine.h"

  
