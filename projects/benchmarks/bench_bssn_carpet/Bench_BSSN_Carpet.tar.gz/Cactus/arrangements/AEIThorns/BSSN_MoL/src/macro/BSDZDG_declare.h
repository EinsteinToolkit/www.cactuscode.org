/*@@
  @header   BSDZDG_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#ifndef BSDZDG_DECLARE
#define BSDZDG_DECLARE

/* Input variables */
#ifdef OPT

#undef  BSDZDG_GXX_KP   
#define BSDZDG_GXX_KP   lg(XX,i,j,kp)
#undef  BSDZDG_GXY_KP   
#define BSDZDG_GXY_KP   lg(XY,i,j,kp)
#undef  BSDZDG_GXZ_KP  
#define BSDZDG_GXZ_KP   lg(XZ,i,j,kp)
#undef  BSDZDG_GYY_KP    
#define BSDZDG_GYY_KP   lg(YY,i,j,kp)
#undef  BSDZDG_GYZ_KP   
#define BSDZDG_GYZ_KP   lg(YZ,i,j,kp)
#undef  BSDZDG_GZZ_KP   
#define BSDZDG_GZZ_KP   lg(ZZ,i,j,kp)

#undef  BSDZDG_GXX_KM   
#define BSDZDG_GXX_KM   lg(XX,i,j,km)
#undef  BSDZDG_GXY_KM   
#define BSDZDG_GXY_KM   lg(XY,i,j,km)
#undef  BSDZDG_GXZ_KM  
#define BSDZDG_GXZ_KM   lg(XZ,i,j,km)
#undef  BSDZDG_GYY_KM    
#define BSDZDG_GYY_KM   lg(YY,i,j,km)
#undef  BSDZDG_GYZ_KM   
#define BSDZDG_GYZ_KM   lg(YZ,i,j,km)
#undef  BSDZDG_GZZ_KM   
#define BSDZDG_GZZ_KM   lg(ZZ,i,j,km)

#else

#undef  BSDZDG_GXX_KP   
#define BSDZDG_GXX_KP   ADM_BS_gxx(i,j,k+1)
#undef  BSDZDG_GXY_KP   
#define BSDZDG_GXY_KP   ADM_BS_gxy(i,j,k+1)
#undef  BSDZDG_GXZ_KP  
#define BSDZDG_GXZ_KP   ADM_BS_gxz(i,j,k+1)
#undef  BSDZDG_GYY_KP    
#define BSDZDG_GYY_KP   ADM_BS_gyy(i,j,k+1)
#undef  BSDZDG_GYZ_KP   
#define BSDZDG_GYZ_KP   ADM_BS_gyz(i,j,k+1)
#undef  BSDZDG_GZZ_KP   
#define BSDZDG_GZZ_KP   ADM_BS_gzz(i,j,k+1)

#undef  BSDZDG_GXX_KM   
#define BSDZDG_GXX_KM   ADM_BS_gxx(i,j,k-1)
#undef  BSDZDG_GXY_KM   
#define BSDZDG_GXY_KM   ADM_BS_gxy(i,j,k-1)
#undef  BSDZDG_GXZ_KM  
#define BSDZDG_GXZ_KM   ADM_BS_gxz(i,j,k-1)
#undef  BSDZDG_GYY_KM    
#define BSDZDG_GYY_KM   ADM_BS_gyy(i,j,k-1)
#undef  BSDZDG_GYZ_KM   
#define BSDZDG_GYZ_KM   ADM_BS_gyz(i,j,k-1)
#undef  BSDZDG_GZZ_KM   
#define BSDZDG_GZZ_KM   ADM_BS_gzz(i,j,k-1)

#endif

/* Output variables */ 
#undef  BSDZDG_DZDGXX
#define BSDZDG_DZDGXX  bsdzdg_dzdgxx
#undef  BSDZDG_DZDGXY
#define BSDZDG_DZDGXY  bsdzdg_dzdgxy
#undef  BSDZDG_DZDGXZ
#define BSDZDG_DZDGXZ  bsdzdg_dzdgxz
#undef  BSDZDG_DZDGYY
#define BSDZDG_DZDGYY  bsdzdg_dzdgyy
#undef  BSDZDG_DZDGYZ
#define BSDZDG_DZDGYZ  bsdzdg_dzdgyz
#undef  BSDZDG_DZDGZZ
#define BSDZDG_DZDGZZ  bsdzdg_dzdgzz

/* Internal variables */
#undef  BSDZDG_DZFAC
#define BSDZDG_DZFAC   bsdzdg_dzfac

/* Declare internal variables */
      CCTK_REAL BSDZDG_DZFAC;

/* Declare output variables */
      CCTK_REAL BSDZDG_DZDGXX;
      CCTK_REAL BSDZDG_DZDGXY;
      CCTK_REAL BSDZDG_DZDGXZ;
      CCTK_REAL BSDZDG_DZDGYY;
      CCTK_REAL BSDZDG_DZDGYZ;
      CCTK_REAL BSDZDG_DZDGZZ;

#endif
