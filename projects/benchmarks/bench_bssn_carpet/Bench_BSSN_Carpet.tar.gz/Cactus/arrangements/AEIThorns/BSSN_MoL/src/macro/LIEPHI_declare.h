/*@@
  @header   LIEPHI_declare.h
  @date     August 2001
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef LIEPHI_DECLARE
#define LIEPHI_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_declare.h"

#undef  LIEPHI_LPHI
#define LIEPHI_LPHI liephi_lphi

      CCTK_REAL LIEPHI_LPHI

#endif
