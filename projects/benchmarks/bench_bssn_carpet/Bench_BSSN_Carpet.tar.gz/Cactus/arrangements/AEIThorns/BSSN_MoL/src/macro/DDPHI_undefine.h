/*@@
  @header   DDPHI_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DDPHI_GUTS
#undef DDPHI_DECLARE

