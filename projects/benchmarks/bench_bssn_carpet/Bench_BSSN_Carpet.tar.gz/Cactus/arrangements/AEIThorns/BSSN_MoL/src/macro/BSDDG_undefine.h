/*@@
  @header   BSDDG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/ 

#undef BSDDG_GUTS
#undef BSDDG_DECLARE

#include "macro/BSDXDG_undefine.h"
#include "macro/BSDYDG_undefine.h"
#include "macro/BSDZDG_undefine.h"

