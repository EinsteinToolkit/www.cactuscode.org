/*@@
  @header  WAVEBSG_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate wave operator acting on the BS metric 

  That is BSg^lm Bsg_ij,lm

  @enddesc
@@*/

#ifndef WAVEBSG_DECLARE
#define WAVEBSG_DECLARE

#include "macro/BSUPPERMET_declare.h"
#include "macro/BSDDG_declare.h"

/* Output variables */ 
#undef  WAVEBSG_DDGXX
#define WAVEBSG_DDGXX wavebsg_ddgxx
#undef  WAVEBSG_DDGXY
#define WAVEBSG_DDGXY wavebsg_ddgxy
#undef  WAVEBSG_DDGXZ
#define WAVEBSG_DDGXZ wavebsg_ddgxz
#undef  WAVEBSG_DDGYY
#define WAVEBSG_DDGYY wavebsg_ddgyy
#undef  WAVEBSG_DDGYZ
#define WAVEBSG_DDGYZ wavebsg_ddgyz
#undef  WAVEBSG_DDGZZ
#define WAVEBSG_DDGZZ wavebsg_ddgzz

      CCTK_REAL WAVEBSG_DDGXX
      CCTK_REAL WAVEBSG_DDGXY
      CCTK_REAL WAVEBSG_DDGXZ
      CCTK_REAL WAVEBSG_DDGYY
      CCTK_REAL WAVEBSG_DDGYZ
      CCTK_REAL WAVEBSG_DDGZZ

#endif

