/*@@
  @header   DDK_guts.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  Macro to calculate all second spatial derivative of K
  @enddesc
@@*/

#ifndef DDK_GUTS
#define DDK_GUTS

#include "macro/BSSN_Derivative.h"
      if (local_spatial_order.eq.2) then
        DDK_DXXDA = BSSN_DXX_2(ADM_BS_K,i,j,k)
        DDK_DYYDA = BSSN_DYY_2(ADM_BS_K,i,j,k)
        DDK_DZZDA = BSSN_DZZ_2(ADM_BS_K,i,j,k)
        DDK_DXXDA = BSSN_DXY_2(ADM_BS_K,i,j,k)
        DDK_DYYDA = BSSN_DXZ_2(ADM_BS_K,i,j,k)
        DDK_DZZDA = BSSN_DZZ_2(ADM_BS_K,i,j,k)
      else
        DDK_DXXDA = BSSN_DXX_4(ADM_BS_K,i,j,k)
        DDK_DYYDA = BSSN_DYY_4(ADM_BS_K,i,j,k)
        DDK_DZZDA = BSSN_DZZ_4(ADM_BS_K,i,j,k)
        DDK_DXXDA = BSSN_DXY_4(ADM_BS_K,i,j,k)
        DDK_DYYDA = BSSN_DXZ_4(ADM_BS_K,i,j,k)
        DDK_DZZDA = BSSN_DZZ_4(ADM_BS_K,i,j,k)
      end if
#endif

