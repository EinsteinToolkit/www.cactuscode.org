/*@@
  @header   BSDDG_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate all the second derivatives of the 
  BS metric with respect to x, y, z
  @enddesc
@@*/ 

#ifndef BSDDG_GUTS 
#define BSDDG_GUTS

#include "macro/BSSN_Derivative.h"

      if (local_spatial_order.eq.2) then
        BSDDG_DXXDGXX = BSSN_DXX_2(ADM_BS_gxx,i,j,k)
        BSDDG_DYYDGXX = BSSN_DYY_2(ADM_BS_gxx,i,j,k)
        BSDDG_DZZDGXX = BSSN_DZZ_2(ADM_BS_gxx,i,j,k)
        BSDDG_DXYDGXX = BSSN_DXY_2(ADM_BS_gxx,i,j,k)
        BSDDG_DXZDGXX = BSSN_DXZ_2(ADM_BS_gxx,i,j,k)
        BSDDG_DYZDGXX = BSSN_DYZ_2(ADM_BS_gxx,i,j,k)

        BSDDG_DXXDGYY = BSSN_DXX_2(ADM_BS_gyy,i,j,k)
        BSDDG_DYYDGYY = BSSN_DYY_2(ADM_BS_gyy,i,j,k)
        BSDDG_DZZDGYY = BSSN_DZZ_2(ADM_BS_gyy,i,j,k)
        BSDDG_DXYDGYY = BSSN_DXY_2(ADM_BS_gyy,i,j,k)
        BSDDG_DXZDGYY = BSSN_DXZ_2(ADM_BS_gyy,i,j,k)
        BSDDG_DYZDGYY = BSSN_DYZ_2(ADM_BS_gyy,i,j,k)

        BSDDG_DXXDGZZ = BSSN_DXX_2(ADM_BS_gzz,i,j,k)
        BSDDG_DYYDGZZ = BSSN_DYY_2(ADM_BS_gzz,i,j,k)
        BSDDG_DZZDGZZ = BSSN_DZZ_2(ADM_BS_gzz,i,j,k)
        BSDDG_DXYDGZZ = BSSN_DXY_2(ADM_BS_gzz,i,j,k)
        BSDDG_DXZDGZZ = BSSN_DXZ_2(ADM_BS_gzz,i,j,k)
        BSDDG_DYZDGZZ = BSSN_DYZ_2(ADM_BS_gzz,i,j,k)

        BSDDG_DXXDGXY = BSSN_DXX_2(ADM_BS_gxy,i,j,k)
        BSDDG_DYYDGXY = BSSN_DYY_2(ADM_BS_gxy,i,j,k)
        BSDDG_DZZDGXY = BSSN_DZZ_2(ADM_BS_gxy,i,j,k)
        BSDDG_DXYDGXY = BSSN_DXY_2(ADM_BS_gxy,i,j,k)
        BSDDG_DXZDGXY = BSSN_DXZ_2(ADM_BS_gxy,i,j,k)
        BSDDG_DYZDGXY = BSSN_DYZ_2(ADM_BS_gxy,i,j,k)

        BSDDG_DXXDGXZ = BSSN_DXX_2(ADM_BS_gxz,i,j,k)
        BSDDG_DYYDGXZ = BSSN_DYY_2(ADM_BS_gxz,i,j,k)
        BSDDG_DZZDGXZ = BSSN_DZZ_2(ADM_BS_gxz,i,j,k)
        BSDDG_DXYDGXZ = BSSN_DXY_2(ADM_BS_gxz,i,j,k)
        BSDDG_DXZDGXZ = BSSN_DXZ_2(ADM_BS_gxz,i,j,k)
        BSDDG_DYZDGXZ = BSSN_DYZ_2(ADM_BS_gxz,i,j,k)

        BSDDG_DXXDGYZ = BSSN_DXX_2(ADM_BS_gyz,i,j,k)
        BSDDG_DYYDGYZ = BSSN_DYY_2(ADM_BS_gyz,i,j,k)
        BSDDG_DZZDGYZ = BSSN_DZZ_2(ADM_BS_gyz,i,j,k)
        BSDDG_DXYDGYZ = BSSN_DXY_2(ADM_BS_gyz,i,j,k)
        BSDDG_DXZDGYZ = BSSN_DXZ_2(ADM_BS_gyz,i,j,k)
        BSDDG_DYZDGYZ = BSSN_DYZ_2(ADM_BS_gyz,i,j,k)
      else
        BSDDG_DXXDGXX = BSSN_DXX_4(ADM_BS_gxx,i,j,k)
        BSDDG_DYYDGXX = BSSN_DYY_4(ADM_BS_gxx,i,j,k)
        BSDDG_DZZDGXX = BSSN_DZZ_4(ADM_BS_gxx,i,j,k)
        BSDDG_DXYDGXX = BSSN_DXY_4(ADM_BS_gxx,i,j,k)
        BSDDG_DXZDGXX = BSSN_DXZ_4(ADM_BS_gxx,i,j,k)
        BSDDG_DYZDGXX = BSSN_DYZ_4(ADM_BS_gxx,i,j,k)

        BSDDG_DXXDGYY = BSSN_DXX_4(ADM_BS_gyy,i,j,k)
        BSDDG_DYYDGYY = BSSN_DYY_4(ADM_BS_gyy,i,j,k)
        BSDDG_DZZDGYY = BSSN_DZZ_4(ADM_BS_gyy,i,j,k)
        BSDDG_DXYDGYY = BSSN_DXY_4(ADM_BS_gyy,i,j,k)
        BSDDG_DXZDGYY = BSSN_DXZ_4(ADM_BS_gyy,i,j,k)
        BSDDG_DYZDGYY = BSSN_DYZ_4(ADM_BS_gyy,i,j,k)

        BSDDG_DXXDGZZ = BSSN_DXX_4(ADM_BS_gzz,i,j,k)
        BSDDG_DYYDGZZ = BSSN_DYY_4(ADM_BS_gzz,i,j,k)
        BSDDG_DZZDGZZ = BSSN_DZZ_4(ADM_BS_gzz,i,j,k)
        BSDDG_DXYDGZZ = BSSN_DXY_4(ADM_BS_gzz,i,j,k)
        BSDDG_DXZDGZZ = BSSN_DXZ_4(ADM_BS_gzz,i,j,k)
        BSDDG_DYZDGZZ = BSSN_DYZ_4(ADM_BS_gzz,i,j,k)

        BSDDG_DXXDGXY = BSSN_DXX_4(ADM_BS_gxy,i,j,k)
        BSDDG_DYYDGXY = BSSN_DYY_4(ADM_BS_gxy,i,j,k)
        BSDDG_DZZDGXY = BSSN_DZZ_4(ADM_BS_gxy,i,j,k)
        BSDDG_DXYDGXY = BSSN_DXY_4(ADM_BS_gxy,i,j,k)
        BSDDG_DXZDGXY = BSSN_DXZ_4(ADM_BS_gxy,i,j,k)
        BSDDG_DYZDGXY = BSSN_DYZ_4(ADM_BS_gxy,i,j,k)

        BSDDG_DXXDGXZ = BSSN_DXX_4(ADM_BS_gxz,i,j,k)
        BSDDG_DYYDGXZ = BSSN_DYY_4(ADM_BS_gxz,i,j,k)
        BSDDG_DZZDGXZ = BSSN_DZZ_4(ADM_BS_gxz,i,j,k)
        BSDDG_DXYDGXZ = BSSN_DXY_4(ADM_BS_gxz,i,j,k)
        BSDDG_DXZDGXZ = BSSN_DXZ_4(ADM_BS_gxz,i,j,k)
        BSDDG_DYZDGXZ = BSSN_DYZ_4(ADM_BS_gxz,i,j,k)

        BSDDG_DXXDGYZ = BSSN_DXX_4(ADM_BS_gyz,i,j,k)
        BSDDG_DYYDGYZ = BSSN_DYY_4(ADM_BS_gyz,i,j,k)
        BSDDG_DZZDGYZ = BSSN_DZZ_4(ADM_BS_gyz,i,j,k)
        BSDDG_DXYDGYZ = BSSN_DXY_4(ADM_BS_gyz,i,j,k)
        BSDDG_DXZDGYZ = BSSN_DXZ_4(ADM_BS_gyz,i,j,k)
        BSDDG_DYZDGYZ = BSSN_DYZ_4(ADM_BS_gyz,i,j,k)
      end if

#endif
