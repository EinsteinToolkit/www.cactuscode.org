/*@@
  @header   BSHYDRO_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the hydro quantities in the BS evolution
  scheme
  @enddesc
@@*/

#ifndef BSHYDRO_DECLARE
#define BSHYDRO_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/STRESSENERGY_declare.h"

#undef  BSHYDRO_RHO
#define BSHYDRO_RHO bshydro_rho

#undef  BSHYDRO_SX
#define BSHYDRO_SX bshydro_Sx
#undef  BSHYDRO_SY
#define BSHYDRO_SY bshydro_Sy
#undef  BSHYDRO_SZ
#define BSHYDRO_SZ bshydro_Sz

#undef  BSHYDRO_SXX
#define BSHYDRO_SXX bshydro_Sxx
#undef  BSHYDRO_SXY
#define BSHYDRO_SXY bshydro_Sxy
#undef  BSHYDRO_SXZ
#define BSHYDRO_SXZ bshydro_Sxz
#undef  BSHYDRO_SYY
#define BSHYDRO_SYY bshydro_Syy
#undef  BSHYDRO_SYZ
#define BSHYDRO_SYZ bshydro_Syz
#undef  BSHYDRO_SZZ
#define BSHYDRO_SZZ bshydro_Szz

#undef  BSHYDRO_PSIFAC
#define BSHYDRO_PSIFAC bshydro_psifac

#undef  BSHYDRO_IALP
#define BSHYDRO_IALP bshydro_ialp

/* Symmetries */

#undef  BSHYDRO_SYX
#define BSHYDRO_SYX bshydro_Sxy
#undef  BSHYDRO_SZX
#define BSHYDRO_SZX bshydro_Sxz
#undef  BSHYDRO_SZY
#define BSHYDRO_SZY bshydro_Syz

      CCTK_REAL BSHYDRO_RHO
      CCTK_REAL BSHYDRO_SX
      CCTK_REAL BSHYDRO_SY
      CCTK_REAL BSHYDRO_SZ
      CCTK_REAL BSHYDRO_SXX
      CCTK_REAL BSHYDRO_SXY
      CCTK_REAL BSHYDRO_SXZ
      CCTK_REAL BSHYDRO_SYY
      CCTK_REAL BSHYDRO_SYZ
      CCTK_REAL BSHYDRO_SZZ
      CCTK_REAL BSHYDRO_PSIFAC
      CCTK_REAL BSHYDRO_IALP

#endif
