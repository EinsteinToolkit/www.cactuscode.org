/*@@
  @header   CDCDK_undefine.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef CDCDK_GUTS
#undef CDCDK_DECLARE

#include "macro/DTRK_undefine.h"
#include "macro/DDK_undefine.h"
#include "macro/BSCHR2_undefine.h"


