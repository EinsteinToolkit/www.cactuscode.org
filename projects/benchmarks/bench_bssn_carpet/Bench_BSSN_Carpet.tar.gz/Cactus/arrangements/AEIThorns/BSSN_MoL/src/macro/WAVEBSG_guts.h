/*@@
  @header  WAVEBSG_guts.h
  @date    Nov 98
  @author  Gabrielle Allen
  @desc
  Macro to calculate wave operator acting on the BSmetric 

  That is BSg^lm BSg_ij,lm

  @enddesc
@@*/

#ifndef WAVEBSG_GUTS
#define WAVEBSG_GUTS

#include "macro/BSUPPERMET_guts.h"
#include "macro/BSDDG_guts.h"

      WAVEBSG_DDGXX = BSUPPERMET_UXX*BSDDG_DXXDGXX
     &              + BSUPPERMET_UYY*BSDDG_DYYDGXX
     &              + BSUPPERMET_UZZ*BSDDG_DZZDGXX
     &              +(BSUPPERMET_UYZ*BSDDG_DYZDGXX
     &              + BSUPPERMET_UXY*BSDDG_DXYDGXX
     &              + BSUPPERMET_UXZ*BSDDG_DXZDGXX)*2.0d0

      WAVEBSG_DDGYY = BSUPPERMET_UXX*BSDDG_DXXDGYY
     &              + BSUPPERMET_UYY*BSDDG_DYYDGYY
     &              + BSUPPERMET_UZZ*BSDDG_DZZDGYY
     &              +(BSUPPERMET_UYZ*BSDDG_DYZDGYY
     &              + BSUPPERMET_UXY*BSDDG_DXYDGYY
     &              + BSUPPERMET_UXZ*BSDDG_DXZDGYY)*2.0d0

      WAVEBSG_DDGZZ = BSUPPERMET_UXX*BSDDG_DXXDGZZ
     &              + BSUPPERMET_UYY*BSDDG_DYYDGZZ
     &              + BSUPPERMET_UZZ*BSDDG_DZZDGZZ
     &              +(BSUPPERMET_UYZ*BSDDG_DYZDGZZ
     &              + BSUPPERMET_UXY*BSDDG_DXYDGZZ
     &              + BSUPPERMET_UXZ*BSDDG_DXZDGZZ)*2.0d0

      WAVEBSG_DDGXY = BSUPPERMET_UXX*BSDDG_DXXDGXY
     &              + BSUPPERMET_UYY*BSDDG_DYYDGXY
     &              + BSUPPERMET_UZZ*BSDDG_DZZDGXY
     &              +(BSUPPERMET_UYZ*BSDDG_DYZDGXY
     &              + BSUPPERMET_UXY*BSDDG_DXYDGXY
     &              + BSUPPERMET_UXZ*BSDDG_DXZDGXY)*2.0d0

      WAVEBSG_DDGXZ = BSUPPERMET_UXX*BSDDG_DXXDGXZ
     &              + BSUPPERMET_UYY*BSDDG_DYYDGXZ
     &              + BSUPPERMET_UZZ*BSDDG_DZZDGXZ
     &              +(BSUPPERMET_UYZ*BSDDG_DYZDGXZ
     &              + BSUPPERMET_UXY*BSDDG_DXYDGXZ
     &              + BSUPPERMET_UXZ*BSDDG_DXZDGXZ)*2.0d0

      WAVEBSG_DDGYZ = BSUPPERMET_UXX*BSDDG_DXXDGYZ
     &              + BSUPPERMET_UYY*BSDDG_DYYDGYZ
     &              + BSUPPERMET_UZZ*BSDDG_DZZDGYZ
     &              +(BSUPPERMET_UYZ*BSDDG_DYZDGYZ
     &              + BSUPPERMET_UXY*BSDDG_DXYDGYZ
     &              + BSUPPERMET_UXZ*BSDDG_DXZDGYZ)*2.0d0

#endif

