/*@@
  @header   RICCIPHI_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro for the components of the "Ricci" tensor for the BS 
  variable phi. Eq. 20 of the BS paper.
  @enddesc
@@*/

#ifndef RICCIPHI_DECLARE
#define RICCIPHI_DECLARE

#include "CDCDPHI_declare.h"
#include "DPHI_declare.h"
#include "NABPHI_declare.h"
#include "BSUPPERMET_declare.h"

/* Input variables */
#ifdef OPT

#undef  RICCIPHI_GXX
#define RICCIPHI_GXX lg(XX,i,j,kc)
#undef  RICCIPHI_GXY
#define RICCIPHI_GXY lg(XY,i,j,kc)
#undef  RICCIPHI_GXZ
#define RICCIPHI_GXZ lg(XZ,i,j,kc)
#undef  RICCIPHI_GYY
#define RICCIPHI_GYY lg(YY,i,j,kc)
#undef  RICCIPHI_GYZ
#define RICCIPHI_GYZ lg(YZ,i,j,kc)
#undef  RICCIPHI_GZZ
#define RICCIPHI_GZZ lg(ZZ,i,j,kc)

#else

#undef  RICCIPHI_GXX
#define RICCIPHI_GXX ADM_BS_gxx(i,j,k)
#undef  RICCIPHI_GXY
#define RICCIPHI_GXY ADM_BS_gxy(i,j,k)
#undef  RICCIPHI_GXZ
#define RICCIPHI_GXZ ADM_BS_gxz(i,j,k)
#undef  RICCIPHI_GYY
#define RICCIPHI_GYY ADM_BS_gyy(i,j,k)
#undef  RICCIPHI_GYZ
#define RICCIPHI_GYZ ADM_BS_gyz(i,j,k)
#undef  RICCIPHI_GZZ
#define RICCIPHI_GZZ ADM_BS_gzz(i,j,k)

#endif

/* Internal variables */
#undef  RICCIPHI_TEMP 
#define RICCIPHI_TEMP ricciphi_temp

      CCTK_REAL ricciphi_temp

/* Output variables */
#undef  RICCIPHI_RXX
#define RICCIPHI_RXX RicciPhi_Rxx
#undef  RICCIPHI_RXY
#define RICCIPHI_RXY RicciPhi_Rxy
#undef  RICCIPHI_RXZ
#define RICCIPHI_RXZ RicciPhi_Rxz
#undef  RICCIPHI_RYY
#define RICCIPHI_RYY RicciPhi_Ryy
#undef  RICCIPHI_RYZ
#define RICCIPHI_RYZ RicciPhi_Ryz
#undef  RICCIPHI_RZZ
#define RICCIPHI_RZZ RicciPhi_Rzz

      CCTK_REAL RICCIPHI_RXX
      CCTK_REAL RICCIPHI_RXY
      CCTK_REAL RICCIPHI_RXZ
      CCTK_REAL RICCIPHI_RYY
      CCTK_REAL RICCIPHI_RYZ
      CCTK_REAL RICCIPHI_RZZ

#endif
