/*@@
  @header   BSSTF_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the tracefree part of the BS matter
  variable S_ij using

    tracefree S_ij = S_ij - g_ij S / 3
 
  @enddesc
@@*/

#ifndef BSSTF_GUTS
#define BSSTF_GUTS

#include "BSHYDRO_guts.h"
#include "BSTRS_guts.h"

      BSSTF_PHIFAC = exp(4D0*ADM_BS_phi(i,j,k))

      IF (conformal_state == 0) THEN
         BSSTF_PSIFAC = 1.0d0
      ELSE
         BSSTF_PSIFAC = psi(i,j,k)**4
      ENDIF

      BSSTF_TEMP = third*BSSTF_PSIFAC*BSSTF_PHIFAC*BSTRS_TRS

#ifdef OPT
      BSSTF_SXX = BSHYDRO_SXX - lg(XX,i,j,kc)*BSSTF_TEMP
      BSSTF_SXY = BSHYDRO_SXY - lg(XY,i,j,kc)*BSSTF_TEMP
      BSSTF_SXZ = BSHYDRO_SXZ - lg(XZ,i,j,kc)*BSSTF_TEMP
      BSSTF_SYY = BSHYDRO_SYY - lg(YY,i,j,kc)*BSSTF_TEMP
      BSSTF_SYZ = BSHYDRO_SYZ - lg(YZ,i,j,kc)*BSSTF_TEMP
      BSSTF_SZZ = BSHYDRO_SZZ - lg(ZZ,i,j,kc)*BSSTF_TEMP
#else
      BSSTF_SXX = BSHYDRO_SXX - ADM_BS_gxx(i,j,k)*BSSTF_TEMP
      BSSTF_SXY = BSHYDRO_SXY - ADM_BS_gxy(i,j,k)*BSSTF_TEMP
      BSSTF_SXZ = BSHYDRO_SXZ - ADM_BS_gxz(i,j,k)*BSSTF_TEMP
      BSSTF_SYY = BSHYDRO_SYY - ADM_BS_gyy(i,j,k)*BSSTF_TEMP
      BSSTF_SYZ = BSHYDRO_SYZ - ADM_BS_gyz(i,j,k)*BSSTF_TEMP
      BSSTF_SZZ = BSHYDRO_SZZ - ADM_BS_gzz(i,j,k)*BSSTF_TEMP
#endif

#endif
