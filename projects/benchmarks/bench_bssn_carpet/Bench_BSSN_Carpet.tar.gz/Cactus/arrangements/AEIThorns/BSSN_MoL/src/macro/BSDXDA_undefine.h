/*@@
  @header   BSDXDA_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef BSDXDA_GUTS
#undef BSDXDA_DECLARE


