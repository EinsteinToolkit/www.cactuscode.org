/*@@
  @header   BSUPPERMET_declare.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to the components of upper BS metric

  @enddesc
@@*/

#ifndef BSUPPERMET_DECLARE
#define BSUPPERMET_DECLARE

#include "macro/BSDETG_declare.h"

#ifdef FCODE

/* Internal variables */

#undef  BSUPPERMET_TEMP
#define BSUPPERMET_TEMP bsuppermet_temp

      CCTK_REAL BSUPPERMET_TEMP


/* Output variables */

#undef  BSUPPERMET_UXX
#define BSUPPERMET_UXX bsuppermet_uxx
#undef  BSUPPERMET_UXY
#define BSUPPERMET_UXY bsuppermet_uxy
#undef  BSUPPERMET_UXZ
#define BSUPPERMET_UXZ bsuppermet_uxz
#undef  BSUPPERMET_UYY
#define BSUPPERMET_UYY bsuppermet_uyy
#undef  BSUPPERMET_UYZ
#define BSUPPERMET_UYZ bsuppermet_uyz
#undef  BSUPPERMET_UZZ
#define BSUPPERMET_UZZ bsuppermet_uzz

      CCTK_REAL BSUPPERMET_UXX, BSUPPERMET_UXY, BSUPPERMET_UXZ
      CCTK_REAL BSUPPERMET_UYY, BSUPPERMET_UYZ, BSUPPERMET_UZZ

#endif


#ifdef CCODE

/* Output variables */
#undef  BSUPPERMET_UXX
#define BSUPPERMET_UXX bsuppermet_uxx
#undef  BSUPPERMET_UXY
#define BSUPPERMET_UXY bsuppermet_uxy
#undef  BSUPPERMET_UXZ
#define BSUPPERMET_UXZ bsuppermet_uxz
#undef  BSUPPERMET_UYY
#define BSUPPERMET_UYY bsuppermet_uyy
#undef  BSUPPERMET_UYZ
#define BSUPPERMET_UYZ bsuppermet_uyz
#undef  BSUPPERMET_UZZ
#define BSUPPERMET_UZZ bsuppermet_uzz

/* Declare output variables */
CCTK_REAL BSUPPERMET_UXX;
CCTK_REAL BSUPPERMET_UXY;
CCTK_REAL BSUPPERMET_UXZ;
CCTK_REAL BSUPPERMET_UYY;
CCTK_REAL BSUPPERMET_UYZ;
CCTK_REAL BSUPPERMET_UZZ;

#endif

/* Symmetries */
#undef  BSUPPERMET_UYX
#define BSUPPERMET_UYX BSUPPERMET_UXY
#undef  BSUPPERMET_UZX
#define BSUPPERMET_UZX BSUPPERMET_UXZ
#undef  BSUPPERMET_UZY
#define BSUPPERMET_UZY BSUPPERMET_UYZ

#endif



