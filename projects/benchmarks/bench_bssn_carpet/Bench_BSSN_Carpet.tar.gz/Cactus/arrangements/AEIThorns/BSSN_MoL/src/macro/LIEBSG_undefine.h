/*@@
  @header   LIEBSG_undefine.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef LIEBSG_GUTS
#undef LIEBSG_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_undefine.h"

