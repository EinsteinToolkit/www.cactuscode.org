/*@@
  @header   BSHYDRO_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  Macro to calculate the hydro quantities in the BS evolution
  scheme
  @enddesc
@@*/

#undef BSHYDRO_GUTS
#undef BSHYDRO_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/STRESSENERGY_undefine.h"
