/*@@
  @header   CDCDK_guts.h
  @date     Feb 99
  @author   Miguel Alcubierre
  @desc
  Macro to calculate all second covariant spatial derivative of K

  That is K_{;ij}

  @enddesc
@@*/

#ifndef CDCDK_GUTS
#define CDCDK_GUTS

#include "macro/DTRK_guts.h"
#include "macro/DDK_guts.h"
#include "macro/BSCHR2_guts.h"

      CDCDK_CDXXDK = (DDK_DXXDK-BSCHR2_XXX*DTRK_DXDTRK
     &             -BSCHR2_YXX*DTRK_DYDTRK-BSCHR2_ZXX*DTRK_DZDTRK)
      CDCDK_CDXYDK = (DDK_DXYDK-BSCHR2_XXY*DTRK_DXDTRK
     &             -BSCHR2_YXY*DTRK_DYDTRK-BSCHR2_ZXY*DTRK_DZDTRK)
      CDCDK_CDXZDK = (DDK_DXZDK-BSCHR2_XXZ*DTRK_DXDTRK
     &             -BSCHR2_YXZ*DTRK_DYDTRK-BSCHR2_ZXZ*DTRK_DZDTRK)
      CDCDK_CDYYDK = (DDK_DYYDK-BSCHR2_XYY*DTRK_DXDTRK
     &             -BSCHR2_YYY*DTRK_DYDTRK-BSCHR2_ZYY*DTRK_DZDTRK)
      CDCDK_CDYZDK = (DDK_DYZDK-BSCHR2_XYZ*DTRK_DXDTRK
     &             -BSCHR2_YYZ*DTRK_DYDTRK-BSCHR2_ZYZ*DTRK_DZDTRK)
      CDCDK_CDZZDK = (DDK_DZZDK-BSCHR2_XZZ*DTRK_DXDTRK
     &             -BSCHR2_YZZ*DTRK_DYDTRK-BSCHR2_ZZZ*DTRK_DZDTRK)

#endif

