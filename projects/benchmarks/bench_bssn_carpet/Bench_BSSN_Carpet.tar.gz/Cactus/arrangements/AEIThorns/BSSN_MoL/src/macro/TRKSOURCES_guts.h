/*@@
  @header   TRKSOURCES_guts.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
     Macro to calculate the combined vacuum and matter source terms
     for BS Eq. 15 for the evolution of the trace of the extrinsic
     curvature.
  @enddesc
@@*/

#ifndef TRKSOURCES_GUTS
#define TRKSOURCES_GUTS

#include "macro/BSHYDRO_guts.h"
#include "macro/BSTRS_guts.h"
#include "macro/TRAA_guts.h"
#include "macro/NABALPHA_guts.h"
#include "macro/BSRICSCAL_guts.h"


/* Do the matter source terms */
/* -------------------------- */

      TRKSOURCES_MATTER = fourpi*alp(i,j,k)*(BSHYDRO_RHO + BSTRS_TRS)

/* Do the vacuum source terms */
/* -------------------------- */

      TRKSOURCES_METRIC = - NABALPHA_NABALPHA_PHYS


      TRKSOURCES_METRIC = TRKSOURCES_METRIC
     &   + alp(i,j,k)*(TRAA_TRAA + third*ADM_BS_K(i,j,k)**2
     &   + Hcoeff*(BSRICSCAL_R - TRAA_TRAA - 2.0D0*eightpi*BSHYDRO_RHO
     &   + twothird*ADM_BS_K(i,j,k)**2))

/* Complete source term */
/* -------------------- */

      adm_bs_sK(i,j,k) = TRKSOURCES_METRIC + TRKSOURCES_MATTER

#endif

