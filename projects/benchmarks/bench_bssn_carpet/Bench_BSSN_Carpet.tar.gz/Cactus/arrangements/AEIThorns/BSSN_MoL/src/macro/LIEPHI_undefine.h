/*@@
  @header   LIEPHI_undefine.h
  @date     August 2001
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#undef LIEPHI_GUTS
#undef LIEPHI_DECLARE

#include "CactusEinstein/ADMMacros/src/macro/DB_undefine.h"

