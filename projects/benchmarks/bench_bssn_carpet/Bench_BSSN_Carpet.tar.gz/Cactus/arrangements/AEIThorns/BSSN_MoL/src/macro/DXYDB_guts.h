/*@@
  @header   DXYDB_guts.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DXYDB_GUTS
#define DXYDB_GUTS

#include "macro/BSSN_Derivative.h"

      if (local_spatial_order.eq.2) then
        DXYDB_DXYDBX = BSSN_DXY_2(betax,i,j,k)
        DXYDB_DXYDBY = BSSN_DXY_2(betay,i,j,k)
        DXYDB_DXYDBZ = BSSN_DXY_2(betaz,i,j,k)
      else
        DXYDB_DXYDBX = BSSN_DXY_4(betax,i,j,k)
        DXYDB_DXYDBY = BSSN_DXY_4(betay,i,j,k)
        DXYDB_DXYDBZ = BSSN_DXY_4(betaz,i,j,k)
      end if

#endif
