/*@@
  @header   DXYDB_declare.h
  @date     December 1999
  @author   Miguel Alcubierre
  @desc
  @enddesc
@@*/

#ifndef DXYDB_DECLARE
#define DXYDB_DECLARE

/* Input variables */

#undef  DXYDB_BX_IPJP
#define DXYDB_BX_IPJP   betax(i+1,j+1,k)
#undef  DXYDB_BY_IPJP
#define DXYDB_BY_IPJP   betay(i+1,j+1,k)
#undef  DXYDB_BZ_IPJP
#define DXYDB_BZ_IPJP   betaz(i+1,j+1,k)

#undef  DXYDB_BX_IPJM
#define DXYDB_BX_IPJM   betax(i+1,j-1,k)
#undef  DXYDB_BY_IPJM
#define DXYDB_BY_IPJM   betay(i+1,j-1,k)
#undef  DXYDB_BZ_IPJM
#define DXYDB_BZ_IPJM   betaz(i+1,j-1,k)

#undef  DXYDB_BX_IMJP
#define DXYDB_BX_IMJP   betax(i-1,j+1,k)
#undef  DXYDB_BY_IMJP
#define DXYDB_BY_IMJP   betay(i-1,j+1,k)
#undef  DXYDB_BZ_IMJP
#define DXYDB_BZ_IMJP   betaz(i-1,j+1,k)

#undef  DXYDB_BX_IMJM
#define DXYDB_BX_IMJM   betax(i-1,j-1,k)
#undef  DXYDB_BY_IMJM
#define DXYDB_BY_IMJM   betay(i-1,j-1,k)
#undef  DXYDB_BZ_IMJM
#define DXYDB_BZ_IMJM   betaz(i-1,j-1,k)


/* Internal variables */

#undef  DXYDB_TEMP
#define DXYDB_TEMP  dxydb_temp

/* Output variables */ 

#undef  DXYDB_DXYDBX
#define DXYDB_DXYDBX  dxydb_dxydbx
#undef  DXYDB_DXYDBY
#define DXYDB_DXYDBY  dxydb_dxydby
#undef  DXYDB_DXYDBZ
#define DXYDB_DXYDBZ  dxydb_dxydbz

/* Declare variables */

      CCTK_REAL DXYDB_TEMP
      CCTK_REAL DXYDB_DXYDBX
      CCTK_REAL DXYDB_DXYDBY
      CCTK_REAL DXYDB_DXYDBZ

#endif
