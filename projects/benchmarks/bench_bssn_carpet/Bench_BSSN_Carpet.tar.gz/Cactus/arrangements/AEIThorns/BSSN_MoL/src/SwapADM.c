/* SwapADM.c */
/* Bernd Bruegmann, 02/00 */
/* $Header: /numrelcvs/AEIThorns/BSSN_MoL/src/SwapADM.c,v 1.4 2003/12/23 11:32:19 schnetter Exp $ */

#include "cctk.h" 
#include "cctk_Arguments.h"

#define swap(a,b) tmp=a[i];a[i]=b[i];b[i]=tmp;

/* Prototypes */
void BSSN_MoL_SwapADM(CCTK_POINTER_TO_CONST GH);


/* swap metric and curvature between BSSN and ADM
   used by BAM_VecLap for conformal 3-harmonic ("Gamma freezing") shift
   put here because there are no conditional inherits in cactus 4
*/
void BSSN_MoL_SwapADM(CCTK_POINTER_TO_CONST GH)
{
  int i;
  CCTK_REAL tmp;
  const cGH *cctkGH = GH;
  DECLARE_CCTK_ARGUMENTS 

  int npoints;

  npoints = cctk_lsh[0]*cctk_lsh[1]*cctk_lsh[2];

  for (i = 0; i < npoints; i++) {
    swap(gxx, ADM_BS_gxx);
    swap(gxy, ADM_BS_gxy);
    swap(gxz, ADM_BS_gxz);
    swap(gyy, ADM_BS_gyy);
    swap(gyz, ADM_BS_gyz);
    swap(gzz, ADM_BS_gzz);
    swap(kxx, ADM_BS_Axx);
    swap(kxy, ADM_BS_Axy);
    swap(kxz, ADM_BS_Axz);
    swap(kyy, ADM_BS_Ayy);
    swap(kyz, ADM_BS_Ayz);
    swap(kzz, ADM_BS_Azz);
  }
}
