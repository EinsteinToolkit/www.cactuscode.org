/*@@
  @header   DETG_undefine.h
  @date     Nov 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DETG_DECLARE
#undef DETG_GUTS
