/*@@
  @header   DXZDG_undefine.h
  @date     Jun 98
  @author   Gabrielle Allen
  @desc
  @enddesc
@@*/

#undef DXZDG_GUTS

#include "DXDG_undefine.h"
#include "DZDG_undefine.h"
