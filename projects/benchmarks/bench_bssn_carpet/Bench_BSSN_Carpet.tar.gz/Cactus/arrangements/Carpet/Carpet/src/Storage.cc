#include <cassert>
#include <cstdlib>

#include "cctk.h"
#include "cctk_Parameters.h"

#include "dh.hh"
#include "gf.hh"
#include "operators.hh"

#include "carpet.hh"



namespace Carpet {
  
  using namespace std;
  
  
  
  static int
  GroupStorageCrease (const cGH* cgh, int n_groups, const int* groups,
                      const int* timelevels, int* status,
                      const bool inc);
  
  int
  GroupStorageCrease (const cGH* cgh, int n_groups, const int* groups,
                      const int* timelevels, int* status,
                      const bool inc)
  {
    DECLARE_CCTK_PARAMETERS;
    
    assert (cgh);
    assert (n_groups >= 0);
    assert (groups);
    assert (timelevels);
    for (int n=0; n<n_groups; ++n) {
      if (groups[n] < 0 or groups[n] >= CCTK_NumGroups()) {
        CCTK_VWarn (1, __LINE__, __FILE__, CCTK_THORNSTRING,
                    "Group index %d is illegal", groups[n]);
        return -1;
      }
      assert (groups[n] >= 0 and groups[n] < CCTK_NumGroups());
      // TODO: timelevels[n] can also be -1; in that case, all time
      // levels should be activated / deactivated
      assert (timelevels[n] >= 0);
    }
    
    bool const can_do = is_meta_mode() or is_global_mode() or is_level_mode();
    bool const all_ml = is_meta_mode();
    int const min_ml = all_ml ? 0        : mglevel;
    int const max_ml = all_ml ? mglevels : mglevel+1;
    
    int total_num_timelevels = 0;
    
    for (int n=0; n<n_groups; ++n) {
      int const group = groups[n];
      
      cGroup gp;
      const int ierr = CCTK_GroupData (group, &gp);
      assert (! ierr);
      
      bool const all_rl = is_meta_mode() or is_global_mode();
      bool const is_array = gp.grouptype != CCTK_GF;
      int const min_rl = is_array ? 0 : all_rl ? 0         : reflevel;
      int const max_rl = is_array ? 1 : all_rl ? reflevels : reflevel+1;
      
      int const firstvarindex = CCTK_FirstVarIndexI (group);
      assert (gp.numvars == 0
              or (firstvarindex >= 0 and firstvarindex < CCTK_NumVars()));
      
      // Check an assumption
      if (! gp.vectorgroup) assert (gp.vectorlength == 1);
      
      // Record previous number of allocated time levels
      if (status) {
        status[n] = groupdata.at(group).info.activetimelevels;
      }
      
      // Only do something if the number of time levels actually needs
      // to be changed -- do nothing otherwise

      const bool do_increase
        = inc and timelevels[n] > groupdata.at(group).info.activetimelevels;
      const bool do_decrease
        = ! inc and timelevels[n] < groupdata.at(group).info.activetimelevels;
      if (do_increase or do_decrease) {
        
        // No storage change in local mode
        if (gp.grouptype == CCTK_GF) {
          assert ((map == -1 or maps == 1)
                  and (component == -1
                       or vhh.at(0)->local_components(reflevel) == 1));
        }
        
        if (! can_do) {
          char * const groupname = CCTK_GroupName (group);
          char const * const modestring
            = (is_meta_mode() ? "meta"
               : is_global_mode() ? "global"
               : is_level_mode() ? "level"
               : is_singlemap_mode() ? "singlemap"
               : is_local_mode() ? "local"
               : NULL);
          CCTK_VWarn (0, __LINE__, __FILE__, CCTK_THORNSTRING,
                      "Cannot change storage for group \"%s\" in %s mode",
                      groupname, modestring);
          free (groupname);
        }
        assert (can_do);
        
        // Set the new number of active time levels
        groupdata.at(group).info.activetimelevels = timelevels[n];
        
        // Allocate the time levels as well
        for (int ml=min_ml; ml<max_ml; ++ml) {
          for (int rl=min_rl; rl<max_rl; ++rl) {
            for (int m=0; m<(int)arrdata.at(group).size(); ++m) {
              for (int var=0; var<gp.numvars; ++var) {
                const int vectorindex
                  = gp.vectorgroup ? var % gp.vectorlength : 0;
                const int vectorlength
                  = gp.vectorgroup ? gp.vectorlength : 1;
                assert (vectorindex>=0 and vectorindex<gp.numvars);
                assert (vectorlength>0 and vectorlength<=gp.numvars);
                ggf* const vectorleader
                  = (vectorindex>0
                     ? arrdata.at(group).at(m).data.at(var - vectorindex)
                     : NULL);
                const int varindex = firstvarindex + var;
#warning "TODO: allocate these in SetupGH, and after recomposing"
                if (! arrdata.at(group).at(m).data.at(var)) {
                  switch (gp.vartype) {
#define TYPECASE(N,T)                                                   \
                    case N:                                             \
                      arrdata.at(group).at(m).data.at(var) = new gf<T>  \
                      (varindex,                                        \
                       groupdata.at(group).transport_operator,          \
                       *arrdata.at(group).at(m).tt,                     \
                       *arrdata.at(group).at(m).dd,                     \
                       prolongation_order_time,                         \
                       vectorlength, vectorindex, (gf<T>*)vectorleader); \
                    break;
#include "typecase"
#undef TYPECASE
                  default:
                    UnsupportedVarType (varindex);
                  } // switch gp.vartype
                } // if ! allocated
              
                arrdata.at(group).at(m).data.at(var)->set_timelevels
                  (ml, rl, timelevels[n]);
              
                // Set the data pointers for grid arrays
                if (gp.grouptype != CCTK_GF) {
                  assert (rl==0 and m==0);
                  int const c = CCTK_MyProc(cgh);
                  for (int tl=0; tl<gp.numtimelevels; ++tl) {
                    cgh->data[varindex][tl]
                      = (tl < groupdata.at(group).info.activetimelevels
                         ? ((*arrdata.at(group).at(m).data.at(var))
                            (tl, 0, c, 0)->storage())
                         : NULL);
                  }
                } // if grouptype != GF
              
              } // for var
            } // for m
          } // for rl
        } // for ml
        
      } // if really change the number of active time levels
      
      // Complain if there are not enough active time levels
      if (gp.grouptype == CCTK_GF) {
        if (max_refinement_levels > 1) {
          if (groupdata.at(group).transport_operator != op_none
              and groupdata.at(group).transport_operator != op_copy) {
            if (groupdata.at(group).info.activetimelevels != 0
                and (groupdata.at(group).info.activetimelevels
                     < prolongation_order_time+1))
            {
              static vector<bool> didwarn;
              int const numgroups = CCTK_NumGroups();
              if (didwarn.size() < numgroups) {
                didwarn.resize (numgroups, false);
              }
              if (! didwarn.at(group)) {
                // Warn only once per group
                didwarn.at(group) = true;
                char * const groupname = CCTK_GroupName (group);
                CCTK_VWarn (1, __LINE__, __FILE__, CCTK_THORNSTRING,
                            "There are not enough time levels for the desired temporal prolongation order in the grid function group \"%s\".  With Carpet::prolongation_order_time=%d, you need at least %d time levels.",
                            groupname,
                            prolongation_order_time, prolongation_order_time+1);
                free (groupname);
              }
            }
          }
        }
      }
      
      // Record current number of time levels
      total_num_timelevels += groupdata.at(group).info.activetimelevels;
      
    } // for n
    
    return total_num_timelevels;
  }
  
  
  
  int
  GroupStorageIncrease (const cGH* cgh, int n_groups, const int* groups,
                        const int* timelevels, int* status)
  {
    Checkpoint ("GroupStorageIncrease");
    return
      GroupStorageCrease (cgh, n_groups, groups, timelevels, status, true);
  }
  
  
  
  int
  GroupStorageDecrease (const cGH* cgh, int n_groups, const int* groups,
                        const int* timelevels, int* status)
  {
    Checkpoint ("GroupStorageDecrease");
    return
      GroupStorageCrease (cgh, n_groups, groups, timelevels, status, false);
  }
  
  
  
  int
  EnableGroupStorage (const cGH* cgh, const char* groupname)
  {
    const int group = CCTK_GroupIndex(groupname);
    assert (group>=0 and group<CCTK_NumGroups());
    const int timelevels = CCTK_MaxTimeLevelsGI(group);
    int status;
    GroupStorageIncrease (cgh, 1, &group, &timelevels, &status);
    // Return whether storage was allocated previously
    return status;
  }
  
  
  
  int
  DisableGroupStorage (const cGH* cgh, const char* groupname)
  {
    const int group = CCTK_GroupIndex(groupname);
    assert (group>=0 and group<CCTK_NumGroups());
    const int timelevels = 0;
    int status;
    GroupStorageDecrease (cgh, 1, &group, &timelevels, &status);
    // Return whether storage was allocated previously
    return status;
  }
  
  
  
  int
  QueryGroupStorageB (const cGH* cgh, int group, const char* groupname)
  {
    if (groupname) {
      group = CCTK_GroupIndex(groupname);
    }
    assert (group>=0 and group<CCTK_NumGroups());
    // Return whether storage is allocated
    return groupdata.at(group).info.activetimelevels > 0;
  }
  
  
  
  const int*
  ArrayGroupSizeB (const cGH* cgh, int dir, int group, const char* groupname)
  {
    static const int zero = 0;
    static const int error = 0;
    
    if (groupname) {
      group = CCTK_GroupIndex(groupname);
    }
    assert (group>=0 and group<CCTK_NumGroups());
    
    if (mglevel == -1) {
      return &error;            // meta mode
    }
    
    const int gptype = CCTK_GroupTypeI (group);
    if (gptype == CCTK_GF and map == -1) {
      return &error;            // global or level mode for a GF
    }
    
    const int gpdim = groupdata.at(group).info.dim;
    assert (dir>=0 and dir<gpdim);
    
    if (CCTK_QueryGroupStorageI(cgh, group)) {
      
      return &groupdata.at(group).info.lsh[dir];
      
    } else {
      
      // no storage
      return &zero;
      
    }
  }
  
  
  
  int GroupDynamicData (const cGH* cgh, int group, cGroupDynamicData* data)
  {
    assert (group>=0 and group<CCTK_NumGroups());
    *data = groupdata.at(group).info;
    return 0;
  }
  
} // namespace Carpet
