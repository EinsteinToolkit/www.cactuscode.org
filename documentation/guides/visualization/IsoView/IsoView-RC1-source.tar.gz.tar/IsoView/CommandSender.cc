/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>

#include "CommandSender.hh"

#ifdef _CRAYMPP
#define OLD_STL_HEADER_FILES
#endif

#ifdef OLD_STL_HEADER_FILES
#include <algo.h>
#else
#include <algorithm>
#endif


/*
#ifndef WIN32
#include <algo.h>
#else
#include <algorithm>
#endif
*/

#ifdef DEBUG
#define DEBUGPRINT(x) x
#else
#define DEBUGPRINT(x) 
#endif

CommandSender::CommandSender(RawTCPport *Connection)
: connection(Connection), server(0)
{
#ifndef WIN32
  signal(SIGPIPE,SIG_IGN);
#endif
}

CommandSender::CommandSender(const char *hostname,int port, bool create_server_if_connect_fails)
:connection(0),server(0)
{
#ifndef WIN32
  signal(SIGPIPE,SIG_IGN);  
#endif
  printf("CommandSender::Connect(%s,%u)\n",hostname,port);
  connection = new RawTCPclient(hostname,port);
  printf("Tried connect\n");
  if(!connection->isAlive() && create_server_if_connect_fails)
  {
    printf("kill connection and begin Server\n");
    delete connection;
    connection = 0;
    server = new RawTCPserver(port);
    puts("began server");
    printf("server port=%u alive (%s)\n",server->getPortNum(),
		server->isValid()?"yes":"no");
    //server->setTCPnoDelay(); // nodelay before connect?
    connection = server->accept(); // wait for a connection
    printf("Accept completed");
    if(!connection->isAlive())
    {
      puts("CommandSender::Connection is not alive!!!");
    }
    //connection->setTCPnoDelay(); // do this to accepted client sockets?
  }
}

CommandSender::~CommandSender(){
  if(connection) delete connection;
  if(server) delete server;
}

int CommandSender::sendCommand(Command &cmd){
  // T3E pads data structures so we can't rely on stated size
  char buffer[64+64+64]; // so copy to intermediate buffer for send
  printf("sending command[%s][%s][%s]\n",cmd.operation,cmd.object,cmd.value);
  for(int i=0;i<64;i++) { 
    buffer[i]=cmd.operation[i];
    buffer[i+64]=cmd.object[i];
    buffer[i+128]=cmd.value[i];
  } 
  //puts("CommmandSender::sendCommand() start.");
  if(connection)
    return connection->write(buffer,64+64+64); // depend on TCP_NODELAY to set
  else {
    puts("CommandSender::Send failed");
    return 0; // failed
  }
}


