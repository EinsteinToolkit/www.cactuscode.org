/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#ifndef _NETWORK_SERVICES_H_
#define _NETWORK_SERVICES_H_

#include <Fl/Fl.H>
#include <FlexArrayTmpl.H> // because inconsistent compiler support for STL...
#include <RawTCP.hh>
#include "CommandSender.hh"
#include "DataReceiver.hh"

struct NetworkServices {
  CommandSender *command;
  DataReceiver *data;
  FlexArray<int> connectivity;
  FlexArray<float> vertices;
  int run; 	/* Have we made our first run yet */
  float *verts, *norms;
  int *tris;
  int numtris,numverts,numnorms;
  float range[2],value;
  int fixedrange;
  int command_timeout;
  int value_changed;
  NetworkServices(){
    command=0;
    data=0;
    range[0]=0.0; range[1]=1.0; value=0.0;
    fixedrange=0;
    command_timeout=0;
    value_changed=0;
  }
  int TryConnection(const char *host,int controlport,int dataport);
  int isConnected();
  // return -1 if no connection available
  // return 0 if no data arrived
  // return 1 if the drawing task should update itself
  //          with new data.
  int CheckNet(/* void *sourcewidget */);
  void IsoValueChange(double val, void *v);
};

#endif
