/*  IsoView2 Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include "Cmdln.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void Cmdln::setDefaults(){
  fixedrange=0;
  controlport=7050;
  dataport = 7051;
  strcpy(hostname,"localhost");
  range[0]=-1.0f; range[1]=1.0f;
  value=0.0;
}

void Cmdln::print(FILE *file){
  fprintf(file,"hostname(cport,dport): %s(%u:%u)\n",
	  hostname,controlport,dataport);
  fprintf(file,"iso(min,max,val):(%f,%f,%f)\n",
	  range[0],range[1],value);
}

Cmdln::Cmdln(){ setDefaults(); }

Cmdln::Cmdln(int argc,char *argv[]){ setDefaults(); parse(argc,argv);}

void Cmdln::parse(int argc,char *argv[]){
  int i;
  for(i=0;i<argc;i++){
    char *arg = argv[i];
    char *val = ((i+1)<argc)?argv[i+1]:0;
    if(!(*arg=='-')) continue;
    else arg++;
    switch(*arg){
    case 'h': // hostname
      if(val){ strcpy(hostname,val); i++; }
      break;
    case 'd': // dataport
      if(arg[1]=='p' && val){ dataport=atoi(val); i++;}
      break;
    case 'r': // datarange
      if(val){ 
	sscanf(val,"%f:%f",range+0,range+1);
	fixedrange=2;
      }
      break;
    case 'c': // controlport
      if(arg[1]=='p' && val){ controlport=atoi(val); i++;}
      break;
    case 'v': // value
      if(val) { value=atof(val); i++;}
      break;
    default: // unknown
      printf("Unknown option %s\n",arg);
      break;
    }
  }
}
