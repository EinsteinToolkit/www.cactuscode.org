/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf
    Copyright (C) 2004  Ian Wesley-Smith (iwsmith@cct.lsu.edu)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#ifndef GLVIEW_H
#define GLVIEW_H
//#include config.h
#include <FL/Fl.H>
// #include <vector.h> // STL Vector (hope I don't regret this)
// STL == instant regret
#if HAVE_GL
#  include <FL/Fl_Gl_Window.H>
#  include <FL/gl.h>
#else
#  include <FL/Fl_Box.H>
#endif /* HAVE_GL */

#include <stdlib.h>

#if HAVE_GL
class GLView : public Fl_Gl_Window {
#else
class GLView : public Fl_Box {
#endif /* HAVE_GL */
 public:
  // this value determines the scaling factor used to draw the cube.
  double size;
  int linenum,draw_image;;
  static GLView *currentview;
  GLuint texName[2]; // eventually nslices
  int texwidth,texheight;
  GLubyte *teximage;
  float move_x, move_y;
  int mousex,mousey,mousedown;
  float cx,lx,cy,ly;
  float sx,sy,rx,ry,tx,ty,tz,scale;
  float curquat[4],lastquat[4];
  int spinning;
  float *px,*py,*pz;
  float palpha;
  float r_val,g_val,b_val,a_val;
  GLenum render_method;
  int perspective;
  
  float *points;
  int *verts;
  float *normals;
  int npoints,nverts,nnormals;

  
  inline void setColor(float r,float g,float b,float a){
    if(r>=0.0) r_val=r;
    if(g>=0.0) g_val=g;
    if(b>=0.0) b_val=b;
    if(a>=0.0) a_val=a;
    //this->redraw();
  }
  inline void setRender(int points, int lines, int polys){
	if(points)
		render_method=GL_POINTS;
	if(lines)
		render_method=GL_LINES;
	if(polys)
		render_method=GL_TRIANGLES;
  }

  void setBounds(float min_ext[3],float max_ext[3]);
  void setPoints(int n,float *x,float *y,float *z){npoints=n;px=x;py=y;pz=z;}
  // set a new isosurface (currently must be done in foreground, but
  // if boxed with a mutex can be done in the background.
  void setSurface(int np,float *p,int nv,int *v,int nn,float *n);
  void motion(int x, int y, long W, long H);
  void quatRot(void); 
  void animate(void); // needs to be static to work
  GLView(int x,int y,int w,int h,const char *l=0);
  GLView(int x,int y);
  void Initialize();
  void reset_idle(void);
  /* Set the rotation about the vertical (y ) axis.
   *
   * This function is called by the horizontal roller in GLViewUI and the
   * initialize button in GLViewUI.
   */
  inline void p_alpha(float a){palpha=a;}
  inline void v_scale(float s) {size=s; this->reset_idle();}
  inline float v_scale() {return size;}
  void v_angle(float angle);
  // {vAng=angle; this->reset_idle();};
  
  // Return the rotation about the vertical (y ) axis.
  inline float v_angle(){return vAng;};
  
  /* Set the rotation about the horizontal (x ) axis.
   *
   * This function is called by the vertical roller in GLViewUI and the
   * initialize button in GLViewUI.
   */
  
  void h_angle(float angle);
  // {hAng=angle; this->reset_idle();};
  
  // the rotation about the horizontal (x ) axis.
  inline float h_angle(){return hAng;};
  
  /* Sets the x shift of the cube view camera.
   *
   * This function is called by the slider in GLViewUI and the
   * initialize button in GLViewUI.
   */
  inline void panx(float x){xshift=x; this->reset_idle();};
  /* Sets the y shift of the cube view camera.
   *
   * This function is called by the slider in GLViewUI and the
   * initialize button in GLViewUI.
   */
  inline void pany(float y){yshift=y; this->reset_idle();};
  virtual FL_EXPORT int handle(int event,int X,int Y,int W,int H);
  virtual FL_EXPORT int handle(int event){
    return this->handle(event,x(),y(),w(),h());
  }
#if HAVE_GL
  /*The widget class draw() override.
   *
   *The draw() function initialize Gl for another round o f drawing
   * then calls specialized functions for drawing each of the
   * entities displayed in the cube view.
   *
   */
  void draw();
  void fl_draw_image(const uchar*, int,int,int,int, int delta=3, int ldelta=0);
#endif /* HAVE_GL */
  int idle();
 private:
  
  /*  Draw the cube boundaries
   *
   *Draw the faces of the cube using the boxv[] vertices, using
   * GL_LINE_LOOP for the faces. The color is \#defined by CUBECOLOR.
   */
#if HAVE_GL
  void drawCube();
#else
  void drawCube() { }
#endif /* HAVE_GL */
  
  float vAng,hAng;
  float rot[4][4];
  float xshift,yshift;
  
  
  float boxv0[3];float boxv1[3];
  float boxv2[3];float boxv3[3];
  float boxv4[3];float boxv5[3];
  float boxv6[3];float boxv7[3];
  
};
#endif

