/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdio.h>
#include "NetworkServices.h"
#include "IsoViewUI.h"

#ifndef False
#define False 0
#endif

int NetworkServices::TryConnection(const char *hostname,int controlport,int dataport)
{
	if(command) delete command;
	if(data) delete data;
	command = new CommandSender(hostname,controlport,False);
	data    = new DataReceiver(hostname,dataport);
	if(!isConnected())
	{
		fprintf(stderr,"Connection Attempt failed:  Host=[%s] controlport=%u dataport=%u\n",hostname,controlport,dataport);
		if(command) delete command; command=0;
		if(data) delete data; data=0;
		return 0;
	}else 
		return 1;
}

int NetworkServices::isConnected()
{
	if(!command || !data || !data->isConnected() || !command->isConnected()) 
		return 0;
	else 
		return 1;
}

int NetworkServices::CheckNet()
{
	DataType::Type datatype;
	int nelem;
	char name[128];
	if(!this->isConnected()) return -1;
	void *data = this->data->receiveData(name,nelem,datatype);
	// Should have *name=='n' for normals
	// and *name=='r' for the range so that
	// ranging information can be sent regardless of
	// the isosurface level.
	// perhaps *name='h' for histogram data
	if(*name=='v')
  	{
  		this->verts= (float*)data;
		this->numverts=nelem/3;
		//if(this->fixedrange<2)
		//{
			float v,minv,maxv;
			/* parse range and value and re-range */
			char *s=strchr(name,'=');
			fprintf(stderr, "Name=[%s]\n",name);
			sscanf(s+1,"%f",&v);
			s=strchr(s+1,'=');
			sscanf(s+1,"%f:%f",&minv,&maxv);
			if(this->fixedrange==0)
			{
				this->value=v;
				this->range[0]=minv;
				this->range[1]=maxv;
				this->fixedrange=1;
  	    	}else 
	   	   	{
				if(minv<this->range[0]) this->range[0]=minv;
				if(maxv>this->range[1]) this->range[1]=maxv;
				// If we haven't just changed it ourselves, pickup the new value.
				if(!this->command_timeout && this->value != v) 
				{
					this->value=v;
					this->value_changed = 1;
				}
			//}
		}
	}else if(*name=='c')
	{     
		this->tris = (int*)data;
		this->numtris = nelem/3;
	}else if(*name=='n')
	{
		this->norms=(float*)data;
		this->numnorms=nelem/3;
	}
	return 1; // should be -1=error, 0=nothing changed, 1=updated
}

void NetworkServices::IsoValueChange(double val, void *v)
{
	if(!this->command || !this->command->isConnected())
	{
		fprintf(stderr, "No Command Interface!!!!!!!!!!\n");
		return;
	}
	if(this->fixedrange==0)
	{ 
  		fprintf(stderr, "Range data has not been recieved yet\n");
    	return; // has not received data for autoranging yet
	}
	// hardcode for now
	/* val*=1.8; */
	fprintf(stderr, "New Isovalue= %lf\n",val);
	char sval[64];
	sprintf(sval,"%lg",val);
	Command cmd("isosurf","wavetoy::phi[0]",sval);
	this->command->sendCommand(cmd);
	// Set a timeout so know it has just been changed.
	this->command_timeout = 2;
}

