/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <errno.h>

#include "DataReceiver.hh"

/*
#undef	VERBOSE
#define VERBOSE
*/

#undef	VERBOSE

// **************DataReceiver******************************

DataReceiver::DataReceiver(const char *hostname,int port)
: data(0),nbytes(0),rcvd(0),
  connection(0),server(0),mode(RCV_START)
{
    connection=new RawTCPclient(hostname,port);
    //if(!connection->isAlive()){
      //delete connection;
      //connection=0;
      //  server = new RawTCPserver(port);
      // connection = server->accept(); // wait for a connection
    //}
    if(connection->isAlive())
      mux.addInport(connection);
}

DataReceiver::DataReceiver(const char *hostname,int port,int windowsize)
: data(0),nbytes(0),rcvd(0),
  connection(0),server(0),mode(RCV_START)
{
    printf("DataReceiver:: opening(%s,%u) window=%u\n",hostname,port,windowsize);
    connection=new FastTCPclient(hostname,port,windowsize);
    //if(!connection->isAlive()){
    //delete connection;
    //connection=0;
    //server = new FastTCPserver(port,windowsize);
    //connection = server->accept(); // wait for a connection
    //if(!connection->isAlive())
    //printf("DataReceiver::Connection is NOT ALIVE!!!!\n");
    //}
    if(connection->isAlive())
      mux.addInport(connection);
}


DataReceiver::DataReceiver(RawTCPport*Connection)
: data(0),nbytes(0),rcvd(0),
  connection(Connection),server(0),mode(RCV_START)
{
    mux.addInport(connection);
}


DataReceiver::~DataReceiver()
{
	puts("delete DataReceiver"); 
	if(connection)
	{
		delete connection; 
		connection=0;
	} 
	if(server) 
	{
		delete server; 
		server=0;
	} 
}

/*
int DataReceiver::receiveDataHdr(char *name,int &nelements,DataType::Type &datatype){
  int recvd;
  // see if any data is availible on the connection
  // The select appears to be taking too long
  //if(mux.select()!=connection) return 0;
  if(!mux.poll()) return 0; // nothing coming in on this socket
  switch(mode){
  case RCV_START:
    mode=RCV_SIZE;
    rcvd=0;
    rcount=0; 
    delete data; 
    data=0; 
  case RCV_SIZE:
    recvd=connection->read(sizebuf+rcvd,8-rcvd);
    if(recvd<0){
      printf("DataReceiver::  socket returned Error on RecvSize\n");
      break;
    }
    if(!recvd) break;
    rcvd+=recvd;
    rcount++;
    if(rcvd>=8){
      mode=RCV_TYPE;
      rcvd=0;
#ifdef	VERBOSE
		printf("got size is %u recvs\n",rcount);
#endif
      rcount=0;
    }
    else break; // haven't gotten everything yet
  case RCV_TYPE:
    recvd=connection->read(tbuf+rcvd,4-rcvd);
    if(recvd<0){
      printf("DataReceiver::  socket returned Error on RcvType\n");
      break;
    }
    if(!recvd) break;
    rcvd+=recvd;
    rcount++;
    if(rcvd>=4){
      mode=RCV_NAME;
      rcvd=0;
      nbytes=DataType::sizeOf(type)*size;
#ifdef	VERBOSE
      		printf("got type is %u recvs\n",rcount);
#endif
      rcount=0;
      // fallthrough to next
    }
    else break; // haven't gotten everything yet
  case RCV_NAME:
    recvd=connection->read(dataname+rcvd,64-rcvd);
    rcount++;
    if(recvd<0){
      perror("DataReceiver::  socket returned Error on RecvName\n");
      
      break;
    }
    if(!recvd) break;
    rcvd+=recvd;
    if(rcvd>=64){
      mode=RCV_DATA;
      rcvd=0;
#ifdef	VERBOSE
     		 printf("got name is %u recvs\n",rcount);
#endif
      rcount=0;
      datatype=DataType::int2type(type);
      nelements=size;
      strcpy(name,dataname);
      return size;
    }
  }
  return 0;
}
*/

/*
void *DataReceiver::receiveData(char *buffer,int bufsize){// for SC97
  int recvd;
  if(!mux.poll()) return 0;
  if(mode!=RCV_DATA){
    fprintf(stderr,"receiveData:: Incorrect receive mode... should be RCV_DATA... it is %u\n",mode);
    return 0;
  }

  if(bufsize<nbytes) {
    fprintf(stderr,"receiveDat:: buffer size mismatch... expected %u got %u\n",
		int(nbytes), int(bufsize));
    return 0;
  }
  recvd=connection->read(buffer+rcvd,nbytes-rcvd);
  if(recvd<0){
    printf("DataReceiver::  socket returned Error on RecvData\n");
    return 0;
  }
  if(!recvd) return 0;
  rcvd+=recvd;
  rcount++;
  if(rcvd>=nbytes){
    mode=RCV_START;
    rcvd=0;
    //datatype=DataType::int2type(type);
    //nelements=size;
    //strcpy(name,dataname);
    printf("Received data in %u steps\n",rcount);
    rcount=0;
    return (void *)(buffer);
  }
  return 0;
}
*/

void *DataReceiver::receiveNewData(char *name,int &nelements,DataType::Type &datatype)
{
int	recvd; 
	  // see if any data is available on the connection 
	  // The select appears to be taking too long 

	*name = 0;
	if(!mux.poll()) return 0; 

	if (!connection)
	{
		puts("DataReceiver::receiveNewData(): Not connected.");
		return 0;
	}

	switch(mode)
	{
	case RCV_START:
		mode=RCV_SIZE;
		rcvd=0; 
		data=0; 
		rcount=0;
	case RCV_SIZE:
		recvd=connection->read(sizebuf+rcvd,8-rcvd); 
		if(recvd<0)
		{
			perror("(DataReceiver)  socket returned Error on RecvSize"); 
			break;
		} 
		if(!recvd) break; 
		rcvd+=recvd; 
		rcount++; 
		if(rcvd>=8)
		{
			mode=RCV_TYPE; 
			rcvd=0; 

			  /// correct for byteswapping 
			byteswap( sizebuf, 1, 8); 
			
#ifdef	VERBOSE 
			printf("got size (%lld) is %u recvs\n",size, rcount); 
			printf("--->     (%llx) \n",size); 
#endif 
			if (size<0)
			{
				printf("DataReceiver: Illegal input data - negative size count %ld!?\n"
				       "Closing connection.\n", (unsigned long) size); 
				delete connection; 
				connection = 0;
				mode = RCV_START; 
				return 0;
			}
			rcount=0;
		}
		else break; // haven't gotten everything yet

	case RCV_TYPE:
		recvd=connection->read(tbuf+rcvd,4-rcvd); 
		if(recvd<0)
		{
			perror("(DataReceiver)  socket returned Error on RcvType"); 
			break;
		} 
		if(!recvd) break; 
		rcvd+=recvd; 
		rcount++; 
		if(rcvd>=4)
		{
			mode=RCV_NAME; 
			rcvd=0; 

			  /// correct for byteswapping 
			byteswap( tbuf, 1, 4); 
			
#ifdef	VERBOSE 
			printf("got type (%d) is %u recvs\n",type, rcount); 
#endif 

			nbytes = sizeOf(type)*size; 
			rcount = 0; 

			if (data)
			{
				printf("Warning: (DataReceiver) internal error: data exists in place!"); 
				delete data;
			} 

			data = new char[nbytes]; 
#ifdef	VERBOSE
			printf("Allocated new receive buffer memory at %p, %ld bytes\n", data, nbytes);
#endif
		}
		else break; // haven't gotten everything yet

	case RCV_NAME:
		recvd=connection->read(dataname+rcvd,64-rcvd); 
		if(recvd<0)
		{
			perror("(DataReceiver)  socket returned Error on RecvName"); 
			break;
		} 
		if(!recvd) break; 
		rcvd+=recvd; 
		rcount++; 
		if(rcvd>=64)
		{
			mode=RCV_DATA; 
			rcvd=0; 
#ifdef	VERBOSE 
			printf("got name is %u recvs, now expecting %ld data elements (%ld bytes, %ld tripel) \n",
			       rcount, size, nbytes, size/3); 
			printf("name=%64s\n", dataname);
#endif 
			rcount=0;
		}
		else break; // haven't gotten everything yet

	case RCV_DATA:

		recvd=connection->read(data+rcvd,nbytes-rcvd); 
		if(recvd<0)
		{
			perror("(DataReceiver) Socket returned Error on RecvData"); 
			break;
		} 
		if(!recvd) break; 
		rcvd+=recvd; 
		rcount++; 
		if(rcvd>=nbytes)
		{
			mode=RCV_START; 
			rcvd=0; 
			datatype  = int2type(type); 
			nelements = size; 
			strcpy(name,dataname); 
			  // byteswap the data... 
			byteswap(data, nelements, sizeOf(datatype)); 
#ifdef	VERBOSE 
			printf("got data at %p is %u recvs (%ld bytes)\n",data, rcount, nbytes); 
			puts("DataReceiver::receiveData() end"); 
#endif 
			rcount=0; 
		char *  retval = data; 
			data = 0;       // clear for next receive 
			return retval;
		}
	} 
	  // puts("DataReceiver::receiveData() end"); 
	return 0;
}


/*
void *DataReceiver::receiveData(char *name,int &nelements,DataType::Type &datatype){
  int recvd;
  // see if any data is availible on the connection
  // The select appears to be taking too long
  if(!mux.poll()) return 0;
  switch(mode){
  case RCV_START:
    mode=RCV_SIZE;
    rcvd=0;
    data=0;
  case RCV_SIZE:
    recvd=connection->read(sizebuf+rcvd,8-rcvd);
    if(recvd<0){
      printf("DataReceiver::  socket returned Error on RecvSize\n");
      break;
    }
    if(!recvd) break;
    rcvd+=recvd;
    if(rcvd>=8){
      mode=RCV_TYPE;
      rcvd=0;
    }
    else break; // haven't gotten everything yet
  case RCV_TYPE:
    recvd=connection->read(tbuf+rcvd,4-rcvd);
    if(recvd<0){
      printf("DataReceiver::  socket returned Error on RcvType\n");
      break;
    }
    if(!recvd) break;
    rcvd+=recvd;
    if(rcvd>=4){
      mode=RCV_NAME;
      rcvd=0;
      nbytes=DataType::sizeOf(type)*size;
      //data=new char[nbytes];
      flexdata.setSize(nbytes);
    }
    else break; // haven't gotten everything yet
  case RCV_NAME:
    recvd=connection->read(dataname+rcvd,64-rcvd);
    if(recvd<0){
      printf("DataReceiver::  socket returned Error on RecvName\n");
      break;
    }
    if(!recvd) break;
    rcvd+=recvd;
    if(rcvd>=64){
      mode=RCV_DATA;
      rcvd=0;
    }
    else break; // haven't gotten everything yet
  case RCV_DATA:
    recvd=connection->read((flexdata.getData())+rcvd,nbytes-rcvd);
    if(recvd<0){
      printf("DataReceiver::  socket returned Error on RecvData\n");
      break;
    }
    if(!recv) break;
    rcvd+=recvd;
    if(rcvd>=nbytes){
      mode=RCV_START;
      rcvd=0;
      datatype=DataType::int2type(type);
      nelements=size;
      strcpy(name,dataname);
      return (void *)(flexdata.getData());
    }
  }
  return 0;
}
*/
