/*  IsoView2 - Visualization tool for CactusCode
    Some Portions Copyright (C) 2004  Ian Wesley-Smith (iwsmith@cct.lsu.edu)
    Copyright (C) 2004 John Shalf

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#ifndef __CMDLN_H_
#define __CMDLN_H_

#include <stdio.h>

struct Cmdln {
  int controlport,dataport;
  char hostname[128];
  float range[2],value;
  int fixedrange; /* 0=unranged, 1=autorange, 2=fixedrange */
  void setDefaults();
  void print(FILE *file=stdout);
  Cmdln();
  Cmdln(int argc,char *argv[]);
  void parse(int argc,char *argv[]);
};


#endif
