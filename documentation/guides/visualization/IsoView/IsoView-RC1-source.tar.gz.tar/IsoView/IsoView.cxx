/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf
    Some Portions Copyright (C) 2004  Ian Wesley-Smith (iwsmith@cct.lsu.edu)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#include <stdio.h>
#include <Fl/Fl.H>
#include "GLView.h"
#include "IsoViewUI.h"
#include "IsoView.h"
#include "Cmdln.h"

int main(int argc,char *argv[]){
  //Initial global objects.
  Cmdln cmdln(argc,argv);
  cmdln.print();
  NetworkServices net;
  net.numverts=0;
  net.verts=NULL;
  net.numtris=0;
  net.tris=NULL;
  net.run=0;
  IsoViewUI isoview(net);
  fprintf(stdout, "***********************************************************************\n");
  fprintf(stdout, "IsoView2 RC1, Copyright (C) 2004 John Shalf at Lawrence Berkeley National Laboratory\n");
  fprintf(stdout, "Some Portions Copyright (C) 2004 Ian Wesley-Smith <iwsmith(at)cct(dot)lsu(dot)edu>\n");
  fprintf(stdout, "IsoView2 comes with ABSOLUTELY NO WARRANTY; for details see COPYRIGHT\n");
  fprintf(stdout, "This is free software, and you are welcome to redistribute it under\n");
  fprintf(stdout, "certain conditions; type see COPYRIGHT for details.\n");
  fprintf(stdout, "***********************************************************************\n");
  isoview.show();
  if(cmdln.hostname)
    isoview.Host->value(cmdln.hostname);
  {
    char tmp[32]; 
    sprintf(tmp,"%u",cmdln.controlport);
    isoview.ControlPort->value(tmp);
    sprintf(tmp,"%u",cmdln.dataport);
    isoview.DataPort->value(tmp);
    net.TryConnection(cmdln.hostname,cmdln.controlport,cmdln.dataport);
  }
  isoview.setIsoRange(cmdln.range[0],cmdln.range[1]);
  return Fl::run();
}
