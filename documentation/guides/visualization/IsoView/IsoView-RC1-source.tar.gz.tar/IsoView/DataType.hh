/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */
#ifndef __RemoteIO_DATATYPE_HPP
#define __RemoteIO_DATATYPE_HPP

#ifdef WIN32
#include <stddef.h>
#endif

#include <sys/types.h>
/*
  NOTE: The #define's of the previous version did conflict
  with  /usr/include/X11/Xmd.h , so this had to be changed.
*/

#ifndef REMOTE_IO_UNITYPE
#define REMOTE_IO_UNITYPE
#define REMOTE_IO_BYTE 0
#define REMOTE_IO_INT8 0
#define REMOTE_IO_INT16 1
#define REMOTE_IO_INT32 2
#define REMOTE_IO_INT64 3
#define REMOTE_IO_FLOAT32 4
#define REMOTE_IO_FLOAT64 5
#define REMOTE_IO_UCHAR 6
#define REMOTE_IO_UINT8 6
#define REMOTE_IO_UINT16 7
#define REMOTE_IO_UINT32 8
#define REMOTE_IO_UINT64 9
/* special string types */
#define REMOTE_IO_CHAR 10
#define REMOTE_IO_CHAR8 10
#define REMOTE_IO_STRING 10
#define REMOTE_IO_UNICODE 11
#define REMOTE_IO_CHAR16 11
#endif

#if defined(T3E) || defined(_CRAYMPP)
typedef short Int32;
typedef int Int64;
#else
typedef int Int32;

#ifndef WIN32
typedef long long Int64;
#else
typedef long int Int64;
#endif

#endif

typedef float Float32;
typedef double Float64;


#ifdef WIN32
#include <RemoteIOWinDLLApi.h>
#endif

#if !( defined(linux) || defined(WIN32) )
#ifndef WORDS_BIGENDIAN
#define WORDS_BIGENDIAN
#endif
#endif


/// Common data type definitions and routines
struct DataType 
{
	  // it's not a good idea to name this enum's exactly the same
	  // as the global typedef's. This should be changed somewhen.
	/// Data protocol numbers
	enum Type 
	{
	 	Byte=0,Int8=0,Int16=1,Int32=2,Int64=3,
		Float32=4,Float64=5,
		uInt8=6,uChar=6,uInt16=7,uInt32=8,uInt64=9,
		Char=10,Char8=10,String=10,Unicode=11,Char16=11, // special string types
		Error=-1  
	};

	/// Convert datatype enum to int
static	inline int type2int(Type dt)
	{
		return static_cast<int>(dt);
	}

	/// Convert int to data type enum
static	inline Type int2type(int dt)
	{
		switch(dt)
		{
		case REMOTE_IO_FLOAT32:
			return Float32;
		case REMOTE_IO_FLOAT64:
			return Float64;
		case REMOTE_IO_INT32:
			return Int32;
		case REMOTE_IO_INT64:
			return Int64;
		case REMOTE_IO_INT8:
			return Int8;      
		case REMOTE_IO_INT16:
			return Int16;      
		default:
			return Error;      
		}
	}
	
	/// size of associated data type ID
static	inline size_t sizeOf(Type dt)
	{
		switch(dt)
		{
		case Float32:
			return 4;    
		case Float64:
			return 8;      
		case Int32:
			return 4;     
		case Int64:
			return 8;      
		case Int8:
			return 1;      
		case Int16:
			return 2;      
		default:
			return 0;  
		}
	}

	/// size of type associated with int data type number
static	size_t sizeOf(int dt)
	{
		switch(dt){
		case REMOTE_IO_FLOAT32:
		case REMOTE_IO_INT32:
			return 4;      
		case REMOTE_IO_FLOAT64:
		case REMOTE_IO_INT64:
			return 8;      
		case REMOTE_IO_INT8:
			return 1;      
		case REMOTE_IO_INT16:
			return 2;    
		default:
			return 0;      
		}
	}

	  /** Byteswap the buffer to big-endian. The provided buffer is
	      overwritten during this process, so when doing multicasting,
	      *don't* call this routine for every send! Otherwise every
	      second client will get the wrong byteorder!
<P>
As for byteswapping, John Shalf advocated choosing network-byte-order rather than
making the client & server negotiate the byte-order.  The reasons for this are
that
<UL>
<DD> 1) No modifications would be required to the existing protocol (the client &
     server don't need to know what each-other's byte order is)
<DD> 2) No modifications would be required to existing clients (thats a natural
consequence to #1).
<DD> 3) The server would not need to know what the byte-order of each of its
clients are.  Or likewise, the client wouldn't need to make its byteswapping
conditional on the byte-order of the server.  The only rule is that if you
are a little-endian machine, you swap bytes.
<DD> 4) It doesn't hurt performance since the amount of time required to swap
bytes is tiny compared to the time it takes to send a buffer over a network.
<DD> 5) It is easy to do.  The routines needed to do this are a standard part of
*all* unix socket implementations.  Thats because canonical network
byte-order has *always* been big-endian.
</UL>
<P>
The routine swaps the given buffer from/to BIG-ENDIAN byte order. It returns
true, if it did byte swapping, and false, if this was not required, i.e.
we actually are on a big-endian machine. It is safe to call the routine
on every platform, since it does required #ifdef's itself.
	  */
static bool byteswap(void *buf, ::Int64 nelements, int elementsize);
};

#endif // __RemoteIO_DATATYPE_HPP
