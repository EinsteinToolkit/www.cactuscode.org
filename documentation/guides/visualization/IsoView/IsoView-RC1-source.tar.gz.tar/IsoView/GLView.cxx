/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf 
    Copyright (C) 2004  Ian Wesley-Smith (iwsmith@cct.lsu.edu)
 
    This program is free software; you can redistribute it and/or modify 
    it under the terms of the GNU General Public License as published by 
    the Free Software Foundation; either version 2 of the License, or 
    (at your option) any later version. 
 
    This program is distributed in the hope that it will be useful, 
    but WITHOUT ANY WARRANTY; without even the implied warranty of 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
    GNU General Public License for more details. 
 
    You should have received a copy of the GNU General Public License 
    along with this program; if not, write to the Free Software 
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "GLView.h"

#include <FL/glut.H>
#ifdef __APPLE__
#include <OpenGL/glu.h> // added for fltk
#else
#include <GL/glu.h> // added for fltk
#endif

#include <FL/fl_draw.H>
#include "trackball.h"

GLView *GLView::currentview=0;

void GLView::setSurface(int np,float *p,int nv,int *v,int nn,float *n){
  // copy in the normals, verts and points
  //float *pold=points,*nold=normals;
  //int *vold = verts;
  // OK, should make this a protected region in the code
  // using a pthread mutex lock if it is multithreaded
  // first rev will single-thread the networking, but 
  // we are prepared...
  // This may still stall rendering of each frame in order
  // to acquire the mutex lock, so rev 2 multithreading 
  // should support a pthread_cond that wakes up a thread
  // to delete the old normals, verts, and points
  // and perform the swap.
  //
  // mutex or cond begin
  points=p; npoints=np;
  verts=v; nverts=nv;
  normals=p; nnormals=nn;
  //delete pold; delete vold; delete nold;
  // mutex or cond end
  // now we need to damage the window
  this->redraw();
}

void GLView::reset_idle(void){
	this->draw_image=0;
	//this->redraw();
}

void cube_idle(){
  if(!GLView::currentview || GLView::currentview->draw_image==0)
    Fl::set_idle(0); // that's enough idling damnit!
  //else
    //GLView::currentview->redraw();
}

void GLView::animate(void)
{
  if (spinning) {
    add_quats(lastquat, curquat, curquat);
  }
  else {
    glutIdleFunc(NULL);
  }
  //GLView::currentview->redraw();
}

void GLView::motion(int x, int y, long W, long H)
{
  // assume mouse is down
  if (mousex != x || mousey != y) {
    trackball(lastquat,
	      (2.0*mousex - W) / W,
	      (H - 2.0*mousey) / H,
	      (2.0*x - W) / W,
	      (H - 2.0*y) / H);
    add_quats(lastquat,curquat,curquat); // remove if spin mode enabled
    spinning = 1;
  } else {
    spinning = 0;
  }
  // Set idle function for animation here!  NULL or static animate
  mousex = x;
  mousey = y;
  //GLView::currentview->redraw();
}

void GLView::quatRot(){
  float m[4][4];
  build_rotmatrix(m,curquat);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glTranslatef(tx,ty,tz);
  glMultMatrixf(&(m[0][0]));
  glRotatef(180.0f,0.0f,0.0f,1.0f);
}

void GLView::v_angle(float angle){
  float newquat[4];
  float axis[3]={1.0,0.0,0.0};
  // printf("vAng=%f angle=%f delta=%f\n",vAng,angle,vAng-angle);
  axis_to_quat(axis,(vAng-angle)/180.0,lastquat);
  vAng=angle;
  add_quats(lastquat,curquat,newquat); // remove if spin mode enabled
  curquat[0]=newquat[0];
  curquat[1]=newquat[1];
  curquat[2]=newquat[2];
  curquat[3]=newquat[3];
  this->reset_idle();
}

void GLView::h_angle(float angle){
  float newquat[4];
  float axis[3]={0.0,1.0,0.0};
  axis_to_quat(axis,(hAng-angle)/180.0,lastquat);
  hAng=angle;
  add_quats(lastquat,curquat,newquat); // remove if spin mode enabled
  curquat[0]=newquat[0];
  curquat[1]=newquat[1];
  curquat[2]=newquat[2];
  curquat[3]=newquat[3];
  this->reset_idle();
}

int GLView::handle(int event,int X,int Y,int W,int H){
  double xf=0.0,yf=0.0,zf=0.0;
  float newquat[4];
  // printf("handling event=%d\t",event);
  /* p,d,r m %d,%d,%d,%d\n",event,
	 FL_PUSH,
	 FL_DRAG,
	 FL_RELEASE,
	 FL_MOVE); */
  // this->when(FL_WHEN_CHANGED);
  switch(event){
  case FL_PUSH:
    if (!Fl::event_inside(X, Y, W, H)) return 0;
    // puts("\tpush");
    //grab();
    this->take_focus();
    cx=lx=(float)(Fl::event_x());
    cy=ly=(float)(Fl::event_y());
    sx=sy=0.0;
    //printf("\tOnPush: sx,sx=%f,%f\tcx,cy=%f,%f\tlx,ly=%f,%f\n",
    //   sx,sy,cx,cy,lx,ly);
    //    break;
  case FL_DRAG:
    // case FL_MOVE:
    //puts("\tdrag");
    lx=cx;
    ly=cy;
    cx=(float)(Fl::event_x());
    cy=(float)(Fl::event_y());
    // scaled by window dimensions
    sx = (float)(2.0*(cx-lx))/(float)(w());
    sy = (float)(2.0*(cy-ly))/(float)(h());
    
    // printf("\tDrag: sx,sx=%f,%f\tcx,cy=%f,%f\tlx,ly=%f,%f\n",
    //   sx,sy,cx,cy,lx,ly);
    
    // now we decide what exactly to do with this
    if(Fl::event_state(FL_SHIFT)) {
      zf = sx + sy;
      xf = 0.0;
      yf = 0.0;
    } else {
      zf = 0.0;
      xf = sx;
      yf = sy;
    }

    // x is newpos and y is newpos (mousex is last?)
#if 0
    if(Fl::event_state(FL_CTRL)) {
      /* Scale down movements 10x */
      xf *= .1;  yf *= .1;  zf *= .1;
    }
#endif

   /* printf("*****Buttons=%d,%d,%d\n",
	    Fl::event_state(FL_BUTTON1),
	    Fl::event_state(FL_BUTTON2),
	    Fl::event_state(FL_BUTTON3)); */
	    
    if(Fl::event_state(FL_BUTTON1) && Fl::event_state(FL_CTRL) ||
       Fl::event_state(FL_BUTTON2)) {
      tx+=xf; ty-=yf; tz+=zf;
      //camera_rotate( CurrentCamera, xf, yf, zf );
      // printf("Panx=%f Pany=%f Panz(nil)=%f\n",tx,ty,tz);
      panx(tx);
      pany(ty);
      // panz(tz);
    } else if(Fl::event_state(FL_BUTTON1) && !Fl::event_state(FL_CTRL)) {
      float W=(float)(w()),H=(float)(h());
      trackball(lastquat,
		(2.0*lx - W) / W,
		(H - 2.0*ly) / H,
		(2.0*cx - W) / W,
		(H - 2.0*cy) / H);
      add_quats(lastquat,curquat,newquat); // remove if spin mode enabled
      curquat[0]=newquat[0];
      curquat[1]=newquat[1];
      curquat[2]=newquat[2];
      curquat[3]=newquat[3];
      // printf("Recompute quaternion and rotate\n");
      // camera_translate( CurrentCamera, xf, yf, zf );
    } else if(Fl::event_state(FL_BUTTON3)) {
      // camera_scale( CurrentCamera, -(xf + yf + zf) );
      scale+=yf;
      v_scale(scale);
    }
    // puts("Now redraw (do we reset state here?");
    //this->redraw();
    /* event change?  Is this kosher? */
    if(event==FL_PUSH){
      event=FL_DRAG;
    }
    // puts("what happens when changed?");
    set_changed();
    return 1;
    break;
  case FL_RELEASE:
    // puts("\trelease");
    //ungrab();
    // clear_changed();
    break;
  case FL_MOVE:
    // puts("\tmouseover move");
    //this->redraw();
    break;
  default:
    //  puts("\tunknown");
    return Fl_Gl_Window::handle(event);
    break;
  }
  // puts("\t\tnow make parent handle");
  //this->redraw();
  return Fl_Gl_Window::handle(event);
}

/* l[] is lowerbound and u[] is upper bound */
void GLView::setBounds(float l[3],float u[3]){
  boxv0[0] = l[0]; boxv0[1] = l[1]; boxv0[2] = l[2];
  boxv1[0] = u[0]; boxv1[1] = l[1]; boxv1[2] = l[2];
  boxv2[0] = u[0]; boxv2[1] = u[1]; boxv2[2] = l[2];
  boxv3[0] = l[0]; boxv3[1] = u[1]; boxv3[2] = l[2];
  boxv4[0] = l[0]; boxv4[1] = l[1]; boxv4[2] = u[2];
  boxv5[0] = u[0]; boxv5[1] = l[1]; boxv5[2] = u[2];
  boxv6[0] = u[0]; boxv6[1] = u[1]; boxv6[2] = u[2];
  boxv7[0] = l[0]; boxv7[1] = u[1]; boxv7[2] = u[2];
}
  
#if HAVE_GL
GLView::GLView(int x,int y,int w,int h,const char *l)
  : Fl_Gl_Window(x,y,w,h,l),points(0),verts(0),normals(0),npoints(0),nverts(0),nnormals(0){ this->Initialize(); this->end(); }
GLView::GLView(int x,int y)
  : Fl_Gl_Window(x,y),points(0),verts(0),normals(0),npoints(0),nverts(0),nnormals(0){ this->Initialize(); this->end(); }
#else
GLView::GLView(int x,int y,int w,int h,const char *l)
  : Fl_Box(x,y,w,h,l),draw_image(0),points(0),verts(0),normals(0),npoints(0),nverts(0),nnormals(0) { this->Initialize(); this->end(); }
GLView::GLView(int x,int y)
  : Fl_Box(x,y),draw_image(0),points(0),verts(0),normals(0),npoints(0),nverts(0),nnormals(0) { this->Initialize(); this->end(); }
#endif /* HAVE_GL */


void GLView::Initialize()
{
    vAng = 0.0;
    hAng=0.0;
    size=10.0;
    render_method=GL_TRIANGLES;
    r_val=g_val=b_val=a_val=1.0;
    trackball(curquat, 0.0, 0.0, 0.0, 0.0);
    spinning=0;
    move_x=move_y=0.0;
    mousex=mousey=0;
    px=py=pz=0;
    palpha=0.5;
    perspective=0;
    scale=size;
	/*
    GLfloat light_ambient[] = { 0.0, 0.0, 0.0, 1.0 };   
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_DEPTH_TEST);*/
    
    
    /* The cube definition. These are the vertices of a unit cube
     * centered on the origin.*/
    
    boxv0[0] = -0.5; boxv0[1] = -0.5; boxv0[2] = -0.5;
    boxv1[0] =  0.5; boxv1[1] = -0.5; boxv1[2] = -0.5;
    boxv2[0] =  0.5; boxv2[1] =  0.5; boxv2[2] = -0.5;
    boxv3[0] = -0.5; boxv3[1] =  0.5; boxv3[2] = -0.5;
    boxv4[0] = -0.5; boxv4[1] = -0.5; boxv4[2] =  0.5;
    boxv5[0] =  0.5; boxv5[1] = -0.5; boxv5[2] =  0.5;
    boxv6[0] =  0.5; boxv6[1] =  0.5; boxv6[2] =  0.5;
    boxv7[0] = -0.5; boxv7[1] =  0.5; boxv7[2] =  0.5;

    texwidth=64; texheight=64;
    teximage = new GLubyte[64*64*4];
    {
      int idx,i,j;
      for(j=0,idx=0;j<64;j++){
	for(i=0;i<64;i++){
	  // double sqrt(double);
	  double px,py,r;
	  px=(double)(i-32)/32.0;
	  py=(double)(j-32)/32.0;
	  r = sqrt(px*px+py*py);
	  
	  teximage[idx++]=(GLubyte)((px+0.5)*255.0);
	  teximage[idx++]=(GLubyte)(r*255.0);
	  teximage[idx++]=(GLubyte)((1.0-r)*255.0);
	  teximage[idx++]=255;
	}
      }
    }
    
#if !HAVE_GL
    label("OpenGL is required for this demo to operate.");
    align(FL_ALIGN_WRAP | FL_ALIGN_INSIDE);
#endif /* !HAVE_GL */
}

#if HAVE_GL
void GLView::drawCube() {
/* Draw a colored cube */
#define ALPHA 0.5

//    glShadeModel(GL_FLAT);
    glShadeModel(GL_SMOOTH);

   /* glBegin(GL_QUADS);
      glColor4f(0.0, 0.0, 1.0, ALPHA);
      glVertex3fv(boxv0);
      glVertex3fv(boxv1);
      glVertex3fv(boxv2);
      glVertex3fv(boxv3);

      glColor4f(1.0, 0.0, 0.0, ALPHA);
      glVertex3fv(boxv0);
      glVertex3fv(boxv4);
      glVertex3fv(boxv5);
      glVertex3fv(boxv1);

      glColor4f(0.0, 1.0, 0.0, ALPHA);
      glVertex3fv(boxv1);
      glVertex3fv(boxv5);
      glVertex3fv(boxv6);
      glVertex3fv(boxv2);
    glEnd();

    glColor3f(1.0, 1.0, 1.0);
    
    glColor3f(r_val,g_val,b_val); // KLUDGE (you can remove it)
    glBegin(GL_LINES);
      glVertex3fv(boxv0);
      glVertex3fv(boxv1);

      glVertex3fv(boxv1);
      glVertex3fv(boxv2);

      glVertex3fv(boxv2);
      glVertex3fv(boxv3);

      glVertex3fv(boxv3);
      glVertex3fv(boxv0);

      glVertex3fv(boxv4);
      glVertex3fv(boxv5);

      glVertex3fv(boxv5);
      glVertex3fv(boxv6);

      glVertex3fv(boxv6);
      glVertex3fv(boxv7);

      glVertex3fv(boxv7);
      glVertex3fv(boxv4);

      glVertex3fv(boxv0);
      glVertex3fv(boxv4);

      glVertex3fv(boxv1);
      glVertex3fv(boxv5);

      glVertex3fv(boxv2);
      glVertex3fv(boxv6);

      glVertex3fv(boxv3);
      glVertex3fv(boxv7);
    glEnd();*/
    //FILE *points, *verts;
    //points = fopen("/home/reverend/iwsmith/public/debug/points", "w");
    //verts = fopen("/home/reverend/iwsmith/public/debug/verts", "w");
    if (px) { printf("px: %f", px[0]); }
    if (py) { printf("py: %f", py[0]); }
    if (pz) { printf("pz: %f", pz[0]); }
    /*if(npoints>0 && px && py && pz ){
      register int i;
      //glColor4f(1.0,1.0,0.0,palpha);
      //glBegin(GL_POINTS);
	printf("Drawing Points:\n");
        for(i=0;i<npoints;i++){
         // glVertex3f(px[i],py[i],pz[i]);
          printf("points:%d,%f,%f,%f\n", i,px[i],py[i],pz[i]);
		}
      //glEnd();
    }
    else*/ if(npoints>0 && points && nverts>0){
      register int i; 
      register int tmpref;
      //float l;
      //float norms[4][3]={{0}};
      //float vectors[3][3];
      //zx=0;
      // should get surface color arguments
      glColor4f(r_val,g_val,b_val,a_val);
      //glColor4f(1.0, 0.0, 0.0, 0.50);
      //glBegin(GL_TRIANGLE_FAN);
      glBegin(render_method);
      //for(i=0;i<npoints*3;i+=3){
      //fprintf(stderr, "numpoints:%d\n", nverts);
      //fprintf(stderr, "numverts:%d\n", npoints);
      /*As confusing as this is, verts are really polys, polys are verts      */
      for(i=0;i<3*nverts;i++){
      	
      	//fprintf(stderr, "poly[%d]\n", i);
      	//fprintf(stderr,"polys[%d]%d \npolys[%d]%d \npolys[%d]%d\n", i,3*verts[i],i+1,3*verts[i]+1,i+2,3*verts[i]+2);
      	//fprintf(stderr, "x[%f]:y[%f]:z[%f]\n", points[verts[i]],points[verts[i]][1],points[verts[i]][2]);
      	tmpref=3*verts[i];
      	if(nnormals>0)
      		glNormal3f(normals[tmpref],normals[tmpref+1],normals[tmpref+2]);
      	glVertex3f(points[tmpref],points[tmpref+1],points[tmpref+2]);
      	/*norms[zx][0]=points[tmpref];
      	norms[zx][1]=points[tmpref+1];
      	norms[zx][2]=points[tmpref+2];
      	//norms[zx][3]=sqrt(norms[zx][0]*norms[zx][0]+norms[zx][1]*norms[zx][1]+norms[zx][2]*norms[zx][2]);
      	//norms[zx][0]=points[tmpref]/norms[zx][3];
      	//norms[zx][1]=points[tmpref+1]/norms[zx][3];
      	//norms[zx][2]=points[tmpref+2]/norms[zx][3];
      	if (zx>2)
      	{
			//Vector 1 - Should use a struct
			vectors[0][0]=norms[1][0]-norms[0][0];  //X
			vectors[0][1]=norms[1][1]-norms[0][1];  //Y
			vectors[0][2]=norms[1][2]-norms[0][2];  //Z
			l=sqrt(vectors[0][0]*vectors[0][0]+vectors[0][1]*vectors[0][1]+vectors[0][2]*vectors[0][2]);
			vectors[0][0]=vectors[0][0]/l;
			vectors[0][1]=vectors[0][1]/l;
			vectors[0][2]=vectors[0][2]/l;
			//Vector 2
			vectors[1][0]=norms[2][0]-norms[0][0];  //X
			vectors[1][1]=norms[2][1]-norms[0][1];  //Y
			vectors[1][2]=norms[2][2]-norms[0][2];  //Z
			l=sqrt(vectors[1][0]*vectors[1][0]+vectors[1][1]*vectors[1][1]+vectors[1][2]*vectors[1][2]);
			vectors[1][0]=vectors[1][0]/l;
			vectors[1][1]=vectors[1][1]/l;
			vectors[1][2]=vectors[1][2]/l;
			//Cross Product
			vectors[2][0]=vectors[0][1]*vectors[1][2]-vectors[0][2]*vectors[1][1];
			vectors[2][1]=vectors[0][2]*vectors[1][0]-vectors[0][0]*vectors[1][2];
			vectors[2][2]=vectors[0][0]*vectors[1][1]-vectors[0][1]*vectors[1][0];
			//fprintf(stderr, "%f - %f - %f\n", vectors[2][0], vectors[2][1], vectors[2][2]);							      
      		glNormal3f(vectors[2][0],vectors[2][1],vectors[2][2]);
      		glVertex3f(norms[0][0],norms[0][1],norms[0][2]);
      		glVertex3f(norms[1][0],norms[1][1],norms[1][2]);
      		glVertex3f(norms[2][0],norms[2][1],norms[2][2]);
      		zx=0;
      	}else
      	{
      		zx++;
      	}*/

        //glVertex3f(points[verts[i]],points[verts[i+1]],points[verts[i+2]]);
        //glVertex3f(points[3*verts[i]],points[3*verts[i]+1],points[3*verts[i]+2]);
	    //glNormal3fv(normals+i);
      }
      /*for(i=0;i<3*npoints;i+=3)
      {
      	glVertex3f(points[i],points[i+1],points[i+2]);
      }
      glEnd();
      glColor4f(0.0, 1.0, 0.0, 0.60);
      glBegin(GL_LINE_LOOP);
      for(i=0;i<3*npoints;i+=3)
      {
      	glVertex3f(points[i],points[i+1],points[i+2]);
      }
      glEnd();
      glColor4f(0.0, 0.0, 1.0, 1.0);
      glBegin(GL_POINTS);
      for(i=0;i<3*npoints;i+=3)
      {
      	glVertex3f(points[i],points[i+1],points[i+2]);
      }*/
      glEnd();
      /*points=NULL;
      verts=NULL;
      nverts=0;
      npoints=0;*/
    }
    //fclose(verts);
    //fclose(points);
    /* OK, now we draw particles */
    /*
#if 0
    glEnable(GL_TEXTURE_2D);
    //glEnable(GL_ALPHA_TEST);
    //glEnable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, texName[0]);

    glBegin(GL_QUADS);
        glColor4f(0.0, 0.7, 0.7, ALPHA);
        glTexCoord2f(0.0,0.0); 
	glVertex3f(-0.5,-0.5,0.0);
        glTexCoord2f(1.0,0.0); 
	glVertex3f( 0.5,-0.5,0.0);
        glTexCoord2f(1.0,1.0); 
	glVertex3f( 0.5, 0.5,0.0);
        glTexCoord2f(0.0,1.0); 
	glVertex3f(-0.5, 0.5,0.0);
    glEnd();
    glDisable(GL_TEXTURE_2D);
#endif
*/
} //drawCube

//void GLView::reset_idle(void){
 // /* acts as a reset of idle */
  //this->draw_image=0; // reset this
  //this->redraw();
// }

void GLView::draw() {
    if (!valid()) {
      //GLfloat light_ambient[] = { 0.0, 0.0, 0.0, 1.0 };
      //GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
      //GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
      

      double dh=(double)h();
      double dw=(double)w();
      glLoadIdentity();
	if(perspective){
	  glViewport(0,0,(GLsizei)w(),(GLsizei)h());
	  glMatrixMode(GL_PROJECTION);
	  //glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	  //glEnable(GL_LIGHTING);
	  //glEnable(GL_LIGHT0);
	  glLoadIdentity();
	  glFrustum(-1.0*dw/dh,1.0*dw/dh,-1.0,1.0,1.5,40.0);
	  glTranslatef(0.0,0.0,-12.0); /* move camera back some */
	  glMatrixMode(GL_MODELVIEW);
	}
	else{
	  // printf("h=%f\n",10.0*dw/dh);

  
	  
	  glViewport(0,0,(GLsizei)w(),(GLsizei)h());
	  glMatrixMode(GL_PROJECTION);
	  glLoadIdentity();
	  glOrtho(-6.0*dw/dh,6.0*dw/dh,-6.0,6.0,-1000.0,2000.0);
	  glMatrixMode(GL_MODELVIEW);
	}
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glClearColor(0.0,0.0,0.0,0.0);
	//glShadeModel(GL_FLAT);
	//	glEnable(GL_DEPTH_TEST);
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
	glGenTextures(1,texName);
	glBindTexture(GL_TEXTURE_2D,texName[0]);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,
			GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,
			GL_NEAREST);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 
		     texwidth, texheight,
		     0, GL_RGBA, GL_UNSIGNED_BYTE,
		     teximage);
	valid(1);
    }
		  glEnable(GL_NORMALIZE);
    //glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_COLOR_MATERIAL);
    GLfloat mat_specular[] = { 7.0, 7.0, 7.0, 1.0 };
    GLfloat mat_shininess[] = { 50.0 };
    GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light_position[] = { 0.0, 0.0, 5.0, 0.0 };
	GLfloat lmodel_ambient[] = { 0.5, 0.5, 0.5, 1.0 };
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_DEPTH_TEST);
    
    glPushMatrix();
    glMatrixMode(GL_MODELVIEW);
    // quatRot();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //printf("Draw Routine\n");
    // printf("\txshift,yshift=%f,%f\n",xshift,yshift);
    build_rotmatrix(rot,curquat);
    glLoadIdentity();
    glTranslatef(xshift, yshift, 0);
    // printf("\thang,vang=%f,%f\n",hAng,vAng);
    // glRotatef(hAng,0,1,0); glRotatef(vAng,1,0,0);
    glMultMatrixf(&(rot[0][0]));
    // printf("\tsize=%f\n",float(size));
    glScalef(float(size),float(size),float(size));
    /* must choose fb, bf based on current angle of rotation
       can have a decision ladder based on this) */
    
    /* GLView::currentview = this; */
    //GLfloat mat_amb_diff[] = { 0.1, 0.5, 0.8, 1.0 };
    //glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, 
    //        mat_amb_diff);
    //GLfloat light1_ambient[] = { 0.7, 0.7, 0.7, 1.0 };
	//GLfloat light1_diffuse[] = { .70, .70, .70, 1.0 };
	//GLfloat light1_specular[] = { 1.0, 1.0, 1.0, .70 };
	//GLfloat light1_position[] = { 4.0, 2.0, 4.0, 1.0 };
	//GLfloat spot_direction[] = { 0.0, 0.0, 2.0 };

	//glLightfv(GL_LIGHT1, GL_AMBIENT, light1_ambient);
	//glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
	//glLightfv(GL_LIGHT1, GL_SPECULAR, light1_specular);
	//glLightfv(GL_LIGHT1, GL_POSITION, light1_position);
	//glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.5);
	//glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.5);
	//glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.2);

	//glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 180.0);
	//glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spot_direction);
	//glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 1.0);

	

    //GLfloat light_ambient[] = { 0.75, 0.80, 0.78, 1.0 };
    //GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
    //GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    //GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
    //GLfloat mat_specular[] = { .70, .70, .70, .70 };
    //GLfloat mat_shininess[] = { 50.0 };
    //glColorMaterial(GL_FRONT, GL_DIFFUSE);
	//glEnable(GL_COLOR_MATERIAL);
    //glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    //glLightModelfv(GL_LIGHT_MODEL_AMBIENT, light_ambient);
//    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
//    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
//    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	//glEnable(GL_LIGHTING);
	//glEnable(GL_LIGHT0);
	//glEnable(GL_LIGHT1);
    //glDepthFunc(GL_LEQUAL);
    //glEnable(GL_DEPTH_TEST);   

    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

    //glLightfv(GL_LIGHT0, GL_DIFFUSE, light1_diffuse);


    drawCube();
    linenum=0;
    GLView::currentview=this;
    // draw_image=1;
    // Fl::set_idle(cube_idle);

    glPopMatrix();
    /*
      Then call the idle function for the redraw
    */
}


void GLView::fl_draw_image(const uchar* buf, int xx,int yy,
		   int ww,int hh, int delta, int ldelta){
  if(!visible()) return; 
  this->make_current();
  /* then draw the image into the visual */
  /* write out a row of pixels */
  
  glMatrixMode( GL_MODELVIEW );
  glPushMatrix();
  glLoadIdentity();
  glMatrixMode( GL_PROJECTION );
  glPushMatrix();
  glLoadIdentity();
  /* glRasterPos3f(0.0,0.0,-1.0); 
     printf("yy=%u y=%u hh=%u expr=%f\n",
     yy,y(),hh,
     -1.0 + (GLfloat)(yy - y()) / (GLfloat)hh);*/
  
  glRasterPos3f( -1.0 + 2.0*(GLfloat)(xx-x()) / (GLfloat)(w()),
                 -1.0 + 2.0*(GLfloat)(yy-y()) / (GLfloat)(h()),
		 -1.0 );
  /* glRasterPos3f((GLfloat)(xx),(GLfloat)(yy),-1.0); */
  /* glRasterPos3f(-1.0,-1.0,-1.0); */
   
  if(delta==3)
    glDrawPixels( ww, hh, GL_RGB, GL_UNSIGNED_BYTE, buf);
  else if(delta==4)
    glDrawPixels( ww, hh, GL_RGBA, GL_UNSIGNED_BYTE, buf);
  else if (delta==1)
    glDrawPixels( ww, hh, GL_LUMINANCE, GL_UNSIGNED_BYTE, buf);
 
  glMatrixMode( GL_PROJECTION );
  glPopMatrix();
  glMatrixMode( GL_MODELVIEW );
  glPopMatrix();  
}
#endif /* HAVE_GL */

int GLView::idle(){
  if(!this->visible() ) {
    return 0;
  }
  else return 1;
}
