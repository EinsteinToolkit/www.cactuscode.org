////////////////////////////////////////////
// $Id: Command.hpp,v 1.2 2004/10/20 21:02:15 iwsmith Exp $
// $Log: Command.hpp,v $
// Revision 1.2  2004/10/20 21:02:15  iwsmith
// Another Try at getting IsoView 2 in place....
//
// Revision 1.1.1.1  2004/10/06 22:30:26  iwsmith
// IsoView2: Now with OpenGL! (And VTK-Free!!)
//
// Revision 1.1  2000/08/25 00:53:36  jshalf
//
// Added a bunch of stuff for IsoView
// It still requires FLTK, Mesa 3.1, and VTK3.1
//
// Revision 1.3  1999/11/02 20:24:37  werner
// Parameters need to be const.
//
// Revision 1.2  1999/10/27 09:58:13  werner
// Less verbosity.
//
// Revision 1.1  1999/10/18 09:44:02  werner
// Remote IO Library
//
//
////////////////////////////////////////////
#ifndef __RemoteIO_COMMAND_HPP_
#define __RemoteIO_COMMAND_HPP_

#include <string.h>

/// Basic command structure, which is sent over the net
struct Command 
{
	/** Length of command members - warning: changing these values
	    will result in a change of the network protocol!
	 */
	enum { oplen = 64, objlen = 64, valuelen = 64 };

	char operation[oplen];
	char object[objlen];
	char value[valuelen]; // always text (simplifies things for now)
	  //int nbytes; // total length of the message... for async receives
	  //int nreceived;

	/// Constructor, initializes with zero strings
	Command()
	{
		operation[0] = 0;
		object[0]    = 0;
		value[0]     = 0;
	}

	/// Create a new command structure
	Command(const char *op, const char *obj, const char *val)
	{
		/// this is sloppy... should check for max. strlen of parameters...
		strcpy(operation,op); 
		strcpy(object,obj); 
		strcpy(value,val);
	}
};

#endif //  __RemoteIO_COMMAND_HPP_

