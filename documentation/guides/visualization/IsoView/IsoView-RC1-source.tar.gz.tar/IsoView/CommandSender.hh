/*  IsoView2 - Visualization tool for CactusCode
    Copyright (C) 2004 John Shalf

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */

#ifndef __RemoteIO_CommandSender_HPP
#define __RemoteIO_CommandSender_HPP

#include <RawTCP.hh>
#include "Command.hh"
#ifdef WIN32
#include "RemoteIOWinDLLApi.h"
#endif

/// Class handling sending of commands 
class CommandSender 
{
	RawTCPport *connection,*server;

public:
	/** Constructor: specify hostname, port number.
	    Tries to connect to a remote server, if that fails, becomes a server
	    itself and waits for connections. If under no circumstances the command sender
	    shall become a server (i.e. connection fails without blocking), then set
	    the last parameter to true.
	*/
	CommandSender(const char *hostname,int port, bool create_server_if_connect_fails=true);

	/// Create a CommandSender class from an existing connection.
	CommandSender(RawTCPport *connection);
	~CommandSender();

	/// return the TCP connection associated with this CommandSender
	RawTCPport *getConnection() { return connection; }

	/// Is the connection established?
	bool isConnected() const { return connection && connection->isAlive(); }

	/// Send a command to the remote site
	int sendCommand(Command &cmd);
};

#endif	 // RemoteIO_CommandSender_HPP
