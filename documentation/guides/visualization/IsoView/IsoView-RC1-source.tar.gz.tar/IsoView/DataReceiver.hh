/////////////////////////////////////////////////
// $Id: DataReceiver.hh,v 1.3 2004/10/20 21:02:15 iwsmith Exp $
// $Log: DataReceiver.hh,v $
// Revision 1.3  2004/10/20 21:02:15  iwsmith
// Another Try at getting IsoView 2 in place....
//
// Revision 1.1.1.1  2004/10/06 22:30:26  iwsmith
// IsoView2: Now with OpenGL! (And VTK-Free!!)
//
// Revision 1.2  2000/10/10 00:48:19  jshalf
//
// Fixed auto-ranging of the valuators.
//
// Also added polygon stripper (converts all polygons into long triangle
// strips to greatly improve rendering performance).
//
// Also added recursive vertex normal generator.  The data coming from cactus
// doesn't include the vertex normals (for bandwidth efficiency), so
// polygons appear flat-shaded and blocky.  The vertex normal generator
// is able to re-create the missing vertex normals and allows us to
// use smooth shading (gouraud shading).
//
// So the latter two changes would be a pain-in-the-ass if it were not
// for VTK.  So my plans to eradicate VTK from this tool are put on
// hold for now.  Its really become a necessary component now.
//
// Revision 1.1  2000/08/25 00:53:37  jshalf
//
// Added a bunch of stuff for IsoView
// It still requires FLTK, Mesa 3.1, and VTK3.1
//
// Revision 1.6  2000/01/19 14:52:23  werner
// Port to Windows NT.
//
// Revision 1.5  1999/11/03 16:01:58  werner
// Changes for preliminiary NT support.
//
// Revision 1.4  1999/10/22 10:34:56  werner
// Cleanups and not required functions deactivated.
//
// Revision 1.3  1999/10/21 11:32:16  werner
// Support for byte swapping under Linux/NT and some possibly essential bugfix.
//
// Revision 1.2  1999/10/18 13:49:19  werner
// Class documentation
//
// Revision 1.1  1999/10/18 09:44:04  werner
// Remote IO Library
//
////////////////////////////////////////////////

#ifndef __RemoteIO_DATARECEIVER_HPP
#define __RemoteIO_DATARECEIVER_HPP

#include <RawTCP.hh>
#include <PortMux.hh>

#include "DataType.hh"
#ifdef WIN32
#include "RemoteIOWinDLLApi.h"
#endif

/// Class for receiving data from a remote site
class DataReceiver : public DataType
{
	int bufsize;
	char *data;
	long nbytes,rcvd;
	int rcount;

	// Networking stuff
	union {
		::Int32 type;
		char tbuf[4];
	};
	union {
		::Int64 size;
		char sizebuf[8];
	};
	char dataname[64];
	RawTCPport *connection,*server;
	PortMux mux;

	// receives incrementally
	enum {RCV_SIZE=1,RCV_TYPE=2,RCV_NAME=3,RCV_DATA=4,RCV_START=0} mode;

public:
	/// Constructor: specify hostname and port number
	DataReceiver(const char *hostname,int port);

	/// Fast TCP Constructor: specify hostname, port number and TCP windowsize
	DataReceiver(const char *hostname,int port,int windowsize);

	/// Create DataReceiver from some already existing connection
	DataReceiver(RawTCPport*Connection);
	~DataReceiver();

	/// get the TCP Connection associated with this  DataReceiver
	RawTCPport *getConnection() { return connection;}
        int isConnected(){ return this->connection->isValid();}
//	int receiveDataHdr(char *name,int &nelements,DataType::Type &datatype);

	// for SC97 (what is this routine for???)
//	void *receiveData(char *buffer,int bufsize); 

	void *receiveNewData(char *name,int &nelements,DataType::Type &datatype);

//      void *receiveData(char *name,int &nelements,DataType::Type &datatype);

	  /** Receive and allocate Data from remote site.
	      Note that the memory is allocated dynamically in this routine,
	      and must be deleted by the caller of this routine.
	   */
	inline void *receiveData(char *name,int &nelements,DataType::Type &datatype) 
	{
		return receiveNewData(name,nelements,datatype);
	}
};

#endif // __RemoteIO_DATARECEIVER_HPP

